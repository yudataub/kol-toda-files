// interactive=false נכשל בכוונה במקום להציג חלון הסכמה — כך העלאה אוטומטית
// יודעת שנדרש אישור מחדש במקום לתקוע חלון קופץ מול מסך ריק
function getAuthToken(interactive) {
  return new Promise((resolve, reject) => {
    chrome.identity.getAuthToken({ interactive }, (token) => {
      if (chrome.runtime.lastError || !token) {
        reject(new Error(chrome.runtime.lastError ? chrome.runtime.lastError.message : 'לא התקבל טוקן'));
        return;
      }
      resolve(token);
    });
  });
}

function removeCachedToken(token) {
  return new Promise((resolve) => {
    chrome.identity.removeCachedAuthToken({ token }, resolve);
  });
}

function startResumableSession(token, metadata, blob) {
  return fetch(
    'https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status',
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json; charset=UTF-8',
        'X-Upload-Content-Type': blob.type,
        'X-Upload-Content-Length': String(blob.size)
      },
      body: JSON.stringify(metadata)
    }
  );
}

async function uploadVideoToYouTube({ blob, title, description, privacyStatus, interactive = true, onProgress }) {
  let token = await getAuthToken(interactive);

  const metadata = {
    snippet: { title, description },
    status: { privacyStatus }
  };

  let initResponse = await startResumableSession(token, metadata, blob);

  // Chrome מחזיק את הטוקן במטמון גם אחרי שפג (כשעה), ואז כל ניסיון חוזר
  // ייכשל שוב עד שמנקים אותו ידנית
  if (initResponse.status === 401) {
    await removeCachedToken(token);
    token = await getAuthToken(interactive);
    initResponse = await startResumableSession(token, metadata, blob);
  }

  if (!initResponse.ok) {
    throw new Error(`אתחול ההעלאה נכשל: ${initResponse.status} ${await initResponse.text()}`);
  }

  const uploadUrl = initResponse.headers.get('Location');
  if (!uploadUrl) {
    throw new Error('לא התקבלה כתובת העלאה מיוטיוב');
  }

  if (onProgress) onProgress('מעלה...');

  const uploadResponse = await fetch(uploadUrl, {
    method: 'PUT',
    headers: { 'Content-Type': blob.type },
    body: blob
  });

  if (!uploadResponse.ok) {
    throw new Error(`ההעלאה נכשלה: ${uploadResponse.status} ${await uploadResponse.text()}`);
  }

  return uploadResponse.json();
}

// יוטיוב מחזירה לכל היותר 50 רשימות בעמוד. בלי מעבר על nextPageToken
// מתקבלות רק 50 הראשונות, ואצלנו אלה היו כמעט כולן פודקאסטים — שאר
// הרשימות פשוט לא הופיעו. כל עמוד עולה יחידת מכסה אחת בלבד
async function listMyPlaylists(token) {
  const playlists = [];
  let pageToken = '';
  do {
    const url = 'https://www.googleapis.com/youtube/v3/playlists?part=snippet&mine=true&maxResults=50'
      + (pageToken ? `&pageToken=${encodeURIComponent(pageToken)}` : '');
    const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
    if (!res.ok) {
      throw new Error(`שליפת רשימות ההשמעה נכשלה: ${res.status} ${await res.text()}`);
    }
    const data = await res.json();
    for (const item of data.items || []) {
      playlists.push({ id: item.id, title: item.snippet.title });
    }
    pageToken = data.nextPageToken || '';
  } while (pageToken);
  return playlists;
}

async function addVideoToPlaylist(videoId, playlistId, token) {
  const res = await fetch(
    'https://www.googleapis.com/youtube/v3/playlistItems?part=snippet',
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        snippet: {
          playlistId,
          resourceId: { kind: 'youtube#video', videoId }
        }
      })
    }
  );
  if (!res.ok) {
    throw new Error(`ההוספה לרשימת ההשמעה נכשלה: ${res.status} ${await res.text()}`);
  }
  return res.json();
}

async function listCaptionTracks(videoId, token) {
  const res = await fetch(
    `https://www.googleapis.com/youtube/v3/captions?part=snippet&videoId=${encodeURIComponent(videoId)}`,
    { headers: { Authorization: `Bearer ${token}` } }
  );
  if (!res.ok) {
    throw new Error(`שליפת רשימת הכתוביות נכשלה: ${res.status} ${await res.text()}`);
  }
  const data = await res.json();
  return data.items || [];
}

async function downloadCaptionTrack(captionId, token) {
  const res = await fetch(
    `https://www.googleapis.com/youtube/v3/captions/${encodeURIComponent(captionId)}?tfmt=srt`,
    { headers: { Authorization: `Bearer ${token}` } }
  );
  if (!res.ok) {
    throw new Error(`הורדת הכתוביות נכשלה: ${res.status} ${await res.text()}`);
  }
  return res.text();
}

// כתוביות עברית מועדפות, וכתוביות שנכתבו ידנית עדיפות על אוטומטיות
function pickCaptionTrack(tracks) {
  const hebrew = tracks.filter((t) => (t.snippet.language || '').startsWith('he'));
  const pool = hebrew.length > 0 ? hebrew : tracks;
  const manual = pool.find((t) => t.snippet.trackKind !== 'asr');
  return manual || pool[0] || null;
}

function srtToPlainText(srt) {
  const lines = srt.split(/\r?\n/);
  const spoken = [];

  for (const line of lines) {
    const text = line.trim();
    if (text === '') continue;
    if (/^\d+$/.test(text)) continue;          // מספור המקטע
    if (text.includes('-->')) continue;        // שורת חותמות הזמן
    // כתוביות אוטומטיות חוזרות על עצמן בין מקטעים עוקבים
    if (spoken[spoken.length - 1] === text) continue;
    spoken.push(text);
  }

  const flowing = spoken.join(' ').replace(/\s+/g, ' ').trim();

  // פסקאות לפי אורך - לתמלול אוטומטי בעברית כמעט אין פיסוק להישען עליו
  const paragraphs = [];
  let current = '';
  for (const word of flowing.split(' ')) {
    current += (current ? ' ' : '') + word;
    if (current.length >= 500) {
      paragraphs.push(current);
      current = '';
    }
  }
  if (current) paragraphs.push(current);

  return paragraphs.join('\n\n');
}
