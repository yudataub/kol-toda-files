// גזירת ההתחלה והסוף של ההקלטה, בלי קידוד מחדש.
//
// קידוד מחדש של שיעור בן שעה היה לוקח זמן דומה לאורך השיעור. במקום זה
// Mediabunny מעתיק את הפריימים המקודדים כמות שהם (copy), ולכן הגזירה
// לוקחת שניות. המחיר: אפשר להתחיל קטע רק בפריים-מפתח, ולכן נקודת
// ההתחלה נסוגה אחורה עד פריים-המפתח הקודם. ההקלטה מבקשת פריים-מפתח כל
// KEYFRAME_INTERVAL_MS (ראו startRecording), כך שהסטייה קטנה.
//
// הקלט נקרא מה-Blob בחתיכות (BlobSource) והפלט נכתב ברצף, כך ששיעור
// ארוך לא נטען כולו לזיכרון בבת אחת

const KEYFRAME_INTERVAL_MS = 2000;

let mediabunnyPromise = null;

function loadMediabunny() {
  if (!mediabunnyPromise) {
    mediabunnyPromise = import(chrome.runtime.getURL('vendor/mediabunny/mediabunny.min.mjs'));
  }
  return mediabunnyPromise;
}

// משך ההקלטה בשניות. אלמנט ה-video לא תמיד יודע אותו (בהקלטות WebM של
// MediaRecorder הוא Infinity), ולכן שואלים את הקובץ עצמו
async function recordingDuration(blob) {
  const mb = await loadMediabunny();
  const input = new mb.Input({ source: new mb.BlobSource(blob), formats: mb.ALL_FORMATS });
  try {
    return await input.computeDuration();
  } finally {
    input.dispose();
  }
}

// ההתחלה מוזזת בעצמנו אל פריים-המפתח שלפניה. בלי זה Mediabunny מכניס
// לקובץ גם את הפריימים שבין פריים-המפתח להתחלה, עם חותמות זמן שליליות —
// כרום מסתיר אותם, אבל נגן אחר או יוטיוב עלולים להציג שנייה קפואה
async function snapToKeyFrame(mb, input, start) {
  if (start <= 0) return 0;
  const track = await input.getPrimaryVideoTrack();
  if (!track) return start;
  const packet = await new mb.EncodedPacketSink(track).getKeyPacket(start);
  return packet ? Math.max(0, packet.timestamp) : 0;
}

async function trimRecording(blob, requestedStart, end, onProgress) {
  const mb = await loadMediabunny();
  const input = new mb.Input({ source: new mb.BlobSource(blob), formats: mb.ALL_FORMATS });
  const start = await snapToKeyFrame(mb, input, requestedStart);

  // MP4 מפוצל (fragmented) ו-WebM במצב appendOnly נכתבים ברצף מההתחלה
  // לסוף, בלי לחזור לתקן כותרות — וזה מה שמאפשר לאסוף את הפלט כחלקים
  const isMp4 = blob.type === 'video/mp4';
  const format = isMp4
    ? new mb.Mp4OutputFormat({ fastStart: 'fragmented' })
    : new mb.WebMOutputFormat({ appendOnly: true });

  const parts = [];
  let written = 0;
  const target = new mb.StreamTarget(new WritableStream({
    write(chunk) {
      if (chunk.position !== written) {
        throw new Error('הפלט לא נכתב ברצף — לא ניתן להרכיב את הקובץ');
      }
      parts.push(chunk.data);
      written += chunk.data.byteLength;
    }
  }), { chunked: true });

  const output = new mb.Output({ format, target });
  const conversion = await mb.Conversion.init({
    input,
    output,
    trim: { start, end },
    copy: {
      // מתירים להזיז את נקודת ההתחלה לפריים-המפתח הקודם, אחרת Mediabunny
      // היה מקודד מחדש כדי לדייק — וזה בדיוק מה שרצינו לחסוך
      shiftTolerance: Infinity,
      boundaryPolicy: 'expand'
    },
    showWarnings: false
  });

  if (!conversion.isValid) {
    input.dispose();
    const reasons = conversion.discardedTracks.map((t) => t.reason).join(', ');
    throw new Error('לא ניתן לגזור את הקובץ הזה' + (reasons ? ` (${reasons})` : ''));
  }

  if (onProgress) conversion.onProgress = onProgress;
  try {
    await conversion.execute();
  } finally {
    input.dispose();
  }
  return { blob: new Blob(parts, { type: blob.type }), start };
}
