// עיצוב תמונת המורה בתוך הווידאו: גודל, מיקום, צורה, מסגרת ושם.
// אותה פונקציית ציור משמשת גם את ההקלטה וגם את התצוגה המקדימה במסך
// ההגדרות, ולכן מה שרואים בהגדרות הוא בדיוק מה שיוקלט

const CAM_STYLE_KEY = 'cameraStyle';

const DEFAULT_CAM_STYLE = {
  size: 22,                 // אחוז מהצלע הקצרה של המסך
  position: 'bottom-right', // top|bottom + -left|-center|-right
  shape: 'circle',          // circle | square | rounded | rect
  frameOn: true,
  frameColor: '#ffffff',
  frameWidth: 2,            // אחוז מגודל התמונה
  nameOn: false,
  name: '',
  background: 'none',       // none | blur | color | image
  bgColor: '#1e3a5f',
  bgImage: ''               // data URL, מוקטן לפני השמירה
};

async function loadCamStyle() {
  const stored = await chrome.storage.local.get(CAM_STYLE_KEY);
  // מיזוג עם ברירת המחדל, כדי שהגדרה שתתווסף בעתיד לא תגיע כ-undefined
  return { ...DEFAULT_CAM_STYLE, ...(stored[CAM_STYLE_KEY] || {}) };
}

function saveCamStyle(style) {
  return chrome.storage.local.set({ [CAM_STYLE_KEY]: style });
}

function camLayout(canvasW, canvasH, style) {
  const base = Math.round(Math.min(canvasW, canvasH) * style.size / 100);
  const w = style.shape === 'rect' ? Math.round(base * 4 / 3) : base;
  const h = base;
  const margin = Math.round(Math.min(canvasW, canvasH) * 0.03);

  const hasName = style.nameOn && style.name.trim() !== '';
  const fontSize = Math.max(12, Math.round(base * 0.11));
  const labelH = hasName ? Math.round(fontSize * 1.7) : 0;
  const labelGap = hasName ? Math.round(fontSize * 0.4) : 0;

  const [vertical, horizontal] = style.position.split('-');
  let x;
  if (horizontal === 'left') x = margin;
  else if (horizontal === 'center') x = Math.round((canvasW - w) / 2);
  else x = canvasW - margin - w;

  // השם יושב מתחת לתמונה, ולכן במיקום תחתון התמונה עולה כדי לפנות לו מקום
  const y = vertical === 'top' ? margin : canvasH - margin - h - labelGap - labelH;

  return { x, y, w, h, fontSize, labelH, labelGap, hasName };
}

function traceCamShape(ctx, x, y, w, h, shape) {
  ctx.beginPath();
  if (shape === 'circle') {
    ctx.ellipse(x + w / 2, y + h / 2, w / 2, h / 2, 0, 0, Math.PI * 2);
  } else if (shape === 'square') {
    ctx.rect(x, y, w, h);
  } else {
    const r = shape === 'rounded' ? Math.min(w, h) * 0.18 : Math.min(w, h) * 0.08;
    ctx.roundRect(x, y, w, h, r);
  }
}

// source: וידאו המצלמה או קנבס אחרי החלפת רקע. נחתך מהמרכז ליחס של
// המסגרת, אחרת הפרופורציות של הפנים נמתחות
function drawCameraOverlay(ctx, canvasW, canvasH, source, style) {
  const srcW = source.videoWidth || source.width;
  const srcH = source.videoHeight || source.height;
  if (!srcW || !srcH) return;

  const { x, y, w, h, fontSize, labelH, labelGap, hasName } = camLayout(canvasW, canvasH, style);

  const targetRatio = w / h;
  let cropW = srcW;
  let cropH = srcW / targetRatio;
  if (cropH > srcH) {
    cropH = srcH;
    cropW = srcH * targetRatio;
  }
  const cropX = (srcW - cropW) / 2;
  const cropY = (srcH - cropH) / 2;

  ctx.save();
  traceCamShape(ctx, x, y, w, h, style.shape);
  ctx.clip();
  ctx.drawImage(source, cropX, cropY, cropW, cropH, x, y, w, h);
  ctx.restore();

  if (style.frameOn && style.frameWidth > 0) {
    traceCamShape(ctx, x, y, w, h, style.shape);
    ctx.lineWidth = Math.max(1, Math.round(Math.min(w, h) * style.frameWidth / 100));
    ctx.strokeStyle = style.frameColor;
    ctx.stroke();
  }

  if (hasName) {
    ctx.save();
    ctx.font = `bold ${fontSize}px Arial, sans-serif`;
    ctx.direction = 'rtl';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    const text = style.name.trim();
    const padX = fontSize * 0.8;
    const labelW = Math.min(ctx.measureText(text).width + padX * 2, canvasW - 8);
    const centerX = Math.min(Math.max(x + w / 2, labelW / 2 + 4), canvasW - labelW / 2 - 4);
    const labelY = y + h + labelGap;

    ctx.fillStyle = 'rgba(0, 0, 0, 0.65)';
    ctx.beginPath();
    ctx.roundRect(centerX - labelW / 2, labelY, labelW, labelH, labelH / 2);
    ctx.fill();

    ctx.fillStyle = '#ffffff';
    ctx.fillText(text, centerX, labelY + labelH / 2, labelW - padX);
    ctx.restore();
  }
}

// תמונת רקע נשמרת ב-chrome.storage (מכסה של 10MB), ולכן מוקטנת ל-JPEG
// ברוחב של עד 1280 לפני השמירה — מספיק בהרבה לתמונה בגודל עיגול המצלמה
function imageFileToDataUrl(file, maxSide = 1280) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      const scale = Math.min(1, maxSide / Math.max(img.width, img.height));
      const canvas = document.createElement('canvas');
      canvas.width = Math.round(img.width * scale);
      canvas.height = Math.round(img.height * scale);
      canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height);
      URL.revokeObjectURL(url);
      resolve(canvas.toDataURL('image/jpeg', 0.85));
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error('לא ניתן לקרוא את התמונה'));
    };
    img.src = url;
  });
}
