const QUALITY_BITRATES = { high: 6_000_000, medium: 3_000_000, low: 1_200_000 };

let mediaRecorder = null;
// שרשרת הכתיבות ל-IndexedDB: onstop עלול לרוץ לפני שהמקטע האחרון נכתב,
// ובלי להמתין לה הסוף של השיעור נחתך
let chunkWriteQueue = Promise.resolve();
let displayStream = null;
let micStream = null;
let audioContext = null;
let recordedMimeType = '';
let timerInterval = null;
let secondsElapsed = 0;
let recordedBlob = null;
let recordedBlobUrl = null;
// אחרי גזירה recordedBlob הוא הקטע הגזור (וזה מה שנשמר ומועלה), וכאן
// נשמרת ההקלטה המלאה — לביטול הגזירה, ולגזירה חוזרת תמיד מהמקור
let originalBlob = null;
let originalBlobUrl = null;
let autoUploadEnabled = false;
let uploadInProgress = false;

let cameraEnabled = false;
let cameraStream = null;
let compositor = null;

const AUTO_UPLOAD_KEY = 'autoUpload';
const UPLOADS_KEY = 'uploads';
const MAX_REMEMBERED_UPLOADS = 20;
const USE_CAMERA_KEY = 'useCamera';
const DEFAULT_PRIVACY = 'unlisted';
const PLAYLIST_KEY = 'playlistId';
const PRIVACY_KEY = 'privacy';
const DESC_KEY = 'description';
const COMPOSITE_FPS = 30;

let camStyle = { ...DEFAULT_CAM_STYLE };

function showScreen(name) {
  document.querySelectorAll('.screen').forEach(el => el.classList.remove('active'));
  document.getElementById('screen-' + name).classList.add('active');
  // ההגדרות נפתחות רק ממסך הפתיחה — מעבר אליהן באמצע הקלטה היה מעלים
  // את כפתורי העצירה
  document.getElementById('btn-settings').hidden = name !== 'start';

  // סט שדות אחד שנודד בין המסכים, ולא שני עותקים שצריך לסנכרן: מה שהוקלד
  // לפני ההקלטה הוא בדיוק מה שמופיע בסיכום, בלי קוד שמעתיק ערכים
  const meta = document.getElementById('upload-meta');
  if (name === 'summary') document.getElementById('meta-slot-summary').appendChild(meta);
  if (name === 'start') document.getElementById('meta-slot-start').appendChild(meta);
}

function setStatus(msg) {
  document.getElementById('status-msg').textContent = msg;
}

function pickMimeType() {
  const candidates = [
    // avc3 ולא avc1: avc3 נושא את תיאור הקודק בתוך הזרם, ולכן שינוי רזולוציה
    // באמצע ההקלטה (החלפת חלון משותף, שינוי גודל) לא הופך את הקובץ ללא-קריא
    'video/mp4;codecs=avc3.42E01E,mp4a.40.2',
    'video/mp4;codecs=avc1.42E01E,mp4a.40.2',
    'video/mp4',
    'video/webm;codecs=vp9,opus',
    'video/webm'
  ];
  return candidates.find((type) => MediaRecorder.isTypeSupported(type)) || '';
}

function formatTimer(totalSeconds) {
  const h = String(Math.floor(totalSeconds / 3600)).padStart(2, '0');
  const m = String(Math.floor((totalSeconds % 3600) / 60)).padStart(2, '0');
  const s = String(totalSeconds % 60).padStart(2, '0');
  return `${h}:${m}:${s}`;
}

function startTimer() {
  secondsElapsed = 0;
  document.getElementById('timer').textContent = formatTimer(0);
  timerInterval = setInterval(() => {
    secondsElapsed += 1;
    document.getElementById('timer').textContent = formatTimer(secondsElapsed);
  }, 1000);
}

function stopTimer() {
  clearInterval(timerInterval);
  timerInterval = null;
}

// הקלטה של שיעור שלם שוקלת מאות מגה-בייט; בלי שחרור מפורש הקלטה קודמת
// נשארת תקועה בזיכרון החלון כל עוד הוא פתוח
function releasePreviousRecording() {
  const preview = document.getElementById('preview');
  preview.removeAttribute('src');
  preview.load();
  if (recordedBlobUrl) {
    URL.revokeObjectURL(recordedBlobUrl);
  }
  if (originalBlobUrl) {
    URL.revokeObjectURL(originalBlobUrl);
  }
  recordedBlobUrl = null;
  recordedBlob = null;
  originalBlob = null;
  originalBlobUrl = null;
}

async function openCameraStream() {
  if (cameraStream) return cameraStream;
  // וידאו בלבד - השמע כבר מגיע מהמיקרופון, ולקיחתו גם מהמצלמה תיצור הד
  cameraStream = await navigator.mediaDevices.getUserMedia({ video: true });
  return cameraStream;
}

function closeCameraStream() {
  if (!cameraStream) return;
  cameraStream.getTracks().forEach((t) => t.stop());
  cameraStream = null;
}

// הווידאו חייב להיות בתוך ה-DOM ולא display:none - כרום מפסיק לפענח פריימים
// של אלמנט מוסתר, והקנבס היה מצייר תמונה קפואה
function playInHiddenVideo(stream) {
  const video = document.createElement('video');
  video.srcObject = stream;
  video.muted = true;
  video.playsInline = true;
  video.style.cssText = 'position:fixed;top:0;left:0;width:1px;height:1px;opacity:0.01;pointer-events:none;';
  document.body.appendChild(video);
  return video.play().then(() => video);
}

// רקע וירטואלי שנכשל בטעינה לא מבטל את ההקלטה — מקליטים עם הרקע האמיתי
async function tryCreateVirtualBackground(style, onError) {
  try {
    return await createVirtualBackground(style);
  } catch (err) {
    console.error('טעינת הרקע הווירטואלי נכשלה', err);
    onError('הרקע הווירטואלי לא נטען, ממשיך עם הרקע האמיתי: ' + err.message);
    return null;
  }
}

// מחזיר את המקור לציור: הקנבס המעובד, או המצלמה עצמה אם העיבוד נכשל
// בפריים הזה — עדיף פריים בלי רקע מאשר עיגול שחור
function cameraFrame(camVideo, virtualBg) {
  if (!virtualBg) return camVideo;
  try {
    return virtualBg.process(camVideo);
  } catch (err) {
    console.warn('עיבוד הרקע נכשל בפריים', err);
    return camVideo;
  }
}

// מצייר את המסך על כל הקנבס ואת המורה לפי ההגדרות (גודל, מיקום, צורה,
// מסגרת, שם, רקע), ומחזיר את זרם הווידאו של הקנבס במקום זה של המסך
async function startCompositing(screenStream, camStream) {
  const screenVideo = await playInHiddenVideo(screenStream);
  const camVideo = await playInHiddenVideo(camStream);
  // העתק: שינוי הגדרות בזמן הקלטה לא אמור לשנות את הווידאו באמצע
  const style = { ...camStyle };
  const virtualBg = await tryCreateVirtualBackground(style, setStatus);

  const canvas = document.createElement('canvas');
  canvas.width = screenVideo.videoWidth;
  canvas.height = screenVideo.videoHeight;
  const ctx = canvas.getContext('2d');

  function drawFrame() {
    ctx.drawImage(screenVideo, 0, 0, canvas.width, canvas.height);
    if (camVideo.videoWidth === 0) return;
    drawCameraOverlay(ctx, canvas.width, canvas.height, cameraFrame(camVideo, virtualBg), style);
  }

  drawFrame();

  const ticker = new Worker('ticker.js');
  ticker.onmessage = drawFrame;
  ticker.postMessage({ action: 'start', intervalMs: Math.round(1000 / COMPOSITE_FPS) });

  compositor = {
    ticker,
    stop() {
      ticker.postMessage({ action: 'stop' });
      ticker.terminate();
      if (virtualBg) virtualBg.close();
      screenVideo.srcObject = null;
      camVideo.srcObject = null;
      screenVideo.remove();
      camVideo.remove();
    }
  };

  return canvas.captureStream(COMPOSITE_FPS);
}

function stopCompositing() {
  if (!compositor) return;
  compositor.stop();
  compositor = null;
}

async function startRecording() {
  setStatus('');
  releasePreviousRecording();
  const quality = document.getElementById('quality').value;
  const bitrate = QUALITY_BITRATES[quality];

  try {
    displayStream = await navigator.mediaDevices.getDisplayMedia({ video: true, audio: true });
  } catch (err) {
    setStatus('בחירת המסך בוטלה או נכשלה: ' + err.message);
    return;
  }

  try {
    micStream = await navigator.mediaDevices.getUserMedia({ audio: true });
  } catch (err) {
    setStatus('אין גישה למיקרופון: ' + err.message);
    displayStream.getTracks().forEach((t) => t.stop());
    return;
  }

  audioContext = new AudioContext();
  const destination = audioContext.createMediaStreamDestination();

  const systemAudioTracks = displayStream.getAudioTracks();
  if (systemAudioTracks.length > 0) {
    const systemSource = audioContext.createMediaStreamSource(new MediaStream(systemAudioTracks));
    systemSource.connect(destination);
  }
  const micSource = audioContext.createMediaStreamSource(micStream);
  micSource.connect(destination);

  let videoTracks = displayStream.getVideoTracks();
  if (cameraEnabled) {
    try {
      const camStream = await openCameraStream();
      const compositeStream = await startCompositing(displayStream, camStream);
      videoTracks = compositeStream.getVideoTracks();
    } catch (err) {
      // עדיף להקליט את השיעור בלי המצלמה מאשר לא להקליט בכלל
      setStatus('המצלמה לא זמינה, ממשיך בהקלטת מסך בלבד: ' + err.message);
    }
  }

  const combinedStream = new MediaStream([
    ...videoTracks,
    ...destination.stream.getAudioTracks()
  ]);

  recordedMimeType = pickMimeType();
  if (!recordedMimeType) {
    setStatus('הדפדפן לא תומך בהקלטת וידאו');
    displayStream.getTracks().forEach((t) => t.stop());
    micStream.getTracks().forEach((t) => t.stop());
    return;
  }
  if (!recordedMimeType.startsWith('video/mp4')) {
    setStatus('שים לב: הדפדפן לא תומך ב-MP4 ישיר, ההקלטה תישמר כ-WebM');
  }

  await beginRecordingSession(recordedMimeType);
  chunkWriteQueue = Promise.resolve();

  mediaRecorder = new MediaRecorder(combinedStream, {
    mimeType: recordedMimeType,
    videoBitsPerSecond: bitrate,
    // פריים-מפתח קבוע מאפשר לגזירה (trim.js) להתחיל קרוב לנקודה שנבחרה.
    // דפדפן שלא מכיר את האפשרות פשוט מתעלם ממנה
    videoKeyFrameIntervalDuration: KEYFRAME_INTERVAL_MS
  });
  mediaRecorder.ondataavailable = (e) => {
    if (!e.data || e.data.size === 0) return;
    chunkWriteQueue = chunkWriteQueue
      .then(() => appendRecordingChunk(e.data))
      .catch((err) => console.error('כתיבת מקטע נכשלה', err));
  };
  mediaRecorder.onstop = handleRecordingStop;
  mediaRecorder.start(1000);

  displayStream.getVideoTracks()[0].addEventListener('ended', () => {
    if (mediaRecorder.state !== 'inactive') stopRecording();
  });

  document.getElementById('btn-pause').textContent = '⏸ השהה';
  startTimer();
  showScreen('recording');
}

function pauseRecording() {
  const btn = document.getElementById('btn-pause');
  if (mediaRecorder.state === 'recording') {
    mediaRecorder.pause();
    stopTimer();
    btn.textContent = '▶ המשך';
  } else if (mediaRecorder.state === 'paused') {
    mediaRecorder.resume();
    timerInterval = setInterval(() => {
      secondsElapsed += 1;
      document.getElementById('timer').textContent = formatTimer(secondsElapsed);
    }, 1000);
    btn.textContent = '⏸ השהה';
  }
}

function stopRecording() {
  stopTimer();
  mediaRecorder.stop();
}

async function handleRecordingStop() {
  // הניקוי חייב לקרות כאן ולא ב-stopRecording: MediaRecorder.stop() אסינכרוני,
  // וסגירת המקורות לפני ה-onstop חותכת את שארית ההקלטה
  stopCompositing();
  displayStream.getTracks().forEach((t) => t.stop());
  micStream.getTracks().forEach((t) => t.stop());
  closeCameraStream();
  audioContext.close();

  await chunkWriteQueue;
  await presentRecordingFromStorage();

  if (autoUploadEnabled) {
    runAutoUpload();
  }
}

function containerTypeFor(mimeType) {
  return mimeType && mimeType.startsWith('video/mp4') ? 'video/mp4' : 'video/webm';
}

async function presentRecordingFromStorage() {
  const [chunks, meta] = await Promise.all([readRecordingChunks(), readRecordingMeta()]);
  recordedBlob = new Blob(chunks, { type: containerTypeFor(meta && meta.mimeType) });
  recordedBlobUrl = URL.createObjectURL(recordedBlob);
  document.getElementById('preview').src = recordedBlobUrl;
  showScreen('summary');
  prepareTrim();
}

// ---------- גזירה ----------

let trimStart = 0;
let trimEnd = null;          // null = עד הסוף
let recordingSeconds = null; // משך ההקלטה המלאה
let trimInProgress = false;

function formatClock(seconds) {
  return formatTimer(Math.max(0, Math.round(seconds)));
}

function setTrimStatus(msg, color) {
  const el = document.getElementById('trim-status');
  el.style.color = color || '#9aa0b5';
  el.textContent = msg;
}

function renderTrimRange() {
  const el = document.getElementById('trim-range');
  const trimmed = originalBlob !== null;
  document.getElementById('btn-trim-start').disabled = trimmed || trimInProgress;
  document.getElementById('btn-trim-end').disabled = trimmed || trimInProgress;
  document.getElementById('btn-trim').disabled = trimmed || trimInProgress;
  document.getElementById('btn-trim-reset').hidden = !trimmed;
  // בזמן גזירה אסור לשמור או להעלות — זה היה נופל על הגרסה הלא-נכונה
  document.getElementById('btn-download').disabled = trimInProgress;
  document.getElementById('btn-upload').disabled = trimInProgress || uploadInProgress;

  if (recordingSeconds === null) {
    el.textContent = 'מחשב את אורך ההקלטה...';
    return;
  }
  const end = trimEnd === null ? recordingSeconds : trimEnd;
  el.innerHTML = '';
  el.append(
    'התחלה ', Object.assign(document.createElement('b'), { textContent: formatClock(trimStart) }),
    ' · סוף ', Object.assign(document.createElement('b'), { textContent: formatClock(end) }),
    ' · אורך ', Object.assign(document.createElement('b'), { textContent: formatClock(end - trimStart) })
  );
}

async function prepareTrim() {
  trimStart = 0;
  trimEnd = null;
  recordingSeconds = null;
  trimInProgress = false;
  setTrimStatus(autoUploadEnabled
    ? 'ההעלאה האוטומטית מעלה את ההקלטה המלאה. אחרי גזירה אפשר לשמור את הקטע במחשב או להעלות אותו שוב ידנית.'
    : '');
  renderTrimRange();

  const blob = recordedBlob;
  try {
    const seconds = await recordingDuration(blob);
    if (blob !== recordedBlob) return; // הוחלפה הקלטה בינתיים
    recordingSeconds = seconds;
  } catch (err) {
    console.error('חישוב אורך ההקלטה נכשל', err);
    const fallback = document.getElementById('preview').duration;
    recordingSeconds = Number.isFinite(fallback) ? fallback : 0;
  }
  renderTrimRange();
}

document.getElementById('btn-trim-start').addEventListener('click', () => {
  const t = document.getElementById('preview').currentTime;
  const end = trimEnd === null ? recordingSeconds : trimEnd;
  if (t >= end - 1) {
    setTrimStatus('ההתחלה חייבת להיות לפני הסוף.', '#ff6b6b');
    return;
  }
  trimStart = t;
  setTrimStatus('');
  renderTrimRange();
});

document.getElementById('btn-trim-end').addEventListener('click', () => {
  const t = document.getElementById('preview').currentTime;
  if (t <= trimStart + 1) {
    setTrimStatus('הסוף חייב להיות אחרי ההתחלה.', '#ff6b6b');
    return;
  }
  // סימון ממש בסוף הסרטון = בלי גזירת סוף
  trimEnd = recordingSeconds && t >= recordingSeconds - 0.05 ? null : t;
  setTrimStatus('');
  renderTrimRange();
});

document.getElementById('btn-trim').addEventListener('click', async () => {
  if (trimStart === 0 && trimEnd === null) {
    setTrimStatus('לא סומנה נקודת התחלה או סוף — אין מה לגזור.', '#f9c74f');
    return;
  }

  trimInProgress = true;
  renderTrimRange();
  setTrimStatus('גוזר...', '#f9c74f');
  const source = recordedBlob;
  try {
    const result = await trimRecording(source, trimStart, trimEnd === null ? undefined : trimEnd, (progress) => {
      setTrimStatus(`גוזר... ${Math.round(progress * 100)}%`, '#f9c74f');
    });
    const trimmed = result.blob;
    // מציגים את נקודת ההתחלה בפועל, אחרי ההצמדה לפריים-מפתח
    trimStart = result.start;

    originalBlob = source;
    originalBlobUrl = recordedBlobUrl;
    recordedBlob = trimmed;
    recordedBlobUrl = URL.createObjectURL(trimmed);
    document.getElementById('preview').src = recordedBlobUrl;

    let newLength = '';
    try {
      newLength = formatClock(await recordingDuration(trimmed));
    } catch (err) {
      console.warn('חישוב אורך הקטע נכשל', err);
    }
    setTrimStatus(
      `✓ נגזר${newLength ? ` — אורך חדש ${newLength} במקום ${formatClock(recordingSeconds)}` : ''}. ` +
      'השמירה למחשב וההעלאה ליוטיוב ישתמשו בקטע הגזור בלבד. ' +
      'נקודת ההתחלה הוקדמה מעט לפריים-המפתח הקרוב (עד 2 שניות), כי הגזירה נעשית בלי קידוד מחדש.',
      '#90ee90'
    );
  } catch (err) {
    console.error('הגזירה נכשלה', err);
    setTrimStatus('הגזירה נכשלה: ' + err.message + ' ההקלטה המלאה לא נפגעה.', '#ff6b6b');
  } finally {
    trimInProgress = false;
    renderTrimRange();
  }
});

document.getElementById('btn-trim-reset').addEventListener('click', () => {
  if (!originalBlob) return;
  URL.revokeObjectURL(recordedBlobUrl);
  recordedBlob = originalBlob;
  recordedBlobUrl = originalBlobUrl;
  originalBlob = null;
  originalBlobUrl = null;
  document.getElementById('preview').src = recordedBlobUrl;
  trimStart = 0;
  trimEnd = null;
  setTrimStatus('הגזירה בוטלה — חזרה להקלטה המלאה.');
  renderTrimRange();
});

function lessonTitleForNow() {
  const now = new Date();
  const pad = (n) => String(n).padStart(2, '0');
  return `שיעור ${pad(now.getDate())}.${pad(now.getMonth() + 1)}.${now.getFullYear()} ${pad(now.getHours())}:${pad(now.getMinutes())}`;
}

function saveRecordingToDisk(askWhere) {
  const ext = recordedBlob.type === 'video/mp4' ? 'mp4' : 'webm';
  const now = new Date();
  const stamp = now.toISOString().slice(0, 19).replace(/[:T]/g, '-');
  chrome.downloads.download({
    url: recordedBlobUrl,
    filename: `שיעור-${stamp}.${ext}`,
    saveAs: askWhere
  }, (downloadId) => {
    // רק כשהקובץ באמת נשמר בדיסק אפשר לוותר על העותק ב-IndexedDB
    if (downloadId !== undefined) clearRecordingSession();
  });
}

function setUploadStatus(msg, color) {
  const statusEl = document.getElementById('upload-status');
  statusEl.style.color = color;
  statusEl.textContent = msg;
}

async function performUpload({ title, description, privacyStatus, interactive }) {
  const uploadBtn = document.getElementById('btn-upload');
  uploadBtn.disabled = true;
  uploadInProgress = true;

  try {
    const result = await uploadVideoToYouTube({
      blob: recordedBlob,
      title,
      description,
      privacyStatus,
      interactive,
      onProgress: (msg) => setUploadStatus(msg + ' אל תסגור את החלון.', '#f9c74f')
    });
    // מדווחים את מה שיוטיוב באמת שמר ולא את מה שביקשנו - בדיקת שפיות זולה
    const actual = result.status ? result.status.privacyStatus : privacyStatus;
    setUploadStatus(`הועלה (${actual}): https://youtu.be/${result.id}`, '#90ee90');
    await rememberUpload(result.id, title);
    await addToSelectedPlaylist(result.id, actual, interactive);
  } catch (err) {
    const hint = interactive
      ? ''
      : ' — לחץ "⬆️ העלה ליוטיוב" כדי לאשר מחדש את החיבור לגוגל.';
    setUploadStatus(`ההעלאה נכשלה: ${err.message}${hint} ההקלטה שמורה במחשב.`, '#ff6b6b');
  } finally {
    uploadInProgress = false;
    uploadBtn.disabled = false;
  }
}

// כישלון בהוספה לרשימה אינו כישלון העלאה - הסרטון כבר ביוטיוב, ולכן
// מדווחים עליו בנפרד ולא הופכים הצלחה לשגיאה
async function addToSelectedPlaylist(videoId, privacyLabel, interactive) {
  const select = document.getElementById('playlist');
  const playlistId = select.value;
  if (!playlistId) return;

  const playlistName = select.options[select.selectedIndex].textContent;
  try {
    const token = await getAuthToken(interactive);
    await addVideoToPlaylist(videoId, playlistId, token);
    setUploadStatus(
      `הועלה (${privacyLabel}) ונוסף ל"${playlistName}": https://youtu.be/${videoId}`,
      '#90ee90'
    );
  } catch (err) {
    setUploadStatus(
      `הועלה (${privacyLabel}): https://youtu.be/${videoId} — אך ההוספה ל"${playlistName}" נכשלה: ${err.message}`,
      '#f9c74f'
    );
  }
}

async function loadPlaylists(interactive) {
  const select = document.getElementById('playlist');
  const hint = document.getElementById('playlist-hint');
  const stored = await chrome.storage.local.get(PLAYLIST_KEY);
  const savedId = stored[PLAYLIST_KEY] || '';

  try {
    // בפתיחת החלון קודם מנסים בלי הסכמה - אבל אם אין טוקן שמור בכלל
    // (למשל אחרי שהתווספה הרשאת playlists לתוסף), אין מה לטעון בלי
    // חלון הסכמה, ואז interactive=true נדרש בפועל
    const token = await getAuthToken(interactive);
    const playlists = await listMyPlaylists(token);
    // עם עשרות רשימות, סדר א"ב הוא מה שמאפשר למצוא רשימה גם בלי חיפוש
    playlists.sort((a, b) => a.title.localeCompare(b.title, 'he', { numeric: true }));

    while (select.options.length > 1) select.remove(1);
    for (const playlist of playlists) {
      const option = document.createElement('option');
      option.value = playlist.id;
      option.textContent = playlist.title;
      select.appendChild(option);
    }
    select.value = savedId;
    hint.hidden = true;
    filterPlaylists();
  } catch (err) {
    // ללא חיבור פעיל, המשתמש צריך לחצן מפורש כדי לפתוח חלון הסכמה -
    // כישלון שקט כאן משאיר את הרשימה ריקה בלי שום הסבר
    console.warn('טעינת רשימות ההשמעה נכשלה', err);
    hint.hidden = false;
  }
}

document.getElementById('playlist-retry').addEventListener('click', (e) => {
  e.preventDefault();
  loadPlaylists(true);
});

const PLAYLIST_LIST_ROWS = 8;

// החיפוש רק מסתיר אפשרויות בתוך אותו <select> ולא בונה רשימה מקבילה —
// addToSelectedPlaylist ממשיך לקרוא את הבחירה ממנו כרגיל. בזמן חיפוש
// ה-select נפתח לרשימה גלויה כדי שהתוצאות ייראו בלי לפתוח תפריט
function filterPlaylists() {
  const select = document.getElementById('playlist');
  const query = document.getElementById('playlist-search').value.trim().toLowerCase();
  const total = select.options.length - 1;
  let shown = 0;

  for (let i = 1; i < select.options.length; i++) {
    const option = select.options[i];
    // הרשימה הנבחרת נשארת גלויה תמיד, אחרת הבחירה נראית כאילו נעלמה
    const match = !query || option.textContent.toLowerCase().includes(query) || option.selected;
    option.hidden = !match;
    if (match) shown++;
  }

  select.size = query ? Math.min(Math.max(shown + 1, 2), PLAYLIST_LIST_ROWS) : 1;
  document.getElementById('playlist-count').textContent =
    total === 0 ? '' : query ? `נמצאו ${shown} מתוך ${total} רשימות` : `${total} רשימות השמעה`;
}

document.getElementById('playlist-search').addEventListener('input', filterPlaylists);

document.getElementById('playlist').addEventListener('change', (e) => {
  chrome.storage.local.set({ [PLAYLIST_KEY]: e.target.value });
});

// הפרטיות והתיאור נשמרים ונטענים בפתיחת החלון, כי במצב אוטומטי ההעלאה
// מתחילה מיד בסיום ההקלטה ואין רגע למלא אותם אחריה
document.getElementById('yt-privacy').addEventListener('change', (e) => {
  chrome.storage.local.set({ [PRIVACY_KEY]: e.target.value });
});

document.getElementById('yt-desc').addEventListener('input', (e) => {
  chrome.storage.local.set({ [DESC_KEY]: e.target.value });
});

async function runAutoUpload() {
  const titleField = document.getElementById('yt-title');
  const title = titleField.value.trim() || lessonTitleForNow();
  const description = document.getElementById('yt-desc').value.trim();
  const privacyStatus = document.getElementById('yt-privacy').value;
  titleField.value = title;

  // עותק מקומי נשמר לפני ההעלאה כדי ששיעור לא ילך לאיבוד אם הרשת תיפול
  saveRecordingToDisk(false);
  setUploadStatus('נשמר במחשב. מעלה ליוטיוב...', '#f9c74f');

  await performUpload({
    title,
    description,
    privacyStatus,
    interactive: false
  });
}

document.getElementById('btn-start').addEventListener('click', startRecording);
document.getElementById('btn-pause').addEventListener('click', pauseRecording);
document.getElementById('btn-stop').addEventListener('click', stopRecording);
document.getElementById('btn-new').addEventListener('click', () => {
  document.getElementById('preview').removeAttribute('src');
  // הכותרת מתנקה כדי ששיעור חדש לא יעלה בשקט תחת השם של הקודם; התיאור
  // והפרטיות נשארים, הם בדרך כלל אותו דבר לכל הסדרה
  document.getElementById('yt-title').value = '';
  showScreen('start');
  // ההקלטה סגרה את המצלמה, אז התצוגה המקדימה צריכה להיפתח מחדש
  if (cameraEnabled) showCameraPreview();
});

document.getElementById('btn-download').addEventListener('click', () => {
  saveRecordingToDisk(true);
});

document.getElementById('btn-upload').addEventListener('click', () => {
  setUploadStatus('מתחבר לחשבון Google...', '#f9c74f');
  performUpload({
    title: document.getElementById('yt-title').value.trim() || lessonTitleForNow(),
    description: document.getElementById('yt-desc').value.trim(),
    privacyStatus: document.getElementById('yt-privacy').value,
    interactive: true
  });
});

document.getElementById('auto-upload').addEventListener('change', (e) => {
  autoUploadEnabled = e.target.checked;
  chrome.storage.local.set({ [AUTO_UPLOAD_KEY]: autoUploadEnabled });
});

async function showCameraPreview() {
  const preview = document.getElementById('cam-preview');
  try {
    preview.srcObject = await openCameraStream();
    preview.hidden = false;
  } catch (err) {
    setStatus('אין גישה למצלמה: ' + err.message);
    document.getElementById('use-camera').checked = false;
    cameraEnabled = false;
  }
}

function hideCameraPreview() {
  const preview = document.getElementById('cam-preview');
  preview.srcObject = null;
  preview.hidden = true;
  closeCameraStream();
}

document.getElementById('use-camera').addEventListener('change', async (e) => {
  cameraEnabled = e.target.checked;
  chrome.storage.local.set({ [USE_CAMERA_KEY]: cameraEnabled });
  if (cameraEnabled) {
    await showCameraPreview();
  } else {
    hideCameraPreview();
  }
});

window.addEventListener('beforeunload', (e) => {
  const isRecording = mediaRecorder && mediaRecorder.state !== 'inactive';
  if (isRecording || uploadInProgress) {
    e.preventDefault();
    e.returnValue = '';
  }
});

async function offerRecoveryIfAny() {
  const chunkCount = await countRecordingChunks();
  if (chunkCount === 0) return;

  const meta = await readRecordingMeta();
  // מקטע לשנייה (timeslice של MediaRecorder), ולכן המספר הוא גם משך ההקלטה
  const minutes = Math.max(1, Math.round(chunkCount / 60));
  const startedAt = meta && meta.startedAt
    ? new Date(meta.startedAt).toLocaleString('he-IL')
    : '';

  document.getElementById('recovery-msg').textContent =
    `נמצאה הקלטה שלא נשמרה, באורך ${minutes} דקות בערך${startedAt ? ' מ-' + startedAt : ''}.`;
  document.getElementById('recovery-box').hidden = false;
}

document.getElementById('btn-recover').addEventListener('click', async () => {
  document.getElementById('recovery-box').hidden = true;
  await presentRecordingFromStorage();
});

document.getElementById('btn-discard').addEventListener('click', async () => {
  await clearRecordingSession();
  document.getElementById('recovery-box').hidden = true;
});

async function rememberUpload(videoId, title) {
  const stored = await chrome.storage.local.get(UPLOADS_KEY);
  const uploads = stored[UPLOADS_KEY] || [];
  uploads.unshift({ id: videoId, title, at: Date.now() });
  await chrome.storage.local.set({ [UPLOADS_KEY]: uploads.slice(0, MAX_REMEMBERED_UPLOADS) });
  await renderUploads();
}

function setTranscriptStatus(msg, color) {
  const el = document.getElementById('transcript-status');
  el.style.color = color;
  el.textContent = msg;
}

// chrome.downloads דוחה תווים שאינם חוקיים בשם קובץ בחלונות
function safeFileName(title) {
  return title.replace(/[\\/:*?"<>|]/g, '-').trim() || 'תמלול';
}

async function fetchTranscript(videoId, title) {
  setTranscriptStatus('מתחבר לחשבון Google...', '#f9c74f');
  try {
    const token = await getAuthToken(true);

    setTranscriptStatus('מחפש כתוביות...', '#f9c74f');
    const tracks = await listCaptionTracks(videoId, token);
    const track = pickCaptionTrack(tracks);
    if (!track) {
      setTranscriptStatus('עדיין אין כתוביות לסרטון הזה. יוטיוב מייצרת אותן תוך כמה דקות עד שעות - נסה שוב מאוחר יותר.', '#f9c74f');
      return;
    }

    setTranscriptStatus('מוריד ומנקה...', '#f9c74f');
    const srt = await downloadCaptionTrack(track.id, token);
    const text = srtToPlainText(srt);
    if (!text) {
      setTranscriptStatus('הכתוביות התקבלו אבל היו ריקות.', '#ff6b6b');
      return;
    }

    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    chrome.downloads.download({ url, filename: `${safeFileName(title)}.txt`, saveAs: true });

    const kind = track.snippet.trackKind === 'asr' ? 'אוטומטיות' : 'ידניות';
    setTranscriptStatus(`התמלול מוכן (כתוביות ${kind}, ${text.length} תווים).`, '#90ee90');
  } catch (err) {
    setTranscriptStatus('שגיאה: ' + err.message, '#ff6b6b');
  }
}

async function renderUploads() {
  const stored = await chrome.storage.local.get(UPLOADS_KEY);
  const uploads = stored[UPLOADS_KEY] || [];
  const box = document.getElementById('uploads-box');
  const list = document.getElementById('uploads-list');

  if (uploads.length === 0) {
    box.hidden = true;
    return;
  }

  list.textContent = '';
  for (const upload of uploads) {
    const row = document.createElement('div');
    row.className = 'upload-row';

    const meta = document.createElement('div');
    meta.className = 'meta';
    const titleEl = document.createElement('b');
    titleEl.textContent = upload.title;
    const dateEl = document.createElement('span');
    dateEl.textContent = new Date(upload.at).toLocaleString('he-IL');
    meta.append(titleEl, dateEl);

    const btn = document.createElement('button');
    btn.textContent = '📄 תמלול';
    btn.onclick = () => fetchTranscript(upload.id, upload.title);

    row.append(meta, btn);
    list.appendChild(row);
  }
  box.hidden = false;
}

// ---------- מסך ההגדרות ----------

let settingsPreview = null;
// מונה שמבטל יצירת רקע וירטואלי שהתחילה לפני שינוי הגדרה חדש יותר
let previewBgGeneration = 0;

// התצוגה המקדימה של המצלמה במסך הפתיחה מקבלת את הצורה שנבחרה, כדי
// שלא תראה עיגול כשבווידאו יוקלט ריבוע
function applyStartPreviewShape() {
  const preview = document.getElementById('cam-preview');
  const radius = { circle: '50%', square: '0', rounded: '18%', rect: '8%' }[camStyle.shape];
  preview.style.borderRadius = radius;
  preview.style.width = camStyle.shape === 'rect' ? '200px' : '150px';
  preview.style.borderColor = camStyle.frameOn ? camStyle.frameColor : 'transparent';
}

// "מסך" לדוגמה מאחורי תמונת המורה, כדי לראות גודל ומיקום ביחס לשקף
function drawMockScreen(ctx, w, h) {
  const gradient = ctx.createLinearGradient(0, 0, w, h);
  gradient.addColorStop(0, '#2b3a67');
  gradient.addColorStop(1, '#1a1f36');
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, w, h);
  ctx.fillStyle = 'rgba(255, 255, 255, 0.85)';
  ctx.fillRect(w * 0.3, h * 0.12, w * 0.6, h * 0.07);
  ctx.fillStyle = 'rgba(255, 255, 255, 0.35)';
  for (let i = 0; i < 4; i++) {
    ctx.fillRect(w * (0.2 + i * 0.05), h * (0.3 + i * 0.1), w * (0.7 - i * 0.05), h * 0.035);
  }
}

// בלי מצלמה מציירים דמות לדוגמה, כדי שעדיין יהיה אפשר לכוון גודל ומיקום
function makePlaceholderPerson() {
  const canvas = document.createElement('canvas');
  canvas.width = 640;
  canvas.height = 480;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#6b7280';
  ctx.fillRect(0, 0, 640, 480);
  ctx.fillStyle = '#d1d5db';
  ctx.beginPath();
  ctx.arc(320, 190, 85, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.ellipse(320, 470, 190, 150, 0, Math.PI, 0);
  ctx.fill();
  return canvas;
}

function drawSettingsPreview() {
  if (!settingsPreview) return;
  const canvas = document.getElementById('settings-preview');
  const ctx = canvas.getContext('2d');
  drawMockScreen(ctx, canvas.width, canvas.height);

  const { camVideo, placeholder, virtualBg } = settingsPreview;
  const source = camVideo ? cameraFrame(camVideo, virtualBg) : placeholder;
  drawCameraOverlay(ctx, canvas.width, canvas.height, source, camStyle);
}

// המודל נטען מחדש רק כשצריך: מעבר בין "ללא" לרקע כלשהו, או תמונה אחרת.
// שינוי צבע או מעבר בין טשטוש לצבע נקרא ישירות מ-camStyle בכל פריים
function previewBgKey() {
  if (camStyle.background === 'none') return 'none';
  return camStyle.background === 'image' ? 'image:' + camStyle.bgImage : 'segment';
}

async function refreshPreviewBackground() {
  if (!settingsPreview || !settingsPreview.camVideo) return;
  const key = previewBgKey();
  if (key === settingsPreview.bgKey) return;
  settingsPreview.bgKey = key;

  const generation = ++previewBgGeneration;
  if (settingsPreview.virtualBg) settingsPreview.virtualBg.close();
  settingsPreview.virtualBg = null;
  if (key === 'none') return;

  const status = document.getElementById('settings-status');
  status.textContent = 'טוען את זיהוי הרקע...';
  // camStyle עצמו ולא העתק: בתצוגה המקדימה שינוי צבע אמור להיראות מיד
  const virtualBg = await tryCreateVirtualBackground(camStyle, (msg) => { status.textContent = msg; });
  if (generation !== previewBgGeneration || !settingsPreview) {
    if (virtualBg) virtualBg.close();
    return;
  }
  settingsPreview.virtualBg = virtualBg;
  if (virtualBg) status.textContent = '';
}

async function openSettings() {
  renderSettingsForm();
  showScreen('settings');
  const status = document.getElementById('settings-status');
  status.textContent = '';

  settingsPreview = { camVideo: null, placeholder: makePlaceholderPerson(), virtualBg: null, bgKey: 'none', timer: null };
  settingsPreview.timer = setInterval(drawSettingsPreview, Math.round(1000 / COMPOSITE_FPS));

  try {
    const video = await playInHiddenVideo(await openCameraStream());
    if (!settingsPreview) {
      video.remove();
      return;
    }
    settingsPreview.camVideo = video;
    await refreshPreviewBackground();
  } catch (err) {
    status.textContent = 'אין גישה למצלמה — מוצגת דמות לדוגמה. ' + err.message;
  }
}

function closeSettings() {
  if (settingsPreview) {
    clearInterval(settingsPreview.timer);
    if (settingsPreview.virtualBg) settingsPreview.virtualBg.close();
    if (settingsPreview.camVideo) {
      settingsPreview.camVideo.srcObject = null;
      settingsPreview.camVideo.remove();
    }
    settingsPreview = null;
  }
  previewBgGeneration++;
  // המצלמה נפתחה רק בשביל התצוגה המקדימה — אם היא כבויה בהקלטה, נסגור אותה
  if (!cameraEnabled) closeCameraStream();
  applyStartPreviewShape();
  showScreen('start');
}

function markChoice(groupId, value) {
  document.querySelectorAll(`#${groupId} button`).forEach((btn) => {
    btn.classList.toggle('selected', btn.dataset.value === value);
  });
}

function renderSettingsForm() {
  document.getElementById('set-size').value = camStyle.size;
  document.getElementById('set-size-val').textContent = camStyle.size + '%';
  markChoice('set-position', camStyle.position);
  markChoice('set-shape', camStyle.shape);
  document.getElementById('set-frame-on').checked = camStyle.frameOn;
  document.getElementById('set-frame-color').value = camStyle.frameColor;
  document.getElementById('set-frame-width').value = camStyle.frameWidth;
  document.getElementById('set-frame-width-val').textContent = camStyle.frameWidth;
  document.getElementById('set-frame-width-row').hidden = !camStyle.frameOn;
  document.getElementById('set-name-on').checked = camStyle.nameOn;
  document.getElementById('set-name').value = camStyle.name;
  markChoice('set-background', camStyle.background);
  document.getElementById('set-bg-color-row').hidden = camStyle.background !== 'color';
  document.getElementById('set-bg-image-row').hidden = camStyle.background !== 'image';
}

function updateCamStyle(changes) {
  Object.assign(camStyle, changes);
  saveCamStyle(camStyle);
  renderSettingsForm();
  refreshPreviewBackground();
}

function bindChoiceGroup(groupId, field) {
  document.querySelectorAll(`#${groupId} button`).forEach((btn) => {
    btn.addEventListener('click', () => updateCamStyle({ [field]: btn.dataset.value }));
  });
}

bindChoiceGroup('set-position', 'position');
bindChoiceGroup('set-shape', 'shape');
bindChoiceGroup('set-background', 'background');

document.getElementById('set-size').addEventListener('input', (e) => updateCamStyle({ size: Number(e.target.value) }));
document.getElementById('set-frame-on').addEventListener('change', (e) => updateCamStyle({ frameOn: e.target.checked }));
document.getElementById('set-frame-color').addEventListener('input', (e) => updateCamStyle({ frameColor: e.target.value }));
document.getElementById('set-frame-width').addEventListener('input', (e) => updateCamStyle({ frameWidth: Number(e.target.value) }));
document.getElementById('set-name-on').addEventListener('change', (e) => updateCamStyle({ nameOn: e.target.checked }));
document.getElementById('set-name').addEventListener('input', (e) => {
  // הקלדת שם מדליקה את הצגתו — אחרת זה נראה כאילו השדה לא עובד
  updateCamStyle({ name: e.target.value, nameOn: e.target.value.trim() !== '' || camStyle.nameOn });
});
document.getElementById('set-bg-color').addEventListener('input', (e) => updateCamStyle({ bgColor: e.target.value }));
document.getElementById('set-bg-image').addEventListener('change', async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  try {
    updateCamStyle({ bgImage: await imageFileToDataUrl(file) });
  } catch (err) {
    document.getElementById('settings-status').textContent = err.message;
  }
});

document.getElementById('btn-settings').addEventListener('click', openSettings);
document.getElementById('btn-settings-back').addEventListener('click', closeSettings);

offerRecoveryIfAny();
renderUploads();

loadCamStyle().then((style) => {
  camStyle = style;
  applyStartPreviewShape();
});

chrome.storage.local.get([AUTO_UPLOAD_KEY, USE_CAMERA_KEY, PRIVACY_KEY, DESC_KEY]).then((stored) => {
  autoUploadEnabled = false;
  document.getElementById('auto-upload').checked = autoUploadEnabled;

  cameraEnabled = stored[USE_CAMERA_KEY] === true;
  document.getElementById('use-camera').checked = cameraEnabled;
  if (cameraEnabled) showCameraPreview();

  document.getElementById('yt-privacy').value = stored[PRIVACY_KEY] || DEFAULT_PRIVACY;
  document.getElementById('yt-desc').value = stored[DESC_KEY] || '';
});
