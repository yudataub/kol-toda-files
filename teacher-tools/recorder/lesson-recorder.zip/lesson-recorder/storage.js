// ההקלטה נכתבת ל-IndexedDB מקטע-מקטע במקום להיצבר בזיכרון, כדי ששיעור
// לא ילך לאיבוד בכיבוי פתאומי, קריסה, או סגירה בטעות של החלון
const DB_NAME = 'lesson-recorder';
const DB_VERSION = 1;
const CHUNK_STORE = 'chunks';
const META_STORE = 'meta';
const META_KEY = 'current';

let dbPromise = null;

function request(req) {
  return new Promise((resolve, reject) => {
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

function openDb() {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(CHUNK_STORE)) {
        db.createObjectStore(CHUNK_STORE, { autoIncrement: true });
      }
      if (!db.objectStoreNames.contains(META_STORE)) {
        db.createObjectStore(META_STORE);
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
  return dbPromise;
}

async function store(name, mode) {
  const db = await openDb();
  return db.transaction(name, mode).objectStore(name);
}

async function beginRecordingSession(mimeType) {
  const chunks = await store(CHUNK_STORE, 'readwrite');
  await request(chunks.clear());
  const meta = await store(META_STORE, 'readwrite');
  await request(meta.put({ mimeType, startedAt: Date.now() }, META_KEY));
}

async function appendRecordingChunk(blob) {
  const chunks = await store(CHUNK_STORE, 'readwrite');
  await request(chunks.add(blob));
}

async function readRecordingChunks() {
  const chunks = await store(CHUNK_STORE, 'readonly');
  return request(chunks.getAll());
}

async function readRecordingMeta() {
  const meta = await store(META_STORE, 'readonly');
  return request(meta.get(META_KEY));
}

async function countRecordingChunks() {
  const chunks = await store(CHUNK_STORE, 'readonly');
  return request(chunks.count());
}

async function clearRecordingSession() {
  const chunks = await store(CHUNK_STORE, 'readwrite');
  await request(chunks.clear());
  const meta = await store(META_STORE, 'readwrite');
  await request(meta.delete(META_KEY));
}
