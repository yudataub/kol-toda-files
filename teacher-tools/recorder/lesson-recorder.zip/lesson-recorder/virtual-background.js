// רקע וירטואלי למורה: MediaPipe מזהה בכל פריים איפה האדם, ומה שמסביבו
// מוחלף בטשטוש, בצבע או בתמונה.
//
// הספרייה והמודל ארוזים בתוך התוסף (vendor/mediapipe) ולא נטענים מהרשת —
// ב-Manifest V3 אסור להריץ קוד מרוחק, וגם כך זה עובד בלי אינטרנט.
// ה-wasm דורש 'wasm-unsafe-eval' ב-content_security_policy של המניפסט

const MEDIAPIPE_DIR = 'vendor/mediapipe/';
// אין טעם לעבד ברזולוציה גבוהה: תמונת המורה תופסת לכל היותר כמחצית
// מגובה הווידאו
const BG_PROCESS_MAX_WIDTH = 640;
// המודל עצמו רואה 256x256. הקטנה שלנו לפני ההעברה אליו חוסכת את ההקטנה
// האיטית שבתוך ה-wasm: נמדד 21ms לפריים בכניסה של 640x480 מול 9ms ב-256
const SEGMENT_INPUT_WIDTH = 256;
// הזיהוי רץ בפריים אחד מכל שניים, והמסכה האחרונה משמשת בינתיים. תזוזה
// של 1/15 שנייה לא נראית בשולי הדמות, והעומס על המעבד יורד בחצי
const SEGMENT_EVERY_N_FRAMES = 2;

let visionModulePromise = null;

function loadVisionModule() {
  if (!visionModulePromise) {
    visionModulePromise = import(chrome.runtime.getURL(MEDIAPIPE_DIR + 'vision_bundle.mjs'));
  }
  return visionModulePromise;
}

function loadImage(src) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('תמונת הרקע לא נטענה'));
    img.src = src;
  });
}

// מחזיר null כשאין רקע וירטואלי, אחרת אובייקט עם process(video) שמחזיר
// קנבס מעובד במקום הווידאו, ו-close()
async function createVirtualBackground(style) {
  if (style.background === 'none') return null;

  const { ImageSegmenter } = await loadVisionModule();
  const base = chrome.runtime.getURL(MEDIAPIPE_DIR);
  const segmenter = await ImageSegmenter.createFromOptions(
    {
      wasmLoaderPath: base + 'vision_wasm_internal.js',
      wasmBinaryPath: base + 'vision_wasm_internal.wasm'
    },
    {
      // CPU ולא GPU: כשחלון המקליט עובר לרקע כרום מאט את ה-GPU של הדף,
      // והפריימים היו נתקעים באמצע השיעור
      baseOptions: { modelAssetPath: base + 'selfie_segmenter.tflite', delegate: 'CPU' },
      runningMode: 'VIDEO',
      outputConfidenceMasks: true,
      outputCategoryMask: false
    }
  );

  const bgImage = style.background === 'image' && style.bgImage ? await loadImage(style.bgImage) : null;

  const out = document.createElement('canvas');
  const outCtx = out.getContext('2d');
  const person = document.createElement('canvas');
  const personCtx = person.getContext('2d');
  const mask = document.createElement('canvas');
  const maskCtx = mask.getContext('2d');
  const segInput = document.createElement('canvas');
  const segInputCtx = segInput.getContext('2d');
  let maskPixels = null;
  let lastTimestamp = -1;
  let frameCount = 0;

  function updateMask(video) {
    const inW = SEGMENT_INPUT_WIDTH;
    const inH = Math.round(inW * video.videoHeight / video.videoWidth);
    if (segInput.width !== inW || segInput.height !== inH) {
      segInput.width = inW;
      segInput.height = inH;
    }
    segInputCtx.drawImage(video, 0, 0, inW, inH);

    // segmentForVideo דורש חותמות זמן עולות ממש; שני פריימים באותה
    // מילישנייה היו זורקים שגיאה
    let timestamp = performance.now();
    if (timestamp <= lastTimestamp) timestamp = lastTimestamp + 1;
    lastTimestamp = timestamp;

    const result = segmenter.segmentForVideo(segInput, timestamp);
    try {
      const confidence = result.confidenceMasks[0];
      const mw = confidence.width;
      const mh = confidence.height;
      const values = confidence.getAsFloat32Array();
      if (mask.width !== mw || mask.height !== mh || !maskPixels) {
        mask.width = mw;
        mask.height = mh;
        maskPixels = maskCtx.createImageData(mw, mh);
      }
      const data = maskPixels.data;
      for (let i = 0; i < values.length; i++) {
        data[i * 4 + 3] = values[i] * 255;
      }
      maskCtx.putImageData(maskPixels, 0, 0);
    } finally {
      result.close();
    }
  }

  function drawBackground(frameSource, w, h) {
    if (style.background === 'blur') {
      outCtx.filter = `blur(${Math.max(4, Math.round(w * 0.025))}px)`;
      outCtx.drawImage(frameSource, 0, 0, w, h);
      outCtx.filter = 'none';
    } else if (style.background === 'image' && bgImage) {
      // כיסוי מלא (cover) בלי עיוות
      const scale = Math.max(w / bgImage.width, h / bgImage.height);
      const dw = bgImage.width * scale;
      const dh = bgImage.height * scale;
      outCtx.drawImage(bgImage, (w - dw) / 2, (h - dh) / 2, dw, dh);
    } else {
      outCtx.fillStyle = style.bgColor;
      outCtx.fillRect(0, 0, w, h);
    }
  }

  function process(video) {
    if (!video.videoWidth) return video;

    const scale = Math.min(1, BG_PROCESS_MAX_WIDTH / video.videoWidth);
    const w = Math.round(video.videoWidth * scale);
    const h = Math.round(video.videoHeight * scale);
    if (out.width !== w || out.height !== h) {
      out.width = person.width = w;
      out.height = person.height = h;
    }

    if (!maskPixels || frameCount % SEGMENT_EVERY_N_FRAMES === 0) updateMask(video);
    frameCount++;

    // שכבת האדם: הווידאו, ורק איפה שהמסכה אומרת שיש אדם
    personCtx.globalCompositeOperation = 'copy';
    personCtx.drawImage(video, 0, 0, w, h);
    personCtx.globalCompositeOperation = 'destination-in';
    personCtx.imageSmoothingEnabled = true;
    personCtx.drawImage(mask, 0, 0, w, h);
    personCtx.globalCompositeOperation = 'source-over';

    drawBackground(video, w, h);
    outCtx.drawImage(person, 0, 0);
    return out;
  }

  return {
    process,
    close() {
      segmenter.close();
    }
  };
}
