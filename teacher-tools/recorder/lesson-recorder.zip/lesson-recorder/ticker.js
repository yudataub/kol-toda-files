// לולאת הציור חייבת לרוץ מתוך worker: כשחלון ההקלטה עובר לרקע (וזה בדיוק מה
// שקורה כשמתחילים להציג) כרום מחניק setInterval ו-requestAnimationFrame בדף
// עצמו, והמצלמה הייתה נתקעת על פריים אחד לכל אורך השיעור
let intervalId = null;

onmessage = (e) => {
  if (e.data.action === 'start' && intervalId === null) {
    intervalId = setInterval(() => postMessage('tick'), e.data.intervalMs);
  } else if (e.data.action === 'stop') {
    clearInterval(intervalId);
    intervalId = null;
  }
};
