@echo off
rem Remote help - kol-toda.co.il. Opens a window; commands run only while it is open.
setlocal
set "KOLHELP_SELF=%~f0"
set "KOLHELP_PS=%TEMP%\kol-remote-help-%RANDOM%%RANDOM%.ps1"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$t=[IO.File]::ReadAllText($env:KOLHELP_SELF,[Text.Encoding]::UTF8); $m=[char]35+[char]35+'PS-START'+[char]35+[char]35; $i=$t.LastIndexOf($m); [IO.File]::WriteAllText($env:KOLHELP_PS,$t.Substring($i),(New-Object Text.UTF8Encoding $true))"
start "" powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%KOLHELP_PS%"
exit /b
##PS-START##
# עזרה מרחוק – הקול החמישי (28.11.2026)
# The visitor runs this (inside remote-help.bat). It opens a session on the kol-help server, shows a code, and runs
# PowerShell commands that the helper sends, ONLY while this window is open, ONLY when the command is signed by the
# helper's private key (RSA, public key below), and by default only after the visitor clicks "Yes" for each one.
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Add-Type -AssemblyName System.Windows.Forms, System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$API = 'https://script.google.com/macros/s/AKfycbyCV-UJeVsYGw54l1yDeg9nghVLZ3MXXMkP2t1exYPzwRw_lmUnvj42yDzXOJ51eBYfrA/exec'
$PUBKEY = '<RSAKeyValue><Modulus>u7vkD625WPRhz71HN6NflLcdFYpiZSxLtDTZjGk0+Y1XhUF33tVv4345rOyfoIC7YVIDEwpGUFBYWRzyOx7SFteK5R4FuBygcYoIiVobfMSftXwQpVQnpVztDVX00NQFtZKAupcdviFEM/868Ibh4caF/L+Gep/W20Dr+jtiYJxt3vAWpvPmkfZaKCxs6V6guAql6isglikwMXiUWNG6XRlKMh8gFmsz5nv/KptWgGCffJVoeb2svUO+0ZJdTo3WDwzE6nmiUhBtLiQsJW7hvybA1UrCxCc0UYYFqZfxwg5Kk1dLR/oBsDQlIHMN23MzbIxwkGaEeJEotwwA+v/CW1NiPHWzUrUQga6e0M+HUzql6LRQEoswbj6hE7EaDjxxgL0G7Iia5BYgTfvvGomtLDmNX50aLqWcXrh8YX5N0yuXBu6otHuYZpwOfKCoR78dnJDGvTqMLB853JFMoPLebQLUHte3j7BySbR/NY0k0Q1m9NkoqfKpmluI4q5/6FTp</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>'
$MAX_HOURS = 3

$sync = [hashtable]::Synchronized(@{
  log = [System.Collections.ArrayList]::Synchronized((New-Object System.Collections.ArrayList))
  code = $null; secret = $null; approve = $true; stop = $false; ended = $false
  ask = $null; answer = $null; problem = ''; status = ''
})

# ---------------- worker (runs in the background, never touches the window) ----------------
$worker = {
  param($sync, $API, $PUBKEY, $MAX_HOURS)
  $ErrorActionPreference = 'Stop'
  [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
  function Say($t) { [void]$sync.log.Add($t) }
  function Post($body) {
    $json = $body | ConvertTo-Json -Compress -Depth 5
    $bytes = [Text.Encoding]::UTF8.GetBytes($json)
    $r = Invoke-WebRequest -Uri $API -Method Post -Body $bytes -ContentType 'text/plain; charset=utf-8' -UseBasicParsing -TimeoutSec 60
    $text = [Text.Encoding]::UTF8.GetString($r.RawContentStream.ToArray())
    return ($text | ConvertFrom-Json)
  }
  $rsa = New-Object Security.Cryptography.RSACryptoServiceProvider
  $rsa.FromXmlString($PUBKEY)
  $done = @{}
  try {
    $os = ''
    try { $o = Get-CimInstance Win32_OperatingSystem; $os = "$($o.Caption) $($o.Version)" } catch {}
    $r = Post @{ action = 'ropen'; problem = $sync.problem; computer = $env:COMPUTERNAME; user = $env:USERNAME; os = $os; approve = $sync.approve }
    if (-not $r.ok) { Say "❌ לא הצלחתי להתחבר לשרת ($($r.error)). נסו שוב בעוד דקה."; $sync.ended = $true; return }
    $sync.secret = $r.secret; $sync.code = $r.code
    Say "✅ מחובר. הקוד: $($r.code)"
    Say "ממתינים לעזרה… כל פקודה שתגיע תופיע כאן."
    $deadline = (Get-Date).AddHours($MAX_HOURS)
    $fails = 0
    while (-not $sync.stop -and (Get-Date) -lt $deadline) {
      try {
        $p = Post @{ action = 'rpoll'; code = $sync.code; secret = $sync.secret; approve = $sync.approve }
        $fails = 0
      } catch {
        $fails++
        if ($fails -eq 3) { Say "⚠️ בעיה בחיבור לאינטרנט, ממשיך לנסות…" }
        Start-Sleep -Seconds 5; continue
      }
      if ($p.error -eq 'closed') { Say "החיבור נסגר."; break }
      foreach ($c in @($p.cmds)) {
        if ($sync.stop) { break }
        if (-not $c -or $done.ContainsKey($c.id)) { continue }
        $done[$c.id] = 1
        $ok = $false
        try {
          $data = [Text.Encoding]::UTF8.GetBytes("$($sync.code)|$($c.id)|$($c.cmd)")
          $ok = $rsa.VerifyData($data, 'SHA256', [Convert]::FromBase64String($c.sig))
        } catch { $ok = $false }
        if (-not $ok) {
          Say "⛔ התקבלה פקודה בלי חתימה תקינה – נדחתה ולא הורצה."
          try { [void](Post @{ action = 'rresult'; code = $sync.code; secret = $sync.secret; id = $c.id; state = 'rejected'; out = 'bad signature'; exit = $null }) } catch {}
          continue
        }
        Say ""
        Say "▶ פקודה:"
        Say $c.cmd
        if ($sync.approve) {
          $sync.answer = $null; $sync.ask = $c.cmd
          while ($null -eq $sync.answer -and -not $sync.stop) { Start-Sleep -Milliseconds 300 }
          $sync.ask = $null
          if ($sync.answer -ne $true) {
            Say "✋ לא אישרת – הפקודה לא הורצה."
            try { [void](Post @{ action = 'rresult'; code = $sync.code; secret = $sync.secret; id = $c.id; state = 'denied'; out = 'the user declined'; exit = $null }) } catch {}
            continue
          }
        }
        $sync.status = 'מריץ פקודה…'
        $file = Join-Path $env:TEMP ("kolhelp-" + [guid]::NewGuid().ToString('N') + ".ps1")
        $prefix = "[Console]::OutputEncoding=[Text.Encoding]::UTF8; `$ProgressPreference='SilentlyContinue'`r`n"
        [IO.File]::WriteAllText($file, $prefix + $c.cmd, (New-Object Text.UTF8Encoding $true))
        $psi = New-Object Diagnostics.ProcessStartInfo 'powershell.exe'
        $psi.Arguments = "-NoProfile -NonInteractive -ExecutionPolicy Bypass -File `"$file`""
        $psi.UseShellExecute = $false; $psi.CreateNoWindow = $true
        $psi.RedirectStandardOutput = $true; $psi.RedirectStandardError = $true
        $psi.StandardOutputEncoding = [Text.Encoding]::UTF8; $psi.StandardErrorEncoding = [Text.Encoding]::UTF8
        $exit = $null; $out = ''
        try {
          $proc = [Diagnostics.Process]::Start($psi)
          $t1 = $proc.StandardOutput.ReadToEndAsync(); $t2 = $proc.StandardError.ReadToEndAsync()
          $limit = [int]([Math]::Min([Math]::Max([double]$c.timeout, 5), 1800) * 1000)
          if ($proc.WaitForExit($limit)) { $proc.WaitForExit(); $exit = $proc.ExitCode }
          else { & taskkill.exe /PID $proc.Id /T /F | Out-Null; $exit = 'timeout' }
          $out = $t1.Result
          if ($t2.Result) { $out += "`n[stderr]`n" + $t2.Result }
        } catch { $out = "could not run: $($_.Exception.Message)"; $exit = 'error' }
        Remove-Item $file -ErrorAction SilentlyContinue
        $show = if ($out.Length -gt 1500) { $out.Substring(0, 1500) + "`n…" } else { $out }
        Say ("◀ תוצאה (" + $exit + "):")
        if ($show.Trim()) { Say $show.TrimEnd() }
        $sync.status = ''
        try { [void](Post @{ action = 'rresult'; code = $sync.code; secret = $sync.secret; id = $c.id; state = 'done'; out = $out; exit = "$exit" }) }
        catch { Say "⚠️ לא הצלחתי לשלוח את התוצאה." }
      }
      Start-Sleep -Seconds 3
    }
    if ((Get-Date) -ge $deadline) { Say "החיבור נסגר אחרי $MAX_HOURS שעות." }
  } catch {
    Say "❌ שגיאה: $($_.Exception.Message)"
  } finally {
    if ($sync.code) { try { [void](Post @{ action = 'rclose'; code = $sync.code; secret = $sync.secret }) } catch {} }
    $sync.ended = $true
  }
}

# ---------------- window ----------------
$font = New-Object Drawing.Font('Segoe UI', 11)
$form = New-Object Windows.Forms.Form
$form.Text = 'עזרה מרחוק – הקול החמישי'
$form.Size = New-Object Drawing.Size(620, 700)
$form.StartPosition = 'CenterScreen'
$form.RightToLeft = 'Yes'; $form.RightToLeftLayout = $true
$form.Font = $font
$form.BackColor = [Drawing.Color]::FromArgb(250, 247, 242)
$form.TopMost = $false

$intro = New-Object Windows.Forms.Label
$intro.Text = "החלון הזה מאפשר לרב יהודה טאוב (ולעוזר הממוחשב שלו) לבדוק ולתקן תקלות במחשב הזה, באמצעות פקודות." + "`n" +
  "• הפקודות רצות רק כל עוד החלון פתוח, וכל פקודה מופיעה כאן עם התוצאה שלה." + "`n" +
  "• אפשר לבקש לאשר כל פקודה לפני שהיא רצה, ואפשר לסיים בכל רגע."
$intro.Location = New-Object Drawing.Point(16, 12); $intro.Size = New-Object Drawing.Size(570, 96)
$form.Controls.Add($intro)

$lbl = New-Object Windows.Forms.Label
$lbl.Text = 'מה הבעיה? (כמה מילים)'; $lbl.Location = New-Object Drawing.Point(16, 112); $lbl.Size = New-Object Drawing.Size(570, 24)
$form.Controls.Add($lbl)

$problem = New-Object Windows.Forms.TextBox
$problem.Multiline = $true; $problem.Location = New-Object Drawing.Point(16, 138); $problem.Size = New-Object Drawing.Size(570, 70)
$problem.ScrollBars = 'Vertical'
$form.Controls.Add($problem)

$approve = New-Object Windows.Forms.CheckBox
$approve.Text = 'לשאול אותי לפני כל פקודה'; $approve.Checked = $true
$approve.Location = New-Object Drawing.Point(16, 214); $approve.Size = New-Object Drawing.Size(400, 28)
$form.Controls.Add($approve)

$connect = New-Object Windows.Forms.Button
$connect.Text = 'התחבר וקבל קוד'; $connect.Location = New-Object Drawing.Point(16, 248); $connect.Size = New-Object Drawing.Size(200, 40)
$connect.BackColor = [Drawing.Color]::FromArgb(13, 148, 136); $connect.ForeColor = [Drawing.Color]::White; $connect.FlatStyle = 'Flat'
$form.Controls.Add($connect)

$codeLbl = New-Object Windows.Forms.Label
$codeLbl.Font = New-Object Drawing.Font('Consolas', 26, [Drawing.FontStyle]::Bold)
$codeLbl.ForeColor = [Drawing.Color]::FromArgb(31, 58, 104)
$codeLbl.Location = New-Object Drawing.Point(230, 246); $codeLbl.Size = New-Object Drawing.Size(356, 46); $codeLbl.TextAlign = 'MiddleCenter'
$form.Controls.Add($codeLbl)

$hint = New-Object Windows.Forms.Label
$hint.Location = New-Object Drawing.Point(16, 294); $hint.Size = New-Object Drawing.Size(570, 26)
$hint.ForeColor = [Drawing.Color]::FromArgb(91, 100, 117)
$form.Controls.Add($hint)

$log = New-Object Windows.Forms.TextBox
$log.Multiline = $true; $log.ReadOnly = $true; $log.ScrollBars = 'Vertical'; $log.WordWrap = $true
$log.Location = New-Object Drawing.Point(16, 324); $log.Size = New-Object Drawing.Size(570, 270)
$log.Font = New-Object Drawing.Font('Consolas', 10); $log.BackColor = [Drawing.Color]::White
$log.RightToLeft = 'No'
$form.Controls.Add($log)

$stop = New-Object Windows.Forms.Button
$stop.Text = 'סיים חיבור'; $stop.Location = New-Object Drawing.Point(16, 604); $stop.Size = New-Object Drawing.Size(160, 40)
$stop.BackColor = [Drawing.Color]::FromArgb(194, 65, 12); $stop.ForeColor = [Drawing.Color]::White; $stop.FlatStyle = 'Flat'
$stop.Enabled = $false
$form.Controls.Add($stop)

$approve.Add_CheckedChanged({ $sync.approve = $approve.Checked })

$ps = $null; $rs = $null
$connect.Add_Click({
  $connect.Enabled = $false; $problem.ReadOnly = $true; $stop.Enabled = $true
  $sync.problem = $problem.Text; $sync.approve = $approve.Checked
  $hint.Text = 'מתחבר…'
  $script:rs = [runspacefactory]::CreateRunspace(); $script:rs.ApartmentState = 'STA'; $script:rs.Open()
  $script:ps = [powershell]::Create(); $script:ps.Runspace = $script:rs
  [void]$script:ps.AddScript($worker).AddArgument($sync).AddArgument($API).AddArgument($PUBKEY).AddArgument($MAX_HOURS)
  [void]$script:ps.BeginInvoke()
})

$stop.Add_Click({ $sync.stop = $true; $stop.Enabled = $false; $hint.Text = 'מסיים…' })

$asking = $false
$timer = New-Object Windows.Forms.Timer
$timer.Interval = 400
$timer.Add_Tick({
  while ($sync.log.Count -gt 0) {
    $line = $sync.log[0]; $sync.log.RemoveAt(0)
    $log.AppendText(($line -replace "`r?`n", "`r`n") + "`r`n")
  }
  if ($sync.code -and $codeLbl.Text -ne $sync.code) {
    $codeLbl.Text = $sync.code
    $hint.Text = 'הקוד נשלח לרב יחד עם תיאור הבעיה. אפשר להשאיר את החלון פתוח ולחכות.'
  }
  if ($sync.status) { $hint.Text = $sync.status } elseif ($sync.code -and -not $sync.ended -and $hint.Text -eq 'מריץ פקודה…') { $hint.Text = 'ממתין לפקודה הבאה…' }
  if ($sync.ask -and -not $script:asking) {
    $script:asking = $true
    $form.Activate()
    $cmdText = [string]$sync.ask
    if ($cmdText.Length -gt 1500) { $cmdText = $cmdText.Substring(0, 1500) + "`n…" }
    $res = [Windows.Forms.MessageBox]::Show($form, "להריץ את הפקודה הזו במחשב?`n`n" + $cmdText, 'אישור פקודה',
      [Windows.Forms.MessageBoxButtons]::YesNo, [Windows.Forms.MessageBoxIcon]::Question,
      [Windows.Forms.MessageBoxDefaultButton]::Button2,
      [Windows.Forms.MessageBoxOptions]::RtlReading -bor [Windows.Forms.MessageBoxOptions]::RightAlign)
    $sync.answer = ($res -eq [Windows.Forms.DialogResult]::Yes)
    $script:asking = $false
  }
  if ($sync.ended -and $stop.Enabled -eq $false -and $hint.Text -ne 'החיבור הסתיים. אפשר לסגור את החלון.') {
    $hint.Text = 'החיבור הסתיים. אפשר לסגור את החלון.'; $codeLbl.Text = ''
  } elseif ($sync.ended -and $stop.Enabled) {
    $stop.Enabled = $false; $hint.Text = 'החיבור הסתיים. אפשר לסגור את החלון.'; $codeLbl.Text = ''
  }
})
$timer.Start()

$form.Add_FormClosing({
  $sync.stop = $true
  $sync.answer = $false
  $t0 = Get-Date
  while ($sync.code -and -not $sync.ended -and ((Get-Date) - $t0).TotalSeconds -lt 8) {
    [Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 200
  }
})

[void]$form.ShowDialog()
