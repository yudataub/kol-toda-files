// The side panel: chat UI + the WebSocket to the bridge on this computer.
(() => {
  const cfg = self.PANEL_CONFIG || {};
  const $ = (id) => document.getElementById(id);
  const messages = $('messages');
  const input = $('input');
  let ws = null;
  let connected = false;
  let running = false;
  let live = null; // the bubble that is filling up while Claude writes
  let liveText = '';
  let settings = { cwd: '', mode: 'auto' };
  let convCwd = '';

  // ----- rendering -----
  function atBottom() { return messages.scrollHeight - messages.scrollTop - messages.clientHeight < 60; }
  function scrollDown(force) { if (force || atBottom()) messages.scrollTop = messages.scrollHeight; }
  function el(tag, cls, text) {
    const node = document.createElement(tag);
    if (cls) node.className = cls;
    if (text !== undefined) node.textContent = text;
    return node;
  }
  function showEmpty() {
    messages.replaceChildren();
    const box = el('div', 'empty');
    box.append(el('b', '', 'שלום'), document.createTextNode('אני Claude שרץ במחשב שלך. אפשר לבקש ממני לעבוד עם קבצים ותיקיות, להריץ את הסקילים שלך, לקרוא את הדף הפתוח ולפעול בו.'));
    messages.append(box);
  }
  function removeTyping() { const t = messages.querySelector('.typing'); if (t) t.remove(); }
  function showTyping() {
    removeTyping();
    if (running) messages.append(el('div', 'msg typing', 'עובד'));
  }
  function renderItem(item) {
    const empty = messages.querySelector('.empty');
    if (empty) empty.remove();
    const stick = atBottom();
    removeTyping();
    let node;
    if (item.role === 'assistant') {
      node = live || el('div', 'msg assistant');
      node.innerHTML = self.renderMarkdown(item.text);
      speakButton(node, item.text);
      live = null;
      liveText = '';
    } else {
      node = el('div', 'msg ' + item.role, item.text);
      if (item.role === 'tool') node.title = item.text;
    }
    if (!node.isConnected) messages.append(node);
    showTyping();
    scrollDown(stick || item.role === 'user');
  }
  function renderDelta(text) {
    const stick = atBottom();
    if (!live) {
      const empty = messages.querySelector('.empty');
      if (empty) empty.remove();
      removeTyping();
      live = el('div', 'msg assistant');
      messages.append(live);
    }
    liveText += text;
    live.innerHTML = self.renderMarkdown(liveText);
    scrollDown(stick);
  }
  function renderAll(items) {
    live = null;
    liveText = '';
    if (!items.length) return showEmpty();
    messages.replaceChildren();
    for (const item of items) renderItem(item);
    scrollDown(true);
  }
  function notice(text) {
    messages.append(el('div', 'msg info', text));
    scrollDown(true);
  }
  function setRunning(value) {
    running = value;
    $('btn-send').hidden = running;
    $('btn-stop').hidden = !running;
    $('dot').className = 'dot ' + (!connected ? 'off' : running ? 'busy' : 'on');
    $('dot').title = !connected ? 'מנותק' : running ? 'עובד' : 'מחובר למחשב';
    if (running) showTyping(); else { removeTyping(); live = null; liveText = ''; }
  }
  function applySettings() {
    $('set-cwd').value = settings.cwd || '';
    $('set-mode').value = settings.mode || 'auto';
    $('set-desktop').checked = settings.desktop !== false;
    $('set-topmost').checked = !!settings.topmost;
    $('model').value = settings.model || '';
    $('cwd-hint').textContent = convCwd && convCwd !== settings.cwd
      ? `השיחה הנוכחית ממשיכה בתיקייה ${convCwd}. התיקייה החדשה תחול משיחה חדשה.` : '';
  }

  // ----- read an answer aloud (the bridge turns it into speech with Gemini, piece by piece) -----
  let speech = null; // { id, button, queue, playing, audio, total, received }
  function speakButton(node, text) {
    const button = el('button', 'speak', '🔊');
    button.title = 'השמע את התשובה';
    button.onclick = () => {
      const mine = speech && speech.button === button;
      stopSpeech();
      if (mine) return;
      speech = { id: `${Date.now()}-${Math.random().toString(16).slice(2)}`, button, queue: [], playing: false, audio: null, total: null, received: 0 };
      button.textContent = '⏳';
      button.title = 'מכין הקראה. לחיצה מבטלת';
      send({ type: 'speak', id: speech.id, text });
    };
    node.append(button);
  }
  function stopSpeech() {
    const s = speech;
    if (!s) return;
    speech = null;
    if (s.audio) s.audio.pause();
    s.queue.forEach((url) => URL.revokeObjectURL(url));
    s.button.textContent = '🔊';
    s.button.title = 'השמע את התשובה';
    if (s.total === null || s.received < s.total) send({ type: 'speak_stop', id: s.id });
  }
  function onSpeech(msg) {
    const s = speech;
    if (!s || msg.id !== s.id) return;
    if (msg.error) { stopSpeech(); return notice('ההקראה נכשלה: ' + msg.error); }
    s.total = msg.total;
    s.received++;
    const bytes = Uint8Array.from(atob(msg.audio), (c) => c.charCodeAt(0));
    s.queue.push(URL.createObjectURL(new Blob([bytes], { type: 'audio/wav' })));
    playNextSpeech();
  }
  function playNextSpeech() {
    const s = speech;
    if (!s || s.playing) return;
    const url = s.queue.shift();
    if (!url) {
      if (s.received >= s.total) stopSpeech();
      return;
    }
    s.playing = true;
    s.button.textContent = '⏹';
    s.button.title = 'עצור הקראה';
    const audio = new Audio(url);
    s.audio = audio;
    audio.onended = audio.onerror = () => {
      URL.revokeObjectURL(url);
      if (speech !== s) return;
      s.playing = false;
      if (!s.queue.length && s.received < s.total) s.button.textContent = '⏳';
      playNextSpeech();
    };
    audio.play().catch(() => { if (speech === s) { stopSpeech(); notice('הדפדפן חסם את ההשמעה. לחץ שוב על 🔊.'); } });
  }

  // ----- permission requests (only in "ask" mode) -----
  function askPermission(msg) {
    const box = el('div', 'msg permission');
    box.append(el('b', '', 'Claude מבקש אישור:'), el('code', '', msg.summary));
    const row = el('div', 'row');
    const yes = el('button', 'primary', 'אשר');
    const no = el('button', '', 'דחה');
    const answer = (allow) => {
      send({ type: 'permission_reply', id: msg.id, allow });
      box.replaceChildren(el('span', '', (allow ? '✓ אושר: ' : '✗ נדחה: ') + msg.summary));
      box.className = 'msg info';
    };
    yes.onclick = () => answer(true);
    no.onclick = () => answer(false);
    row.append(yes, no);
    box.append(row);
    removeTyping();
    messages.append(box);
    scrollDown(true);
  }

  // ----- connection -----
  function send(obj) {
    if (ws && ws.readyState === 1) ws.send(JSON.stringify(obj));
  }
  function connect() {
    if (!cfg.token) {
      $('offline').hidden = false;
      $('offline').querySelector('span').textContent = 'חסר קובץ config.js בתוסף. מריצים שוב את install.mjs וטוענים את התוסף מחדש.';
      return;
    }
    ws = new WebSocket(`ws://127.0.0.1:${cfg.port || 5199}/ws?token=${encodeURIComponent(cfg.token)}`);
    ws.onopen = () => {
      connected = true;
      $('offline').hidden = true;
      setRunning(running);
      send({ type: 'hello' });
    };
    ws.onclose = () => {
      const was = connected;
      connected = false;
      ws = null;
      $('offline').hidden = false;
      if (was) setRunning(false);
      setTimeout(connect, 3000);
    };
    ws.onerror = () => {};
    ws.onmessage = async (event) => {
      const msg = JSON.parse(event.data);
      switch (msg.type) {
        case 'init':
          settings = msg.settings;
          convCwd = msg.conv.cwd;
          $('title').textContent = msg.conv.title || 'Claude במחשב שלי';
          renderAll(msg.conv.items);
          setRunning(msg.running);
          applySettings();
          break;
        case 'item': renderItem(msg.item); break;
        case 'delta': renderDelta(msg.text); break;
        case 'running': setRunning(msg.running); break;
        case 'notice': notice(msg.text); break;
        case 'settings':
          settings = msg.settings;
          convCwd = msg.convCwd;
          applySettings();
          break;
        case 'list': renderHistory(msg.items); break;
        case 'permission': askPermission(msg); break;
        case 'speech': onSpeech(msg); break;
        case 'recording_saved': if (self.onRecordingSaved) self.onRecordingSaved(msg); break;
        case 'browser_call': {
          const result = await self.runBrowserTool(msg.tool, msg.args);
          send({ type: 'browser_result', id: msg.id, ...result });
          break;
        }
      }
    };
  }

  // ----- sending -----
  async function submit() {
    if (running) return;
    let text = input.value.trim();
    if (self.stopDictation) self.stopDictation(true); // sending ends the dictation and discards its leftovers
    const withRecording = self.hasRecording && self.hasRecording();
    if (!text && !withRecording) return;
    if (!connected) return notice('אין חיבור לגשר שבמחשב.');
    input.value = '';
    autosize();
    const recording = withRecording ? await self.takeRecording() : null;
    if (!text) {
      if (!recording) return;
      text = 'צפה בהקלטה והמשך את התהליך שהראיתי.';
    }
    const context = await self.currentTabContext();
    send({ type: 'send', text, context, recording });
  }
  function autosize() {
    input.style.height = 'auto';
    input.style.height = Math.min(input.scrollHeight, 160) + 'px';
  }
  input.addEventListener('input', autosize);
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); submit(); }
  });
  $('btn-send').onclick = submit;
  $('btn-stop').onclick = () => send({ type: 'stop' });
  $('btn-new').onclick = () => { send({ type: 'new' }); input.focus(); };

  // ----- settings + history sheets -----
  $('btn-settings').onclick = () => { $('history').hidden = true; $('settings').hidden = !$('settings').hidden; applySettings(); };
  $('set-close').onclick = () => { $('settings').hidden = true; };
  $('set-save').onclick = () => {
    send({ type: 'settings', cwd: $('set-cwd').value, mode: $('set-mode').value, desktop: $('set-desktop').checked, topmost: $('set-topmost').checked });
    $('settings').hidden = true;
  };
  $('btn-history').onclick = () => {
    $('settings').hidden = true;
    $('history').hidden = !$('history').hidden;
    if (!$('history').hidden) send({ type: 'list' });
  };
  $('history-close').onclick = () => { $('history').hidden = true; };
  $('model').onchange = () => send({ type: 'settings', model: $('model').value }); // applies from the next message
  $('history-current').onclick = () => send({ type: 'resume_external' });
  function renderHistory(items) {
    const list = $('history-list');
    list.replaceChildren();
    if (!items.length) return list.append(el('div', 'hint', 'עוד אין שיחות שמורות.'));
    for (const item of items) {
      const row = el('div', 'hist');
      const date = new Date(item.ts);
      row.append(el('span', 't', item.title), el('span', 'd', `${date.getDate()}.${date.getMonth() + 1} ${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`));
      if (item.sessionId) {
        const ext = el('button', '', '↗');
        ext.title = 'המשך ב-Claude Code הרגיל';
        ext.onclick = (e) => { e.stopPropagation(); send({ type: 'resume_external', id: item.id }); };
        row.append(ext);
      }
      const del = el('button', '', '✕');
      del.title = 'מחק מהרשימה';
      del.onclick = (e) => { e.stopPropagation(); send({ type: 'delete', id: item.id }); };
      row.append(del);
      row.onclick = () => { send({ type: 'open', id: item.id }); $('history').hidden = true; };
      list.append(row);
    }
  }

  // ----- which tab Claude sees -----
  async function refreshTabLine() {
    if (self.PANEL_STANDALONE) { $('tabline').textContent = '🖥 חלון עצמאי – עובד בכל המחשב'; return; }
    const context = await self.currentTabContext();
    $('tabline').textContent = context ? `📄 ${context.title || context.url}` : '';
  }
  if (!self.PANEL_STANDALONE) {
    chrome.tabs.onActivated.addListener(refreshTabLine);
    chrome.tabs.onUpdated.addListener((id, info) => { if (info.title || info.status === 'complete') refreshTabLine(); });
    chrome.windows.onFocusChanged.addListener(refreshTabLine);
  }

  self.Panel = { send, notice, input, autosize };
  showEmpty();
  refreshTabLine();
  connect();
  input.focus();
})();
