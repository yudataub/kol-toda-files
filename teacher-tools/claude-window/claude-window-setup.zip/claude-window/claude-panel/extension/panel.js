// The side panel: chat UI + the WebSocket to the bridge on this computer.
(() => {
  const cfg = self.PANEL_CONFIG || {};
  const $ = (id) => document.getElementById(id);
  const messages = $('messages');
  const input = $('input');
  let ws = null;
  let connected = false;
  let running = false;
  let live = null; // the bubble that is filling up while Claude writes
  let liveText = '';
  let settings = { cwd: '', mode: 'auto' };
  let convCwd = '';
  let lastAnswer = null; // the last thing Claude wrote in the turn that is running: a voice conversation reads it aloud

  // ----- rendering -----
  function atBottom() { return messages.scrollHeight - messages.scrollTop - messages.clientHeight < 60; }
  function scrollDown(force) { if (force || atBottom()) messages.scrollTop = messages.scrollHeight; }
  function el(tag, cls, text) {
    const node = document.createElement(tag);
    if (cls) node.className = cls;
    if (text !== undefined) node.textContent = text;
    return node;
  }
  function showEmpty() {
    messages.replaceChildren();
    const box = el('div', 'empty');
    box.append(el('b', '', 'שלום'), document.createTextNode('אני Claude שרץ במחשב שלך. אפשר לבקש ממני לעבוד עם קבצים ותיקיות, להריץ את הסקילים שלך, לקרוא את הדף הפתוח ולפעול בו.'));
    messages.append(box);
  }
  function removeTyping() { const t = messages.querySelector('.typing'); if (t) t.remove(); }
  // While a turn runs: how long it has been going and what it is running right now, so a long command
  // (a build, a download) does not look like a hang.
  let runStart = 0;
  let lastTool = '';
  function typingText() {
    const s = Math.max(0, Math.floor((Date.now() - runStart) / 1000));
    const clock = `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
    return `עובד ${clock}` + (lastTool ? ` · מריץ עכשיו: ${lastTool.slice(0, 70)}` : '');
  }
  function showTyping() {
    removeTyping();
    if (running) messages.append(el('div', 'msg typing', typingText()));
  }
  setInterval(() => {
    const t = messages.querySelector('.typing');
    if (t && running) t.textContent = typingText();
  }, 1000);
  function renderItem(item) {
    const empty = messages.querySelector('.empty');
    if (empty) empty.remove();
    const stick = atBottom();
    removeTyping();
    let node;
    if (item.role === 'assistant') {
      node = live || el('div', 'msg assistant');
      node.innerHTML = self.renderMarkdown(item.text);
      speakButton(node, item.text);
      lastAnswer = { node, text: item.text };
      live = null;
      liveText = '';
    } else {
      node = el('div', 'msg ' + item.role, item.text);
      if (item.role === 'user') lastAnswer = null;
      if (item.role === 'tool') { node.title = item.text; lastTool = item.text; } else lastTool = '';
      if (item.role === 'user' && item.imageCount) {
        const thumbs = el('div', 'thumbs');
        for (const src of item.images || []) {
          if (!/^data:image\/jpeg;base64,/.test(src)) continue;
          const img = document.createElement('img');
          img.src = src;
          img.alt = 'תמונה מצורפת';
          thumbs.append(img);
        }
        if (!thumbs.children.length) thumbs.textContent = `🖼 ${item.imageCount} תמונות מצורפות`;
        node.append(thumbs);
      }
    }
    if (!node.isConnected) messages.append(node);
    showTyping();
    scrollDown(stick || item.role === 'user');
  }
  function renderDelta(text) {
    const stick = atBottom();
    if (!live) {
      const empty = messages.querySelector('.empty');
      if (empty) empty.remove();
      removeTyping();
      live = el('div', 'msg assistant');
      messages.append(live);
    }
    liveText += text;
    live.innerHTML = self.renderMarkdown(liveText);
    scrollDown(stick);
  }
  function renderAll(items) {
    live = null;
    liveText = '';
    if (!items.length) return showEmpty();
    messages.replaceChildren();
    for (const item of items) renderItem(item);
    scrollDown(true);
  }
  function notice(text) {
    messages.append(el('div', 'msg info', text));
    scrollDown(true);
  }
  function setRunning(value) {
    if (value && !running) runStart = Date.now();
    if (!value) lastTool = '';
    running = value;
    $('btn-send').hidden = running;
    $('btn-stop').hidden = !running;
    $('sendrow').hidden = !running;
    $('dot').className = 'dot ' + (!connected ? 'off' : running ? 'busy' : 'on');
    $('dot').title = !connected ? 'מנותק' : running ? 'עובד' : 'מחובר למחשב';
    if (running) showTyping(); else { removeTyping(); live = null; liveText = ''; }
  }
  function applySettings() {
    $('set-cwd').value = settings.cwd || '';
    $('set-mode').value = settings.mode || 'auto';
    $('set-desktop').checked = settings.desktop !== false;
    $('set-topmost').checked = !!settings.topmost;
    $('set-remote').checked = settings.remote !== false;
    $('set-autoupdate').checked = settings.autoUpdate !== false;
    $('app-version').textContent = bridgeVersion ? 'גרסה ' + bridgeVersion : '';
    $('model').value = settings.model || '';
    $('cwd-hint').textContent = convCwd && convCwd !== settings.cwd
      ? `השיחה הנוכחית ממשיכה בתיקייה ${convCwd}. התיקייה החדשה תחול משיחה חדשה.` : '';
  }

  // ----- messages that wait for the end of the running work -----
  function renderQueue(items) {
    const box = $('queue');
    box.replaceChildren();
    box.hidden = !items || !items.length;
    for (const item of items || []) {
      const row = el('div', 'q');
      row.title = item.text;
      const extra = (item.imageCount ? ' 🖼' : '') + (item.recording ? ' 🎬' : '');
      const drop = el('button', '', '✕');
      drop.title = 'בטל את ההודעה הזו';
      drop.onclick = () => send({ type: 'unqueue', id: item.id });
      row.append(el('span', '', `⏳ יישלח בסוף העבודה: ${item.text}${extra}`), drop);
      box.append(row);
    }
  }

  // ----- read an answer aloud (the bridge turns it into speech with Gemini, piece by piece) -----
  let speech = null; // { id, button, queue, playing, audio, total, received }
  function speakButton(node, text) {
    const button = el('button', 'speak', '🔊');
    button.title = 'השמע את התשובה';
    button.onclick = () => {
      const mine = speech && speech.button === button;
      stopSpeech();
      if (mine) return;
      speech = { id: `${Date.now()}-${Math.random().toString(16).slice(2)}`, button, text, queue: [], playing: false, audio: null, total: null, received: 0 };
      button.textContent = '⏳';
      button.title = 'מכין הקראה. לחיצה מבטלת';
      send({ type: 'speak', id: speech.id, text, max: self.voiceOn ? 500 : undefined });
    };
    node.append(button);
  }
  function stopSpeech(reason) {
    const s = speech;
    if (!s) return;
    speech = null;
    if (s.audio) s.audio.pause();
    s.queue.forEach((url) => URL.revokeObjectURL(url));
    s.button.textContent = '🔊';
    s.button.title = 'השמע את התשובה';
    if (s.total === null || s.received < s.total) send({ type: 'speak_stop', id: s.id });
    if (self.onSpeechEnd) self.onSpeechEnd(reason || 'stopped');
  }
  function onSpeech(msg) {
    const s = speech;
    if (!s || msg.id !== s.id) return;
    if (msg.error) {
      stopSpeech('error');
      if (self.onSpeechFail && self.onSpeechFail(s.text, msg.error)) return; // a voice conversation falls back to the browser's own voice
      return notice('ההקראה נכשלה: ' + msg.error);
    }
    s.total = msg.total;
    s.received++;
    const bytes = Uint8Array.from(atob(msg.audio), (c) => c.charCodeAt(0));
    s.queue.push(URL.createObjectURL(new Blob([bytes], { type: 'audio/wav' })));
    playNextSpeech();
  }
  function playNextSpeech() {
    const s = speech;
    if (!s || s.playing) return;
    const url = s.queue.shift();
    if (!url) {
      if (s.received >= s.total) stopSpeech('done');
      return;
    }
    s.playing = true;
    s.button.textContent = '⏹';
    s.button.title = 'עצור הקראה';
    const audio = new Audio(url);
    s.audio = audio;
    audio.onended = audio.onerror = () => {
      URL.revokeObjectURL(url);
      if (speech !== s) return;
      s.playing = false;
      if (!s.queue.length && s.received < s.total) s.button.textContent = '⏳';
      playNextSpeech();
    };
    audio.play().catch(() => { if (speech === s) { stopSpeech(); notice('הדפדפן חסם את ההשמעה. לחץ שוב על 🔊.'); } });
  }

  // ----- the same conversation in regular Claude (Remote Control) -----
  function showRemoteLink(url) {
    const link = $('remote-link');
    const ok = typeof url === 'string' && url.startsWith('https://claude.ai/');
    link.hidden = !ok;
    if (ok) link.href = url; else link.removeAttribute('href');
  }

  // ----- permission requests (only in "ask" mode) -----
  function askPermission(msg) {
    const box = el('div', 'msg permission');
    box.append(el('b', '', 'Claude מבקש אישור:'), el('code', '', msg.summary));
    const row = el('div', 'row');
    const yes = el('button', 'primary', 'אשר');
    const no = el('button', '', 'דחה');
    const answer = (allow) => {
      send({ type: 'permission_reply', id: msg.id, allow });
      box.replaceChildren(el('span', '', (allow ? '✓ אושר: ' : '✗ נדחה: ') + msg.summary));
      box.className = 'msg info';
    };
    yes.onclick = () => answer(true);
    no.onclick = () => answer(false);
    row.append(yes, no);
    box.append(row);
    removeTyping();
    messages.append(box);
    scrollDown(true);
  }

  // ----- automatic update: the bridge installed a new version and restarted; load the new panel code -----
  let bridgeVersion = '';
  function store(key, value) {
    try { if (value === undefined) return localStorage.getItem(key); localStorage.setItem(key, value); } catch {}
    return null;
  }
  function versionChanged(version) {
    if (!version) return false;
    const inExtension = location.protocol === 'chrome-extension:' && self.chrome && chrome.runtime && chrome.runtime.reload;
    const mine = inExtension ? chrome.runtime.getManifest().version : (bridgeVersion || version);
    bridgeVersion = version;
    // Once per version, so a copy that was not updated (an extension loaded from another folder) cannot loop.
    if (mine === version || store('panel-reloaded-for') === version) return false;
    store('panel-reloaded-for', version);
    if (inExtension) chrome.runtime.reload(); else location.reload();
    return true;
  }
  function announceUpdate(version) {
    if (store('panel-update-shown') === version) return;
    store('panel-update-shown', version);
    notice(`החלונית עודכנה לגרסה ${version}.`);
  }

  // ----- connection -----
  function send(obj) {
    if (ws && ws.readyState === 1) ws.send(JSON.stringify(obj));
  }
  function connect() {
    if (!cfg.token) {
      $('offline').hidden = false;
      $('offline').querySelector('span').textContent = 'חסר קובץ config.js בתוסף. מריצים שוב את install.mjs וטוענים את התוסף מחדש.';
      return;
    }
    ws = new WebSocket(`ws://127.0.0.1:${cfg.port || 5199}/ws?token=${encodeURIComponent(cfg.token)}`);
    ws.onopen = () => {
      connected = true;
      $('offline').hidden = true;
      setRunning(running);
      send({ type: 'hello' });
    };
    ws.onclose = () => {
      const was = connected;
      connected = false;
      ws = null;
      $('offline').hidden = false;
      if (was) setRunning(false);
      setTimeout(connect, 3000);
    };
    ws.onerror = () => {};
    ws.onmessage = async (event) => {
      const msg = JSON.parse(event.data);
      switch (msg.type) {
        case 'init':
          if (versionChanged(msg.version)) return;
          if (msg.updated) announceUpdate(msg.updated);
          settings = msg.settings;
          convCwd = msg.conv.cwd;
          $('title').textContent = msg.conv.title || 'Claude במחשב שלי';
          renderAll(msg.conv.items);
          showRemoteLink(msg.remoteUrl);
          renderQueue(msg.queue);
          setRunning(msg.running);
          applySettings();
          break;
        case 'item': renderItem(msg.item); break;
        case 'delta': renderDelta(msg.text); break;
        case 'running': {
          const was = running;
          setRunning(msg.running);
          if (was && !msg.running && self.onTurnEnd) self.onTurnEnd(lastAnswer);
          break;
        }
        case 'notice': notice(msg.text); break;
        case 'settings':
          settings = msg.settings;
          convCwd = msg.convCwd;
          applySettings();
          break;
        case 'list': renderHistory(msg.items); break;
        case 'queue': renderQueue(msg.items); break;
        case 'permission': askPermission(msg); break;
        case 'speech': onSpeech(msg); break;
        case 'remote': showRemoteLink(msg.url); break;
        case 'recording_saved': if (self.onRecordingSaved) self.onRecordingSaved(msg); break;
        case 'browser_call': {
          const result = await self.runBrowserTool(msg.tool, msg.args);
          send({ type: 'browser_result', id: msg.id, ...result });
          break;
        }
      }
    };
  }

  // ----- sending -----
  // when: while Claude works, 'after' keeps the message for the end of the work and 'now' gives it to him right away.
  async function submit(when) {
    when = running ? (when === 'now' ? 'now' : 'after') : undefined;
    let text = input.value.trim();
    if (self.stopDictation) self.stopDictation(true); // sending ends the dictation and discards its leftovers
    const withRecording = self.hasRecording && self.hasRecording();
    const withImages = self.hasImages && self.hasImages();
    if (!text && !withRecording && !withImages) return;
    if (!connected) return notice('אין חיבור לגשר שבמחשב.');
    input.value = '';
    autosize();
    const recording = withRecording ? await self.takeRecording() : null;
    const images = withImages ? self.takeImages() : null;
    if (!text) {
      if (recording) text = 'צפה בהקלטה והמשך את התהליך שהראיתי.';
      else if (images) text = images.length > 1 ? 'ראה את התמונות המצורפות.' : 'ראה את התמונה המצורפת.';
      else return;
    }
    const context = await self.currentTabContext();
    send({ type: 'send', text, context, recording, images, when, voice: self.voiceOn ? true : undefined });
  }
  function autosize() {
    input.style.height = 'auto';
    input.style.height = Math.min(input.scrollHeight, 160) + 'px';
  }
  input.addEventListener('input', autosize);
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); submit(e.ctrlKey ? 'now' : 'after'); }
  });
  $('btn-send').onclick = () => submit();
  $('btn-after').onclick = () => { submit('after'); input.focus(); };
  $('btn-now').onclick = () => { submit('now'); input.focus(); };
  $('btn-stop').onclick = () => send({ type: 'stop' });
  $('btn-new').onclick = () => { send({ type: 'new' }); input.focus(); };

  // ----- settings + history sheets -----
  $('btn-settings').onclick = () => { $('history').hidden = true; $('settings').hidden = !$('settings').hidden; applySettings(); };
  $('set-close').onclick = () => { $('settings').hidden = true; };
  $('set-check').onclick = () => send({ type: 'check_update' });
  $('set-save').onclick = () => {
    send({ type: 'settings', cwd: $('set-cwd').value, mode: $('set-mode').value, desktop: $('set-desktop').checked, topmost: $('set-topmost').checked, remote: $('set-remote').checked, autoUpdate: $('set-autoupdate').checked });
    $('settings').hidden = true;
  };
  $('btn-history').onclick = () => {
    $('settings').hidden = true;
    $('history').hidden = !$('history').hidden;
    if (!$('history').hidden) send({ type: 'list' });
  };
  $('history-close').onclick = () => { $('history').hidden = true; };
  $('model').onchange = () => send({ type: 'settings', model: $('model').value }); // applies from the next message
  $('history-current').onclick = () => send({ type: 'resume_external' });
  function renderHistory(items) {
    const list = $('history-list');
    list.replaceChildren();
    if (!items.length) return list.append(el('div', 'hint', 'עוד אין שיחות שמורות.'));
    for (const item of items) {
      const row = el('div', 'hist');
      const date = new Date(item.ts);
      row.append(el('span', 't', item.title), el('span', 'd', `${date.getDate()}.${date.getMonth() + 1} ${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`));
      if (item.sessionId) {
        const ext = el('button', '', '↗');
        ext.title = 'המשך ב-Claude Code הרגיל';
        ext.onclick = (e) => { e.stopPropagation(); send({ type: 'resume_external', id: item.id }); };
        row.append(ext);
      }
      const del = el('button', '', '✕');
      del.title = 'מחק מהרשימה';
      del.onclick = (e) => { e.stopPropagation(); send({ type: 'delete', id: item.id }); };
      row.append(del);
      row.onclick = () => { send({ type: 'open', id: item.id }); $('history').hidden = true; };
      list.append(row);
    }
  }

  // ----- which tab Claude sees -----
  async function refreshTabLine() {
    if (self.PANEL_STANDALONE) { $('tabline').textContent = '🖥 חלון עצמאי – עובד בכל המחשב'; return; }
    const context = await self.currentTabContext();
    $('tabline').textContent = context ? `📄 ${context.title || context.url}` : '';
  }
  if (!self.PANEL_STANDALONE) {
    chrome.tabs.onActivated.addListener(refreshTabLine);
    chrome.tabs.onUpdated.addListener((id, info) => { if (info.title || info.status === 'complete') refreshTabLine(); });
    chrome.windows.onFocusChanged.addListener(refreshTabLine);
  }

  self.Panel = { send, notice, input, autosize, submit, stopSpeech, isRunning: () => running };
  showEmpty();
  refreshTabLine();
  connect();
  input.focus();
})();
