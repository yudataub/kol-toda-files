// The side panel cannot show Chrome's microphone prompt, so the permission is asked once from this tab.
navigator.mediaDevices.getUserMedia({ audio: true }).then((stream) => {
  stream.getTracks().forEach((track) => track.stop());
  document.getElementById('head').textContent = 'המיקרופון אושר ✓';
  document.getElementById('text').textContent = 'אפשר לסגור את הלשונית הזו, לחזור לחלונית וללחוץ שוב על 🎤.';
  setTimeout(() => window.close(), 2500);
}).catch((err) => {
  document.getElementById('head').textContent = 'המיקרופון לא אושר';
  document.getElementById('text').textContent = 'כדי לאשר: לוחצים על סמל המנעול בשורת הכתובת ← מיקרופון ← אפשר, ומרעננים את הדף. (' + err.name + ')';
});
