// Small Markdown renderer for Claude's answers. Everything is HTML-escaped first, so page or
// model text can never inject markup; only the tags written below are ever produced.
(() => {
  const esc = (s) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

  // A bare address (https://...) becomes a link too. Trailing punctuation stays outside it.
  const URL_RE = /https?:\/\/(?:(?!&quot;|&lt;|&gt;)[^\s\u0000\u0001])+/g;
  function linkBare(s, stash) {
    return s.replace(URL_RE, (url) => {
      let tail = '';
      const m = url.match(/(?:[.,;:!?'\]]|&amp;|\))+$/);
      if (m && !(m[0].startsWith(')') && url.includes('('))) { tail = m[0]; url = url.slice(0, -tail.length); }
      return stash(`<a href="${url}" target="_blank" rel="noopener noreferrer">${url}</a>`) + tail;
    });
  }

  function inline(text) {
    const codes = [];
    const keep = [];
    const stash = (html) => { keep.push(html); return `\u0001${keep.length - 1}\u0001`; };
    let s = esc(text).replace(/`([^`\n]+)`/g, (_, c) => { codes.push(c); return `\u0000${codes.length - 1}\u0000`; });
    s = s.replace(/\[([^\]\n]+)\]\(([^)\s]+)\)/g, (m, label, url) => (/^(https?:|mailto:)/i.test(url)
      ? stash(`<a href="${url}" target="_blank" rel="noopener noreferrer">${label}</a>`) : label));
    s = linkBare(s, stash)
      .replace(/\*\*([^*\n]+)\*\*/g, '<b>$1</b>')
      .replace(/(^|[\s(])\*([^*\n]+)\*(?=[\s).,:;!?]|$)/g, '$1<i>$2</i>');
    s = s.replace(/\u0001(\d+)\u0001/g, (_, i) => keep[i]);
    return s.replace(/\u0000(\d+)\u0000/g, (_, i) => `<code>${codes[i]}</code>`);
  }

  // Plain text (a search result preview) with its addresses as links.
  function linkify(text) {
    const keep = [];
    const s = linkBare(esc(String(text)), (html) => { keep.push(html); return `\u0001${keep.length - 1}\u0001`; });
    return s.replace(/\u0001(\d+)\u0001/g, (_, i) => keep[i]);
  }

  function render(src) {
    const lines = String(src).replace(/\r/g, '').split('\n');
    const out = [];
    let i = 0;
    let para = [];
    const flush = () => { if (para.length) { out.push(`<p>${para.map(inline).join('<br>')}</p>`); para = []; } };
    while (i < lines.length) {
      const line = lines[i];
      const fence = line.match(/^\s*```/);
      if (fence) {
        flush();
        const body = [];
        i++;
        while (i < lines.length && !/^\s*```/.test(lines[i])) body.push(lines[i++]);
        i++;
        out.push(`<pre><code>${esc(body.join('\n'))}</code></pre>`);
        continue;
      }
      if (!line.trim()) { flush(); i++; continue; }
      const heading = line.match(/^(#{1,4})\s+(.*)$/);
      if (heading) { flush(); const n = Math.min(heading[1].length, 3); out.push(`<h${n}>${inline(heading[2])}</h${n}>`); i++; continue; }
      if (/^\s*(-{3,}|\*{3,})\s*$/.test(line)) { flush(); out.push('<hr>'); i++; continue; }
      if (/^\s*\|.*\|\s*$/.test(line) && i + 1 < lines.length && /^\s*\|[\s:|-]+\|\s*$/.test(lines[i + 1])) {
        flush();
        const cells = (l) => l.trim().replace(/^\||\|$/g, '').split('|').map((c) => inline(c.trim()));
        let html = `<table><tr>${cells(line).map((c) => `<th>${c}</th>`).join('')}</tr>`;
        i += 2;
        while (i < lines.length && /^\s*\|.*\|\s*$/.test(lines[i])) html += `<tr>${cells(lines[i++]).map((c) => `<td>${c}</td>`).join('')}</tr>`;
        out.push(html + '</table>');
        continue;
      }
      const bullet = /^\s*[-*•]\s+/;
      const numbered = /^\s*\d+[.)]\s+/;
      if (bullet.test(line) || numbered.test(line)) {
        flush();
        const ordered = numbered.test(line);
        const mark = ordered ? numbered : bullet;
        const items = [];
        while (i < lines.length && (mark.test(lines[i]) || (/^\s{2,}\S/.test(lines[i]) && items.length))) {
          if (mark.test(lines[i])) items.push(lines[i].replace(mark, ''));
          else items[items.length - 1] += '\n' + lines[i].trim().replace(/^[-*•]\s+/, '– ');
          i++;
        }
        out.push(`<${ordered ? 'ol' : 'ul'}>${items.map((t) => `<li>${t.split('\n').map(inline).join('<br>')}</li>`).join('')}</${ordered ? 'ol' : 'ul'}>`);
        continue;
      }
      if (/^\s*>\s?/.test(line)) {
        flush();
        const body = [];
        while (i < lines.length && /^\s*>\s?/.test(lines[i])) body.push(lines[i++].replace(/^\s*>\s?/, ''));
        out.push(`<blockquote>${body.map(inline).join('<br>')}</blockquote>`);
        continue;
      }
      para.push(line);
      i++;
    }
    flush();
    return out.join('');
  }

  self.renderMarkdown = render;
  self.linkifyText = linkify;
})();
