// Screen recording (to show Claude a process) and voice dictation.
// A recording is not sent as video: a frame is kept each time the screen changes, and whatever the
// user says meanwhile is transcribed. Claude gets the frames in order plus the transcript.
(() => {
  const P = self.Panel;
  const $ = (id) => document.getElementById(id);
  const micBtn = $('btn-mic');
  const recBtn = $('btn-rec');
  const attach = $('attach');
  const SR = self.SpeechRecognition || self.webkitSpeechRecognition;

  // ---------- speech recognition ----------
  // One recognizer at a time. Chrome ends a session after a pause, so it is restarted while wanted.
  let recognizer = null;
  function listen({ onFinal, onInterim, onStop, quiet }) {
    if (!SR) { if (!quiet) P.notice('הדפדפן הזה לא תומך בזיהוי דיבור.'); return null; }
    let wanted = true;
    const rec = new SR();
    rec.lang = 'he-IL';
    rec.continuous = true;
    rec.interimResults = true;
    rec.onresult = (event) => {
      let interim = '';
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const text = event.results[i][0].transcript;
        if (event.results[i].isFinal) onFinal(text.trim());
        else interim += text;
      }
      if (onInterim) onInterim(interim);
    };
    rec.onerror = (event) => {
      if (event.error === 'no-speech' || event.error === 'aborted') return;
      wanted = false;
      if (quiet) {
        // Narration during a screen recording: never open a tab over what is being recorded.
        if (event.error === 'not-allowed') P.notice('ההקלטה נמשכת בלי דיבור: המיקרופון עוד לא אושר. לאישור לוחצים פעם אחת על 🎤.');
        return;
      }
      if (event.error === 'not-allowed' || event.error === 'service-not-allowed') {
        if (self.PANEL_STANDALONE) {
          P.notice('המיקרופון חסום לחלון הזה. לאישור: סמל המנעול בכותרת החלון ← מיקרופון ← אפשר.');
        } else {
          P.notice('צריך לאשר גישה למיקרופון. נפתח דף אישור – לוחצים שם "אפשר" וחוזרים לכאן.');
          chrome.tabs.create({ url: chrome.runtime.getURL('mic.html') });
        }
      } else if (event.error === 'network') {
        P.notice('זיהוי הדיבור של כרום לא זמין כרגע (אין גישה לשירות הדיבור של גוגל).');
      } else if (event.error === 'audio-capture') {
        P.notice('לא נמצא מיקרופון.');
      } else {
        P.notice('זיהוי הדיבור נעצר: ' + event.error);
      }
    };
    rec.onend = () => {
      if (wanted) { try { rec.start(); return; } catch {} }
      if (recognizer === handle) recognizer = null;
      if (onStop) onStop();
    };
    const handle = { stop() { wanted = false; try { rec.stop(); } catch {} } };
    try { rec.start(); } catch { return null; }
    recognizer = handle;
    return handle;
  }

  // ---------- dictation into the message box ----------
  let dictation = null;
  let dropped = false; // the message was sent: whatever the recognizer still delivers must not come back into the box
  function stopDictation(drop) {
    if (!dictation) return;
    if (drop) dropped = true;
    dictation.stop();
  }
  micBtn.onclick = () => {
    if (dictation) return stopDictation();
    if (recording) return P.notice('בזמן הקלטת מסך הדיבור כבר נרשם כהסבר להקלטה.');
    let base = P.input.value ? P.input.value.replace(/\s*$/, ' ') : '';
    dropped = false;
    dictation = listen({
      onFinal: (text) => { if (dropped) return; base += text + ' '; P.input.value = base; P.autosize(); },
      onInterim: (text) => { if (dropped) return; P.input.value = base + text; P.autosize(); },
      onStop: () => {
        dictation = null;
        micBtn.classList.remove('active');
        micBtn.title = 'הכתבה בקול';
        if (!dropped) { P.input.value = base.trimEnd(); P.autosize(); }
      },
    });
    if (dictation) { micBtn.classList.add('active'); micBtn.title = 'מקשיב. לחיצה מפסיקה'; }
  };

  // ---------- screen recording ----------
  const MAX_FRAMES = 60;
  let recording = null; // { stream, video, timer, clock, frames, narration, start, lastThumb, minGap, speech }
  let attached = null;  // { id, count, seconds } once the bridge saved it; { pending: Promise } while uploading
  let savedResolve = null;

  const thumbCanvas = new OffscreenCanvas(160, 90);
  const thumbCtx = thumbCanvas.getContext('2d', { willReadFrequently: true });
  function changedPixels(video, state) {
    thumbCtx.drawImage(video, 0, 0, 160, 90);
    const now = thumbCtx.getImageData(0, 0, 160, 90).data;
    let changed = 0;
    if (state.lastThumb) {
      for (let i = 0; i < now.length; i += 4) {
        if (Math.abs(now[i] - state.lastThumb[i]) + Math.abs(now[i + 1] - state.lastThumb[i + 1]) + Math.abs(now[i + 2] - state.lastThumb[i + 2]) > 40) changed++;
      }
    } else changed = Infinity;
    return { changed, now };
  }
  function grab(video) {
    const scale = Math.min(1, 1280 / video.videoWidth);
    const canvas = document.createElement('canvas');
    canvas.width = Math.round(video.videoWidth * scale);
    canvas.height = Math.round(video.videoHeight * scale);
    canvas.getContext('2d').drawImage(video, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL('image/jpeg', 0.6).split(',')[1];
  }
  function sample(force) {
    const r = recording;
    if (!r || !r.video.videoWidth) return;
    const t = (Date.now() - r.start) / 1000;
    const { changed, now } = changedPixels(r.video, r);
    const sinceLast = r.frames.length ? t - r.frames[r.frames.length - 1].t : Infinity;
    // A clear change is kept at once; a small one (a few typed letters) only after a short wait.
    const keep = force ? changed > 0 : sinceLast >= r.minGap && (changed >= 12 || (changed >= 2 && sinceLast >= 1.5));
    if (!keep) return;
    r.lastThumb = now;
    r.frames.push({ t, data: grab(r.video) });
    if (r.frames.length > MAX_FRAMES) {
      // Long recording: keep every second frame and sample less densely from here on.
      r.frames = r.frames.filter((_, i) => i % 2 === 0);
      r.minGap *= 2;
    }
  }
  function showClock() {
    if (!recording) return;
    const s = Math.floor((Date.now() - recording.start) / 1000);
    recBtn.textContent = `⏹ ${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
  }

  async function startRecording() {
    let stream;
    try {
      stream = await navigator.mediaDevices.getDisplayMedia({ video: { frameRate: 5, cursor: 'always' }, audio: false });
    } catch (err) {
      if (err.name !== 'NotAllowedError') P.notice('לא הצלחתי להתחיל הקלטה: ' + err.message);
      return;
    }
    stopDictation();
    clearAttached();
    const video = document.createElement('video');
    video.muted = true;
    video.srcObject = stream;
    await video.play();
    recording = { stream, video, frames: [], narration: [], start: Date.now(), lastThumb: null, minGap: 0.7 };
    recording.timer = setInterval(() => sample(false), 700);
    recording.clock = setInterval(showClock, 500);
    stream.getVideoTracks()[0].addEventListener('ended', stopRecording);
    if (SR) {
      const r = recording;
      r.speech = listen({ quiet: true, onFinal: (text) => { if (text) r.narration.push({ t: (Date.now() - r.start) / 1000, text }); } });
    }
    recBtn.classList.add('active');
    recBtn.title = 'עצור הקלטה';
    showClock();
    setTimeout(() => sample(false), 300);
  }

  function stopRecording() {
    const r = recording;
    if (!r) return;
    sample(true);
    recording = null;
    clearInterval(r.timer);
    clearInterval(r.clock);
    if (r.speech) r.speech.stop();
    r.stream.getTracks().forEach((track) => track.stop());
    recBtn.classList.remove('active');
    recBtn.textContent = '🎬';
    recBtn.title = 'הקלטת מסך: להראות ל-Claude תהליך';
    const seconds = (Date.now() - r.start) / 1000;
    if (!r.frames.length) return P.notice('ההקלטה יצאה ריקה.');
    showAttached(`🎬 שומר הקלטה (${r.frames.length} תמונות)…`, false);
    const pending = new Promise((resolve) => { savedResolve = resolve; });
    attached = { pending };
    // Give the last spoken words a moment to arrive before sending.
    setTimeout(() => P.send({ type: 'recording', frames: r.frames, narration: r.narration, seconds }), r.speech ? 900 : 0);
  }
  recBtn.onclick = () => (recording ? stopRecording() : startRecording());

  function showAttached(text, removable) {
    attach.hidden = false;
    attach.replaceChildren(document.createTextNode(text));
    if (removable) {
      const x = document.createElement('button');
      x.textContent = '✕';
      x.title = 'הסר את ההקלטה';
      x.onclick = clearAttached;
      attach.append(x);
    }
  }
  function clearAttached() {
    attached = null;
    attach.hidden = true;
    attach.replaceChildren();
  }

  self.onRecordingSaved = (msg) => {
    if (msg.error) {
      clearAttached();
      P.notice('שמירת ההקלטה נכשלה: ' + msg.error);
      if (savedResolve) savedResolve(null);
    } else {
      attached = { id: msg.id, count: msg.count, seconds: msg.seconds };
      showAttached(`🎬 הקלטה מצורפת: ${msg.count} תמונות, ${msg.seconds} שניות. כתוב מה לעשות ושלח.`, true);
      if (savedResolve) savedResolve(attached);
    }
    savedResolve = null;
  };
  // Used by panel.js when sending: returns the attached recording's id (waits if it is still uploading).
  self.takeRecording = async () => {
    if (recording) stopRecording();
    if (!attached) return null;
    const ready = attached.pending ? await attached.pending : attached;
    clearAttached();
    return ready ? ready.id : null;
  };
  self.hasRecording = () => !!(attached || recording);
  self.stopDictation = stopDictation;
})();
