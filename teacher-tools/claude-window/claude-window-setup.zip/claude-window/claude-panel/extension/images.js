// Pictures attached to a message: the 📎 button, paste (Ctrl+V) or drag and drop.
// Each picture is shrunk here before it is sent (Claude does not need more than ~1568 px), plus a small
// thumbnail that stays in the conversation so the message still shows what was attached.
(() => {
  const P = self.Panel;
  const $ = (id) => document.getElementById(id);
  const box = $('pics');
  const picker = $('pic-file');
  const MAX = 8;
  let items = []; // { data (base64 jpeg), thumb (data url) }

  async function add(blob) {
    if (!blob || !String(blob.type).startsWith('image/')) return;
    if (items.length >= MAX) return P.notice(`אפשר לצרף עד ${MAX} תמונות להודעה.`);
    let bitmap;
    try { bitmap = await createImageBitmap(blob); } catch { return P.notice('לא הצלחתי לקרוא את התמונה.'); }
    const jpeg = (longest, quality) => {
      const scale = Math.min(1, longest / Math.max(bitmap.width, bitmap.height));
      const canvas = document.createElement('canvas');
      canvas.width = Math.max(1, Math.round(bitmap.width * scale));
      canvas.height = Math.max(1, Math.round(bitmap.height * scale));
      const ctx = canvas.getContext('2d');
      ctx.fillStyle = '#fff'; // transparent PNG areas would turn black in JPEG
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
      return canvas.toDataURL('image/jpeg', quality);
    };
    items.push({ data: jpeg(1568, 0.85).split(',')[1], thumb: jpeg(160, 0.7) });
    render();
  }

  function render() {
    box.hidden = !items.length;
    box.replaceChildren();
    items.forEach((item, index) => {
      const wrap = document.createElement('span');
      wrap.className = 'pic';
      const img = document.createElement('img');
      img.src = item.thumb;
      img.alt = 'תמונה מצורפת';
      const remove = document.createElement('button');
      remove.textContent = '✕';
      remove.title = 'הסר את התמונה';
      remove.onclick = () => { items.splice(index, 1); render(); };
      wrap.append(img, remove);
      box.append(wrap);
    });
  }

  $('btn-pic').onclick = () => picker.click();
  picker.onchange = async () => {
    for (const file of picker.files) await add(file);
    picker.value = '';
  };
  document.addEventListener('paste', (event) => {
    const files = [...((event.clipboardData && event.clipboardData.items) || [])]
      .filter((i) => i.kind === 'file' && i.type.startsWith('image/')).map((i) => i.getAsFile());
    if (!files.length) return; // ordinary text paste
    event.preventDefault();
    files.forEach(add);
  });
  document.addEventListener('dragover', (event) => {
    if ([...(event.dataTransfer?.types || [])].includes('Files')) event.preventDefault();
  });
  document.addEventListener('drop', (event) => {
    const files = [...(event.dataTransfer?.files || [])].filter((f) => f.type.startsWith('image/'));
    if (!files.length) return;
    event.preventDefault();
    files.forEach(add);
  });

  self.hasImages = () => items.length > 0;
  self.takeImages = () => {
    const out = items;
    items = [];
    render();
    return out;
  };
})();
