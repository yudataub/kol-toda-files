// A voice conversation: the user talks, a pause sends what was said, and Claude's answer is read aloud.
// Then it listens again. Built from the parts that already exist: the recognizer (recorder.js) and 🔊 (panel.js).
(() => {
  const P = self.Panel;
  const $ = (id) => document.getElementById(id);
  const btn = $('btn-voice');
  const bar = $('voicebar');
  const PAUSE_MS = 1800; // this much silence after speech means "I finished talking"
  let state = 'off'; // off | listening | thinking | speaking
  let rec = null;
  let heard = '';
  let interim = '';
  let timer = null;

  function show(text) { bar.hidden = state === 'off'; bar.querySelector('span').textContent = text; }
  function arm() { clearTimeout(timer); timer = setTimeout(sendHeard, PAUSE_MS); }

  function startListening() {
    if (state === 'off' || rec) return;
    if (P.isRunning()) { state = 'thinking'; return show('Claude עובד…'); }
    heard = '';
    interim = '';
    const mine = self.panelListen({
      onFinal: (text) => { if (rec !== mine) return; heard += text + ' '; interim = ''; P.input.value = heard; P.autosize(); arm(); },
      onInterim: (text) => { if (rec !== mine) return; interim = text; P.input.value = heard + text; P.autosize(); if (text) arm(); },
      onStop: () => { if (rec === mine) { rec = null; if (state === 'listening') stop(); } }, // the microphone failed: the notice is already shown
    });
    if (!mine) return stop();
    rec = mine;
    state = 'listening';
    show('🎤 מקשיב. דבר, וכשתשתוק ההודעה תישלח');
  }
  function stopListening() {
    clearTimeout(timer);
    const r = rec;
    rec = null;
    if (r) r.stop();
  }
  function sendHeard() {
    const text = (heard + interim).trim();
    if (state !== 'listening' || !text) return;
    stopListening();
    state = 'thinking';
    show('Claude חושב…');
    P.input.value = text;
    P.submit();
  }

  // The turn ended: read the answer, then listen again.
  self.onTurnEnd = (answer) => {
    if (state === 'off') return;
    stopListening();
    const button = answer && answer.node.isConnected ? answer.node.querySelector('button.speak') : null;
    if (!button) { state = 'thinking'; return startListening(); }
    state = 'speaking';
    show('🔊 Claude עונה. ⏹ ליד התשובה מפסיק ומקשיב שוב');
    button.click();
  };
  self.onSpeechEnd = (reason) => {
    if (state !== 'speaking' || reason === 'error') return;
    state = 'thinking';
    setTimeout(startListening, 300); // not at once, so the end of the answer is not heard as speech
  };
  // Gemini's voice is not available (no keys, quota): the browser's own Hebrew voice, when it has one.
  let warned = false;
  self.onSpeechFail = (text, error) => {
    if (state !== 'speaking') return false;
    const synth = self.speechSynthesis;
    const voice = synth ? synth.getVoices().find((v) => /^he|^iw/i.test(v.lang)) : null;
    if (!voice) {
      if (!warned) { warned = true; P.notice('אי אפשר להקריא את התשובה (' + error + '). השיחה ממשיכה: אתה מדבר, והתשובה כתובה.'); }
      state = 'thinking';
      setTimeout(startListening, 300);
      return true;
    }
    const say = new SpeechSynthesisUtterance(String(text).replace(/```[\s\S]*?```/g, ' ').replace(/https?:\/\/\S+/g, ' ').replace(/[*_#`>|]/g, ' '));
    say.voice = voice;
    say.lang = voice.lang;
    say.onend = say.onerror = () => { if (state === 'speaking') { state = 'thinking'; setTimeout(startListening, 300); } };
    synth.speak(say);
    return true;
  };

  function start() {
    if (self.stopDictation) self.stopDictation(true);
    self.voiceOn = true;
    state = 'thinking';
    btn.classList.add('active');
    btn.title = 'שיחה בקול פעילה. לחיצה מסיימת';
    startListening();
  }
  function stop() {
    if (state === 'off') return;
    state = 'off';
    self.voiceOn = false;
    stopListening();
    P.stopSpeech();
    if (self.speechSynthesis) self.speechSynthesis.cancel();
    btn.classList.remove('active');
    btn.title = 'שיחה בקול: מדברים, ו-Claude עונה בקול';
    show('');
  }
  btn.onclick = () => (state === 'off' ? start() : stop());
  $('voice-stop').onclick = stop;
})();
