// The browser tools Claude can call. They run here, in the panel page, and reach into tabs
// with chrome.scripting. Functions passed to executeScript run inside the page and must be self-contained.
(() => {
  // Standalone window (served by the bridge, not an extension): there are no tabs to reach into.
  if (!(self.chrome && chrome.scripting && chrome.tabs)) {
    self.PANEL_STANDALONE = true;
    self.runBrowserTool = async () => ({ ok: false, error: 'כלי הדפדפן (browser_*) עובדים רק מהחלונית שבתוך כרום. בחלון העצמאי משתמשים בכלי desktop_* או בפקודות.' });
    self.currentTabContext = async () => null;
    return;
  }
  const MAX_TEXT = 30000;

  async function targetTab(tabId) {
    if (typeof tabId === 'number') return chrome.tabs.get(tabId);
    const [active] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (active && !isOwnPage(active.url)) return active;
    // The panel is open as a full tab (testing): use the most recently used ordinary tab.
    const all = (await chrome.tabs.query({})).filter((t) => !isOwnPage(t.url));
    all.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0));
    if (!all.length) throw new Error('אין לשונית פתוחה לפעול בה');
    return all[0];
  }
  function isOwnPage(url) {
    return !url || url.startsWith(`chrome-extension://${chrome.runtime.id}/`);
  }
  async function inPage(tab, func, args = []) {
    let results;
    try {
      results = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func, args });
    } catch (err) {
      throw new Error(`אי אפשר לגשת לדף הזה (${tab.url || 'דף פנימי'}): ${err.message}`);
    }
    const value = results && results[0] ? results[0].result : null;
    if (value && value.__error) throw new Error(value.__error);
    return value;
  }
  function waitForLoad(tabId, timeoutMs = 25000) {
    return new Promise((resolve) => {
      let sawLoading = false;
      const done = () => { chrome.tabs.onUpdated.removeListener(listener); clearTimeout(timer); clearTimeout(early); resolve(); };
      const listener = (id, info) => {
        if (id !== tabId) return;
        if (info.status === 'loading') sawLoading = true;
        if (info.status === 'complete') done();
      };
      const timer = setTimeout(done, timeoutMs);
      // Same-page navigation (hash, history.pushState) never reports "loading".
      const early = setTimeout(() => { if (!sawLoading) done(); }, 1500);
      chrome.tabs.onUpdated.addListener(listener);
    });
  }

  // ----- functions injected into the page -----
  function pageRead() {
    const sel = String(window.getSelection ? window.getSelection() : '');
    return { url: location.href, title: document.title, selection: sel, text: document.body ? document.body.innerText : '' };
  }
  function pageSnapshot(filter) {
    const query = 'a[href],button,input,textarea,select,summary,label[for],[role=button],[role=link],[role=tab],[role=menuitem],[role=option],[role=checkbox],[role=radio],[role=switch],[role=combobox],[role=textbox],[role=searchbox],[contenteditable=""],[contenteditable=true],[onclick]';
    const refs = [];
    const lines = [];
    const clean = (s) => String(s || '').replace(/\s+/g, ' ').trim().slice(0, 90);
    for (const el of document.querySelectorAll(query)) {
      const rect = el.getBoundingClientRect();
      if (rect.width < 2 || rect.height < 2) continue;
      const style = getComputedStyle(el);
      if (style.visibility === 'hidden' || style.display === 'none' || el.disabled) continue;
      if (el.type === 'hidden') continue;
      const tag = el.tagName.toLowerCase();
      let label = clean(el.getAttribute('aria-label')) || clean(el.innerText) || clean(el.placeholder) || clean(el.title)
        || clean(el.querySelector && el.querySelector('img[alt]') && el.querySelector('img[alt]').alt) || clean(el.name) || clean(el.id);
      if ((tag === 'input' || tag === 'textarea' || tag === 'select') && el.labels && el.labels[0]) label = clean(el.labels[0].innerText) || label;
      if (filter && !label.toLowerCase().includes(String(filter).toLowerCase())) continue;
      let kind = tag;
      if (tag === 'input') kind = 'input:' + (el.type || 'text');
      else if (el.getAttribute('role')) kind = tag + '[' + el.getAttribute('role') + ']';
      let line = `[${refs.length}] ${kind} "${label}"`;
      if (tag === 'input' || tag === 'textarea') {
        if (el.type === 'checkbox' || el.type === 'radio') line += el.checked ? ' (מסומן)' : ' (לא מסומן)';
        else if (el.type !== 'password' && el.value) line += ` value="${clean(el.value)}"`;
      } else if (tag === 'select') {
        line += ` value="${clean(el.selectedOptions[0] && el.selectedOptions[0].text)}" options: ${[...el.options].slice(0, 25).map((o) => clean(o.text)).join(' | ')}`;
      } else if (tag === 'a') {
        const href = el.getAttribute('href') || '';
        if (href && !href.startsWith('javascript:')) line += ' → ' + href.slice(0, 100);
      }
      const inView = rect.bottom > 0 && rect.top < innerHeight;
      if (!inView) line += ' (מחוץ למסך)';
      refs.push(el);
      lines.push(line);
      if (refs.length >= 400) { lines.push('... (יש עוד רכיבים; השתמש ב-filter כדי לצמצם)'); break; }
    }
    window.__claudePanelRefs = refs;
    return { url: location.href, title: document.title, lines };
  }
  function pageClick(ref) {
    const el = (window.__claudePanelRefs || [])[ref];
    if (!el || !el.isConnected) return { __error: 'הרכיב כבר לא קיים בדף. צריך browser_snapshot חדש.' };
    el.scrollIntoView({ block: 'center', inline: 'center' });
    const rect = el.getBoundingClientRect();
    const opts = { bubbles: true, cancelable: true, view: window, clientX: rect.left + rect.width / 2, clientY: rect.top + rect.height / 2, button: 0 };
    for (const type of ['pointerdown', 'mousedown', 'pointerup', 'mouseup']) {
      el.dispatchEvent(new (type.startsWith('pointer') ? PointerEvent : MouseEvent)(type, opts));
    }
    if (el.focus) el.focus();
    el.click();
    return { ok: true, label: String(el.innerText || el.value || el.getAttribute('aria-label') || '').trim().slice(0, 80) };
  }
  function pageType(ref, text, append, enter) {
    const el = (window.__claudePanelRefs || [])[ref];
    if (!el || !el.isConnected) return { __error: 'הרכיב כבר לא קיים בדף. צריך browser_snapshot חדש.' };
    el.scrollIntoView({ block: 'center' });
    el.focus();
    const tag = el.tagName.toLowerCase();
    if (tag === 'select') {
      const wanted = text.trim().toLowerCase();
      const option = [...el.options].find((o) => o.text.trim().toLowerCase() === wanted || o.value.toLowerCase() === wanted)
        || [...el.options].find((o) => o.text.toLowerCase().includes(wanted));
      if (!option) return { __error: 'אין ברשימה אפשרות בשם הזה' };
      el.value = option.value;
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      return { ok: true };
    }
    if (tag === 'input' && (el.type === 'checkbox' || el.type === 'radio')) {
      const want = !/^(false|0|no|off|לא)$/i.test(text.trim());
      if (el.checked !== want) el.click();
      return { ok: true };
    }
    if (tag === 'input' || tag === 'textarea') {
      const proto = tag === 'input' ? HTMLInputElement.prototype : HTMLTextAreaElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, 'value').set; // goes around React's value tracking
      setter.call(el, append ? el.value + text : text);
      el.dispatchEvent(new InputEvent('input', { bubbles: true, data: text, inputType: 'insertText' }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
    } else if (el.isContentEditable) {
      if (!append) {
        const range = document.createRange();
        range.selectNodeContents(el);
        const sel = getSelection();
        sel.removeAllRanges();
        sel.addRange(range);
      }
      document.execCommand('insertText', false, text);
    } else {
      return { __error: 'אי אפשר להקליד ברכיב הזה' };
    }
    if (enter) {
      const key = { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true };
      const notPrevented = el.dispatchEvent(new KeyboardEvent('keydown', key));
      el.dispatchEvent(new KeyboardEvent('keypress', key));
      el.dispatchEvent(new KeyboardEvent('keyup', key));
      if (notPrevented && el.form && tag === 'input') el.form.requestSubmit ? el.form.requestSubmit() : el.form.submit();
    }
    return { ok: true };
  }
  function pageScroll(direction, ref) {
    if (typeof ref === 'number') {
      const el = (window.__claudePanelRefs || [])[ref];
      if (!el || !el.isConnected) return { __error: 'הרכיב כבר לא קיים בדף. צריך browser_snapshot חדש.' };
      el.scrollIntoView({ block: 'center' });
    } else if (direction === 'top') scrollTo(0, 0);
    else if (direction === 'bottom') scrollTo(0, document.documentElement.scrollHeight);
    else scrollBy(0, (direction === 'up' ? -1 : 1) * innerHeight * 0.85);
    return { y: Math.round(scrollY), height: document.documentElement.scrollHeight, view: innerHeight };
  }

  async function shrink(dataUrl, maxWidth) {
    const img = await createImageBitmap(await (await fetch(dataUrl)).blob());
    const scale = Math.min(1, maxWidth / img.width);
    const canvas = new OffscreenCanvas(Math.round(img.width * scale), Math.round(img.height * scale));
    canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height);
    const blob = await canvas.convertToBlob({ type: 'image/jpeg', quality: 0.7 });
    const bytes = new Uint8Array(await blob.arrayBuffer());
    let binary = '';
    for (let i = 0; i < bytes.length; i += 0x8000) binary += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
    return btoa(binary);
  }

  // ----- the tools -----
  const tools = {
    async tabs() {
      const [active] = await chrome.tabs.query({ active: true, currentWindow: true });
      const all = (await chrome.tabs.query({})).filter((t) => !isOwnPage(t.url));
      return { text: all.map((t) => `${t.id}${active && t.id === active.id ? ' (פעילה)' : ''} | ${t.title} | ${t.url}`).join('\n') || 'אין לשוניות' };
    },
    async read({ tabId, offset = 0 }) {
      const tab = await targetTab(tabId);
      const page = await inPage(tab, pageRead);
      const part = page.text.slice(offset, offset + MAX_TEXT);
      let text = `url: ${page.url}\ntitle: ${page.title}\n`;
      if (page.selection) text += `selected text: ${page.selection.slice(0, 4000)}\n`;
      text += `\n${part}`;
      if (offset + MAX_TEXT < page.text.length) text += `\n\n[הדף ממשיך: ${page.text.length} תווים בסך הכול. להמשך: offset=${offset + MAX_TEXT}]`;
      return { text };
    },
    async snapshot({ tabId, filter }) {
      const tab = await targetTab(tabId);
      const page = await inPage(tab, pageSnapshot, [filter || '']);
      return { text: `url: ${page.url}\ntitle: ${page.title}\n\n${page.lines.join('\n') || 'לא נמצאו רכיבים לפעולה'}` };
    },
    async click({ tabId, ref }) {
      const tab = await targetTab(tabId);
      const res = await inPage(tab, pageClick, [ref]);
      await waitForLoad(tab.id, 10000);
      const now = await chrome.tabs.get(tab.id);
      return { text: `נלחץ: "${res.label}". הדף עכשיו: ${now.url}` };
    },
    async type({ tabId, ref, text, append = false, enter = false }) {
      const tab = await targetTab(tabId);
      await inPage(tab, pageType, [ref, text, append, enter]);
      if (enter) await waitForLoad(tab.id, 10000);
      return { text: 'הוקלד' };
    },
    async navigate({ tabId, url, newTab = false }) {
      let tab;
      if (url === 'back' || url === 'forward' || url === 'reload') {
        tab = await targetTab(tabId);
        const wait = waitForLoad(tab.id);
        if (url === 'back') await chrome.tabs.goBack(tab.id);
        else if (url === 'forward') await chrome.tabs.goForward(tab.id);
        else await chrome.tabs.reload(tab.id);
        await wait;
      } else {
        if (!/^[a-z][a-z0-9+.-]*:/i.test(url)) url = 'https://' + url;
        if (!/^(https?|file):/i.test(url)) throw new Error('אפשר לפתוח רק כתובות http, https או file');
        if (newTab) {
          tab = await chrome.tabs.create({ url, active: true });
          await waitForLoad(tab.id);
        } else {
          tab = await targetTab(tabId);
          const wait = waitForLoad(tab.id);
          await chrome.tabs.update(tab.id, { url });
          await wait;
        }
      }
      const now = await chrome.tabs.get(tab.id);
      return { text: `tab ${now.id} | ${now.title} | ${now.url}` };
    },
    async scroll({ tabId, direction = 'down', ref }) {
      const tab = await targetTab(tabId);
      const pos = await inPage(tab, pageScroll, [direction, typeof ref === 'number' ? ref : null]);
      return { text: `מיקום הגלילה: ${pos.y} מתוך ${pos.height} (גובה חלון ${pos.view})` };
    },
    async screenshot({ tabId }) {
      const tab = await targetTab(tabId);
      if (!tab.active) {
        await chrome.tabs.update(tab.id, { active: true });
        await new Promise((r) => setTimeout(r, 400));
      }
      const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'jpeg', quality: 80 });
      return { text: `צילום של: ${tab.url}`, image: await shrink(dataUrl, 1280) };
    },
  };

  self.runBrowserTool = async (name, args) => {
    if (!tools[name]) return { ok: false, error: 'כלי לא מוכר: ' + name };
    try {
      return { ok: true, ...(await tools[name](args || {})) };
    } catch (err) {
      return { ok: false, error: String(err.message || err) };
    }
  };
  self.currentTabContext = async () => {
    try {
      const tab = await targetTab();
      let selection = '';
      try { selection = (await inPage(tab, () => String(getSelection()))) || ''; } catch {}
      return { title: tab.title, url: tab.url, selection };
    } catch {
      return null;
    }
  };
})();
