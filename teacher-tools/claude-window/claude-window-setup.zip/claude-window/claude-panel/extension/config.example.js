// install.mjs writes the real config.js (with this computer's secret token) into the installed copy.
// config.js is not kept in git.
self.PANEL_CONFIG = { port: 5199, token: 'REPLACED-BY-INSTALL' };
