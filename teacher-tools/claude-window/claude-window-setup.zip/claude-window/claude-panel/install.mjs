// Installs (or updates) the Claude panel on this computer:
//   bridge    -> %USERPROFILE%\claude-panel-bridge   (runs at login, hidden)
//   extension -> %USERPROFILE%\ChromeExtensions\claude-panel   (load it once in chrome://extensions)
// usage: node install.mjs [--no-startup] [--no-restart]
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import crypto from 'node:crypto';
import { execFileSync, spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const HOME = os.homedir();
const BRIDGE = path.join(HOME, 'claude-panel-bridge');
const EXT = path.join(HOME, 'ChromeExtensions', 'claude-panel');
const STARTUP = path.join(process.env.APPDATA, 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup');
const PORT = 5199;
const args = new Set(process.argv.slice(2));

const manifest = JSON.parse(fs.readFileSync(path.join(HERE, 'extension', 'manifest.json'), 'utf8'));
// Chrome derives the extension id from the public key in the manifest.
const extensionId = [...crypto.createHash('sha256').update(Buffer.from(manifest.key, 'base64')).digest('hex').slice(0, 32)]
  .map((h) => String.fromCharCode(97 + parseInt(h, 16))).join('');

// ---- bridge ----
fs.mkdirSync(BRIDGE, { recursive: true });
const configFile = path.join(BRIDGE, 'config.json');
let config = {};
try { config = JSON.parse(fs.readFileSync(configFile, 'utf8')); } catch {}
config = {
  port: PORT,
  token: config.token || crypto.randomBytes(32).toString('hex'),
  extensionId,
  defaultCwd: config.defaultCwd || (!args.has('--safe-defaults') && fs.existsSync('C:\\YUDA') ? 'C:\\YUDA' : HOME),
  python: config.python || findPython(),
  claude: config.claude || findClaude(),
  // --safe-defaults (the public package): ask before every change, and no mouse/keyboard control until switched on.
  ...(config.defaults || args.has('--safe-defaults') ? { defaults: config.defaults || { mode: 'ask', desktop: false, remote: false } } : {}),
};
function findClaude() {
  try {
    const found = execFileSync('where', ['claude'], { encoding: 'utf8' }).split(/\r?\n/).map((s) => s.trim()).filter(Boolean);
    return found.find((p) => /\.exe$/i.test(p)) || found.find((p) => /\.cmd$/i.test(p)) || 'claude';
  } catch { return 'claude'; }
}
// The bridge starts at login with a minimal environment, so remember where python is (for desktop.py).
function findPython() {
  try {
    const found = execFileSync('where', ['python'], { encoding: 'utf8' }).split(/\r?\n/).map((s) => s.trim())
      .find((p) => p && !p.includes('WindowsApps'));
    return found || 'python';
  } catch { return 'python'; }
}
fs.writeFileSync(configFile, JSON.stringify(config, null, 1));
const lockBefore = fs.existsSync(path.join(BRIDGE, 'package-lock.json')) ? fs.readFileSync(path.join(BRIDGE, 'package-lock.json'), 'utf8') : '';
for (const name of ['server.mjs', 'desktop.py', 'topmost.py', 'package.json', 'package-lock.json']) {
  fs.copyFileSync(path.join(HERE, 'bridge', name), path.join(BRIDGE, name));
}
const lockAfter = fs.readFileSync(path.join(BRIDGE, 'package-lock.json'), 'utf8');
if (lockBefore !== lockAfter || !fs.existsSync(path.join(BRIDGE, 'node_modules', 'ws'))) {
  console.log('מתקין את רכיבי הגשר (npm ci)...');
  execFileSync('cmd.exe', ['/c', 'npm', 'ci', '--omit=dev', '--no-audit', '--no-fund'], { cwd: BRIDGE, stdio: 'inherit' });
}
const vbs = `CreateObject("WScript.Shell").Run """${process.execPath}"" ""${path.join(BRIDGE, 'server.mjs')}""", 0, False\r\n`;
const startVbs = path.join(BRIDGE, 'Claude Panel Bridge.vbs');
fs.writeFileSync(startVbs, vbs, 'ascii');
if (!args.has('--no-startup')) fs.writeFileSync(path.join(STARTUP, 'Claude Panel Bridge.vbs'), vbs, 'ascii');

// ---- extension ----
fs.mkdirSync(EXT, { recursive: true });
fs.cpSync(path.join(HERE, 'extension'), EXT, { recursive: true });
fs.writeFileSync(path.join(EXT, 'config.js'), `self.PANEL_CONFIG = ${JSON.stringify({ port: PORT, token: config.token })};\n`);

// ---- standalone window: the same panel page, served by the bridge and opened with chrome --app ----
fs.cpSync(path.join(HERE, 'extension'), path.join(BRIDGE, 'app'), { recursive: true });
fs.rmSync(path.join(BRIDGE, 'app', 'config.js'), { force: true }); // the bridge serves its own config.js
const browser = [
  path.join(process.env.PROGRAMFILES || '', 'Google', 'Chrome', 'Application', 'chrome.exe'),
  path.join(process.env['PROGRAMFILES(X86)'] || '', 'Google', 'Chrome', 'Application', 'chrome.exe'),
  path.join(process.env.LOCALAPPDATA || '', 'Google', 'Chrome', 'Application', 'chrome.exe'),
  path.join(process.env['PROGRAMFILES(X86)'] || '', 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
].find((p) => fs.existsSync(p));
const windowVbs = path.join(BRIDGE, 'Claude Window.vbs');
if (browser) {
  fs.writeFileSync(windowVbs, [
    'Set sh = CreateObject("WScript.Shell")',
    `sh.Run """${process.execPath}"" ""${path.join(BRIDGE, 'server.mjs')}""", 0, False`, // exits by itself if already running
    'WScript.Sleep 1500',
    `sh.Run """${browser}"" --app=http://127.0.0.1:${PORT}/app/panel.html --window-size=470,860", 1, False`,
    '',
  ].join('\r\n'), 'ascii');
  if (!args.has('--no-shortcut')) {
    // Shortcuts on the Desktop and in the Start menu. Encoded so the Hebrew name survives any console codepage.
    const ps = `
      $sh = New-Object -ComObject WScript.Shell
      foreach ($dir in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {
        $lnk = $sh.CreateShortcut((Join-Path $dir 'Claude במחשב שלי.lnk'))
        $lnk.TargetPath = "$env:WINDIR\\System32\\wscript.exe"
        $lnk.Arguments = '"${windowVbs}"'
        $lnk.IconLocation = '${path.join(BRIDGE, 'app', 'icons', 'icon.ico')}'
        $lnk.Description = 'Claude Code in a window'
        $lnk.Save()
      }`;
    try {
      execFileSync('powershell.exe', ['-NoProfile', '-EncodedCommand', Buffer.from(ps, 'utf16le').toString('base64')], { stdio: 'ignore' });
    } catch (err) { console.log('לא הצלחתי ליצור קיצור דרך: ' + err.message); }
  }
}

// ---- restart the bridge so it runs the new code ----
let busy = false;
try { busy = (await (await fetch(`http://127.0.0.1:${PORT}/status`, { signal: AbortSignal.timeout(2000) })).json()).running === true; } catch {}
if (busy) console.log('⚠ הגשר באמצע משימה ולכן לא הופעל מחדש. הקוד החדש ייכנס לתוקף אחרי הרצה נוספת של install.mjs.');
if (!args.has('--no-restart') && !busy) {
  try {
    const out = execFileSync('netstat', ['-ano', '-p', 'TCP'], { encoding: 'utf8' });
    const pids = new Set();
    for (const line of out.split('\n')) {
      const m = line.match(new RegExp(`127\\.0\\.0\\.1:${PORT}\\s+\\S+\\s+LISTENING\\s+(\\d+)`));
      if (m) pids.add(m[1]);
    }
    for (const pid of pids) execFileSync('taskkill', ['/PID', pid, '/T', '/F'], { stdio: 'ignore' }); // /T: also the open Claude session it holds
  } catch {}
  spawn('wscript.exe', [startVbs], { detached: true, stdio: 'ignore' }).unref();
}

console.log('הגשר:   ' + BRIDGE);
console.log('התוסף:  ' + EXT);
console.log('מזהה התוסף: ' + extensionId);
console.log(browser ? 'חלון עצמאי: קיצור "Claude במחשב שלי" בשולחן העבודה ובתפריט התחל' : 'חלון עצמאי: לא נמצא כרום או Edge');
console.log(args.has('--no-startup') ? 'הפעלה אוטומטית בכניסה: לא הוגדרה' : 'הפעלה אוטומטית בכניסה: הוגדרה (תיקיית Startup)');
