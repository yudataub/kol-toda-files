# Keeps the standalone Claude window above every other window.
#   python topmost.py watch <bridge-pid>   re-applies "always on top" every second, exits when the bridge exits
#   python topmost.py off                  removes "always on top" from the window
import ctypes
import sys
import time
from ctypes import wintypes

TITLE = "Claude במחשב שלי"  # the panel page's <title>; a chrome --app window shows exactly it
user32 = ctypes.windll.user32
kernel32 = ctypes.windll.kernel32
GWL_EXSTYLE, WS_EX_TOPMOST = -20, 0x8
SWP_NOSIZE, SWP_NOMOVE, SWP_NOACTIVATE = 0x1, 0x2, 0x10
EnumProc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
user32.SetWindowPos.argtypes = [wintypes.HWND, wintypes.HWND, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, wintypes.UINT]


def windows():
    found = []

    def visit(hwnd, _):
        if user32.IsWindowVisible(hwnd):
            title = ctypes.create_unicode_buffer(200)
            user32.GetWindowTextW(hwnd, title, 200)
            cls = ctypes.create_unicode_buffer(100)
            user32.GetClassNameW(hwnd, cls, 100)
            # Chrome wraps a right-to-left title in invisible direction marks; compare without them.
            text = "".join(ch for ch in title.value if ch not in "‎‏‪‫‬‭‮⁦⁧⁨⁩")
            if text == TITLE and cls.value.startswith("Chrome_WidgetWin"):
                found.append(hwnd)
        return True

    user32.EnumWindows(EnumProc(visit), 0)
    return found


def set_top(hwnd, on):
    user32.SetWindowPos(hwnd, wintypes.HWND(-1 if on else -2), 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE | SWP_NOACTIVATE)


def alive(pid):
    handle = kernel32.OpenProcess(0x1000, False, pid)  # PROCESS_QUERY_LIMITED_INFORMATION
    if not handle:
        return False
    code = wintypes.DWORD()
    kernel32.GetExitCodeProcess(handle, ctypes.byref(code))
    kernel32.CloseHandle(handle)
    return code.value == 259  # STILL_ACTIVE


def main():
    mode = sys.argv[1] if len(sys.argv) > 1 else "off"
    if mode == "off":
        for hwnd in windows():
            set_top(hwnd, False)
        return
    parent = int(sys.argv[2])
    while alive(parent):
        for hwnd in windows():
            # Only when the flag is missing (a new window, or something cleared it). Re-applying it every second
            # re-raised the window each time, and two open Claude windows kept jumping over each other.
            if not user32.IsIconic(hwnd) and not user32.GetWindowLongW(hwnd, GWL_EXSTYLE) & WS_EX_TOPMOST:
                set_top(hwnd, True)
        time.sleep(1)
    for hwnd in windows():
        set_top(hwnd, False)


if __name__ == "__main__":
    main()
