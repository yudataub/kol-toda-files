# Desktop control helper for the Claude panel bridge: screenshot, mouse, keyboard.
# Called once per action:  python desktop.py   (one JSON object on stdin, one JSON object on stdout)
# Screenshots are scaled down to MAX_W wide; every x/y coming in is in that scaled image's pixels.
# Emergency stop: if the mouse pointer is in the top-left corner of the screen, nothing is done.
import base64
import ctypes
import io
import json
import sys
import time
from ctypes import wintypes

user32 = ctypes.windll.user32
try:
    ctypes.windll.shcore.SetProcessDpiAwareness(2)  # physical pixels, same as the screenshot
except Exception:
    user32.SetProcessDPIAware()

MAX_W = 1280
KEYEVENTF_EXTENDEDKEY, KEYEVENTF_KEYUP, KEYEVENTF_UNICODE = 1, 2, 4
INPUT_KEYBOARD = 1


class KEYBDINPUT(ctypes.Structure):
    _fields_ = [("wVk", wintypes.WORD), ("wScan", wintypes.WORD), ("dwFlags", wintypes.DWORD),
                ("time", wintypes.DWORD), ("dwExtraInfo", ctypes.POINTER(ctypes.c_ulong))]


class MOUSEINPUT(ctypes.Structure):
    _fields_ = [("dx", wintypes.LONG), ("dy", wintypes.LONG), ("mouseData", wintypes.DWORD),
                ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD), ("dwExtraInfo", ctypes.POINTER(ctypes.c_ulong))]


class _INPUTUNION(ctypes.Union):
    _fields_ = [("ki", KEYBDINPUT), ("mi", MOUSEINPUT)]


class INPUT(ctypes.Structure):
    _fields_ = [("type", wintypes.DWORD), ("u", _INPUTUNION)]


VK = {
    "ctrl": 0x11, "control": 0x11, "alt": 0x12, "shift": 0x10, "win": 0x5B, "enter": 0x0D, "return": 0x0D,
    "tab": 0x09, "esc": 0x1B, "escape": 0x1B, "backspace": 0x08, "delete": 0x2E, "del": 0x2E, "insert": 0x2D,
    "space": 0x20, "up": 0x26, "down": 0x28, "left": 0x25, "right": 0x27, "home": 0x24, "end": 0x23,
    "pageup": 0x21, "pagedown": 0x22, "printscreen": 0x2C,
}
VK.update({f"f{i}": 0x6F + i for i in range(1, 13)})
EXTENDED = {0x26, 0x28, 0x25, 0x27, 0x24, 0x23, 0x21, 0x22, 0x2D, 0x2E, 0x5B}


def screen_size():
    return user32.GetSystemMetrics(0), user32.GetSystemMetrics(1)


def scale():
    return min(1.0, MAX_W / screen_size()[0])


def to_screen(x, y):
    s = scale()
    w, h = screen_size()
    return max(0, min(w - 1, round(float(x) / s))), max(0, min(h - 1, round(float(y) / s)))


def pointer():
    pt = wintypes.POINT()
    user32.GetCursorPos(ctypes.byref(pt))
    return pt.x, pt.y


def send_key(vk, up=False):
    flags = (KEYEVENTF_KEYUP if up else 0) | (KEYEVENTF_EXTENDEDKEY if vk in EXTENDED else 0)
    user32.keybd_event(vk, 0, flags, 0)


def press(vk):
    send_key(vk)
    send_key(vk, True)


def type_text(text):
    for ch in text:
        if ch == "\n":
            press(0x0D)
        elif ch == "\t":
            press(0x09)
        else:
            units = ch.encode("utf-16-le")
            for i in range(0, len(units), 2):  # one event pair per UTF-16 unit, so any language works
                code = int.from_bytes(units[i:i + 2], "little")
                for flags in (KEYEVENTF_UNICODE, KEYEVENTF_UNICODE | KEYEVENTF_KEYUP):
                    inp = INPUT(type=INPUT_KEYBOARD)
                    inp.u.ki = KEYBDINPUT(0, code, flags, 0, None)
                    user32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(INPUT))
        time.sleep(0.008)


def key_combo(keys):
    codes = []
    for name in [k.strip().lower() for k in keys.split("+") if k.strip()]:
        if name in VK:
            codes.append(VK[name])
        elif len(name) == 1 and name.isascii() and name.isalnum():
            codes.append(ord(name.upper()))
        else:
            raise ValueError(f"unknown key: {name}")
    for vk in codes:
        send_key(vk)
        time.sleep(0.02)
    for vk in reversed(codes):
        send_key(vk, True)


def screenshot():
    from PIL import ImageGrab
    img = ImageGrab.grab()
    s = scale()
    if s < 1:
        img = img.resize((round(img.width * s), round(img.height * s)))
    buf = io.BytesIO()
    img.convert("RGB").save(buf, "JPEG", quality=70)
    return base64.b64encode(buf.getvalue()).decode("ascii"), img.width, img.height


def main():
    req = json.loads(sys.stdin.read() or "{}")
    action = req.get("action")
    out = {"ok": True}
    if action != "screenshot" and pointer()[0] <= 2 and pointer()[1] <= 2:
        print(json.dumps({"ok": False, "aborted": True, "error": "stopped by the user (mouse pointer in the top-left corner)"}))
        return
    if action == "click":
        x, y = to_screen(req["x"], req["y"])
        user32.SetCursorPos(x, y)
        time.sleep(0.08)
        down, up = (8, 16) if req.get("button") == "right" else (2, 4)
        for _ in range(2 if req.get("double") else 1):
            user32.mouse_event(down, 0, 0, 0, 0)
            time.sleep(0.03)
            user32.mouse_event(up, 0, 0, 0, 0)
            time.sleep(0.07)
        out["text"] = f"clicked at {req['x']},{req['y']}"
    elif action == "move":
        x, y = to_screen(req["x"], req["y"])
        user32.SetCursorPos(x, y)
        out["text"] = "moved"
    elif action == "scroll":
        if "x" in req and "y" in req:
            user32.SetCursorPos(*to_screen(req["x"], req["y"]))
            time.sleep(0.05)
        user32.mouse_event(0x0800, 0, 0, ctypes.c_ulong(int(-120 * int(req.get("amount", 3))) & 0xFFFFFFFF).value, 0)
        out["text"] = "scrolled"
    elif action == "type":
        type_text(req.get("text", ""))
        out["text"] = "typed"
    elif action == "key":
        key_combo(req.get("keys", ""))
        out["text"] = f"pressed {req.get('keys')}"
    elif action != "screenshot":
        out = {"ok": False, "error": f"unknown action {action}"}
    if out["ok"] and (action == "screenshot" or req.get("shot", True)):
        if action != "screenshot":
            time.sleep(float(req.get("wait", 0.7)))  # let the screen react before looking at it
        image, w, h = screenshot()
        out["image"] = image
        out["text"] = (out.get("text", "") + f" | screenshot {w}x{h} (use these pixel coordinates)").strip(" |")
    print(json.dumps(out))


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:  # report, never a traceback on stdout
        print(json.dumps({"ok": False, "error": f"{type(exc).__name__}: {exc}"}))
