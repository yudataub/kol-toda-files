# Scissors button: opens the Windows snipping overlay (the dimmed screen where you drag a rectangle),
# waits until the cut picture lands on the clipboard, and prints it as base64 PNG.
# Exit 0 = picture printed; 2 = nothing cut within the time limit (Esc / closed); 3 = error.
# SNIP_NO_LAUNCH=1 skips opening the overlay (tests put a picture on the clipboard themselves).
$ErrorActionPreference = 'Stop'
try {
  Add-Type -AssemblyName System.Windows.Forms, System.Drawing
  Add-Type -Namespace SnipHelper -Name Clip -MemberDefinition '[DllImport("user32.dll")] public static extern uint GetClipboardSequenceNumber();'
  $start = [SnipHelper.Clip]::GetClipboardSequenceNumber()
  if ($env:SNIP_NO_LAUNCH -ne '1') { Start-Process 'ms-screenclip:' }
  $deadline = (Get-Date).AddSeconds(120)
  while ((Get-Date) -lt $deadline) {
    Start-Sleep -Milliseconds 250
    if ([SnipHelper.Clip]::GetClipboardSequenceNumber() -eq $start) { continue }
    try {
      if ([System.Windows.Forms.Clipboard]::ContainsImage()) {
        $img = [System.Windows.Forms.Clipboard]::GetImage()
        $ms = New-Object System.IO.MemoryStream
        $img.Save($ms, [System.Drawing.Imaging.ImageFormat]::Png)
        [Console]::Out.Write([Convert]::ToBase64String($ms.ToArray()))
        exit 0
      }
    } catch { } # the clipboard can be busy for a moment while the snipping tool writes to it
  }
  exit 2
} catch {
  [Console]::Error.Write($_.Exception.Message)
  exit 3
}
