// Automatic updates: every few hours the bridge asks the site whether a newer version was published,
// downloads it, checks its digital signature, installs it when the panel is idle, and restarts itself.
//
// update.json on the site: { version, url, size, sha256, sig }. sig is an Ed25519 signature over
// "claude-window|<version>|<sha256>", made with a private key that exists only on the publisher's computer
// (sign-release.mjs). So even someone who could change files on the site cannot push code to installed copies.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { execFile, spawn } from 'node:child_process';

const UPDATE_URL = 'https://www.kol-toda.co.il/teacher-tools/claude-window/update.json';
const PUBLIC_KEY = crypto.createPublicKey({
  key: Buffer.from('MCowBQYDK2VwAyEAtafNwVdCRGv507CQP5vPSDivDomic+eS6dbwrgfwHG8=', 'base64'), format: 'der', type: 'spki',
});
const ZIP_PREFIXES = ['https://yudataub.github.io/kol-toda-files/', 'https://www.kol-toda.co.il/'];
const MAX_ZIP = 20 * 1024 * 1024;
const FIRST_CHECK = 2 * 60 * 1000;
const EVERY = 6 * 60 * 60 * 1000;
const RETRY_FAILED = 24 * 60 * 60 * 1000;
const VERSION = /^\d{1,4}\.\d{1,4}\.\d{1,6}$/;

export function readVersion(here) {
  for (const file of [path.join(here, 'app', 'manifest.json'), path.join(here, '..', 'extension', 'manifest.json')]) {
    try { return JSON.parse(fs.readFileSync(file, 'utf8')).version; } catch {}
  }
  return '0.0.0';
}
export function newer(a, b) { // is version a newer than b
  const x = a.split('.').map(Number), y = b.split('.').map(Number);
  for (let i = 0; i < 3; i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0);
  return false;
}

// hooks: log, notify(text), enabled(), isIdle(), beforeInstall(), restart()
export function createUpdater(here, dataDir, hooks) {
  const dir = path.join(dataDir, 'update');
  const version = readVersion(here);
  const failed = {}; // version -> when it failed, so a broken release is not retried every few hours
  let working = false;
  let ready = null; // { version, root } downloaded and checked, waiting for an idle moment
  let waitTimer = null;

  async function check(manual) {
    if (working || ready) return { status: ready ? 'waiting' : 'busy', version: ready && ready.version };
    working = true;
    try {
      const res = await fetch(`${process.env.PANEL_UPDATE_URL || UPDATE_URL}?t=${Date.now()}`, { cache: 'no-store', signal: AbortSignal.timeout(20000) });
      if (!res.ok) throw new Error('update.json: HTTP ' + res.status);
      const info = await res.json();
      if (!VERSION.test(String(info.version)) || !/^[0-9a-f]{64}$/.test(String(info.sha256)) || typeof info.sig !== 'string') throw new Error('update.json is malformed');
      if (!newer(info.version, version)) return { status: 'current', version };
      if (!manual && failed[info.version] && Date.now() - failed[info.version] < RETRY_FAILED) return { status: 'failed-before', version: info.version };
      const signed = crypto.verify(null, Buffer.from(`claude-window|${info.version}|${info.sha256}`), PUBLIC_KEY, Buffer.from(info.sig, 'base64'));
      if (!signed) throw new Error('the signature of version ' + info.version + ' does not match – not installing');
      const url = String(info.url || '');
      const prefixes = process.env.PANEL_UPDATE_URL ? [...ZIP_PREFIXES, new URL(process.env.PANEL_UPDATE_URL).origin + '/'] : ZIP_PREFIXES;
      if (!prefixes.some((p) => url.startsWith(p))) throw new Error('unexpected download address: ' + url.slice(0, 120));

      hooks.log('update: downloading version', info.version);
      const zipRes = await fetch(`${url}?v=${info.version}`, { cache: 'no-store', signal: AbortSignal.timeout(120000) });
      if (!zipRes.ok) throw new Error('download: HTTP ' + zipRes.status);
      const zip = Buffer.from(await zipRes.arrayBuffer());
      if (zip.length > MAX_ZIP) throw new Error('the download is too large');
      if (crypto.createHash('sha256').update(zip).digest('hex') !== info.sha256) {
        throw new Error('the download does not match update.json (the site may still be refreshing; will try again later)');
      }
      fs.rmSync(dir, { recursive: true, force: true });
      fs.mkdirSync(dir, { recursive: true });
      const zipFile = path.join(dir, 'claude-window.zip');
      fs.writeFileSync(zipFile, zip);
      const out = path.join(dir, 'files');
      fs.mkdirSync(out);
      await run('tar', ['-xf', zipFile, '-C', out], 60000); // tar.exe ships with Windows 10 and 11 and reads ZIP files
      const root = path.join(out, 'claude-window', 'claude-panel');
      const got = readVersion(path.join(root, 'bridge'));
      if (!fs.existsSync(path.join(root, 'install.mjs')) || got !== info.version) throw new Error('the downloaded package is incomplete');
      ready = { version: info.version, root };
      hooks.log('update: version', info.version, 'is ready');
      hooks.notify(`גרסה חדשה של החלונית (${info.version}) הורדה. היא תותקן לבד ברגע שאין משימה רצה, והחלונית תיטען מחדש.`);
      setTimeout(installWhenIdle, 1000);
      return { status: 'ready', version: info.version };
    } catch (err) {
      hooks.log('update check failed:', String(err.message || err).slice(0, 300));
      return { status: 'error', error: String(err.message || err) };
    } finally {
      working = false;
    }
  }

  function installWhenIdle() {
    clearTimeout(waitTimer);
    if (!ready) return;
    if (!hooks.isIdle()) { waitTimer = setTimeout(installWhenIdle, 30000); return; }
    const target = ready;
    working = true;
    hooks.log('update: installing version', target.version);
    hooks.beforeInstall(target.version);
    // Give the closed Claude process a moment to exit (npm may need to replace its files).
    setTimeout(async () => {
      try {
        await run(process.execPath, [path.join(target.root, 'install.mjs'), '--update'], 5 * 60 * 1000);
        fs.writeFileSync(path.join(dir, 'done.json'), JSON.stringify({ from: version, to: target.version, ts: Date.now() }));
        hooks.log('update: installed version', target.version, '– restarting');
        hooks.restart();
      } catch (err) {
        failed[target.version] = Date.now();
        ready = null;
        working = false;
        hooks.log('update: install failed:', String(err.message || err).slice(0, 500));
        hooks.notify('העדכון האוטומטי נכשל. החלונית ממשיכה לעבוד בגרסה הנוכחית. פרטים בקובץ bridge.log.');
      }
    }, 2500);
  }

  // Shown once after a restart into a new version (the panel remembers it showed it).
  function justUpdated() {
    try {
      const done = JSON.parse(fs.readFileSync(path.join(dir, 'done.json'), 'utf8'));
      if (done.to === version && Date.now() - done.ts < 30 * 60 * 1000) return done.to;
    } catch {}
    return null;
  }

  function start() {
    if (process.env.PANEL_NO_UPDATE === '1') return;
    const tick = () => { if (hooks.enabled()) check(false); };
    setTimeout(tick, FIRST_CHECK).unref();
    setInterval(tick, EVERY).unref();
  }

  return { version, check, start, justUpdated, isUpdating: () => working && !!ready };
}

function run(cmd, args, timeout) {
  return new Promise((resolve, reject) => {
    execFile(cmd, args, { timeout, windowsHide: true, maxBuffer: 16 * 1024 * 1024 }, (err, stdout, stderr) => {
      if (err) reject(new Error(`${path.basename(cmd)} failed: ${err.message}\n${String(stderr || stdout).slice(-1500)}`));
      else resolve(stdout);
    });
  });
}

// Restart: start a fresh bridge process that does not belong to this one's process tree.
export function relaunch(here) {
  const vbs = path.join(here, 'Claude Panel Bridge.vbs');
  const child = fs.existsSync(vbs)
    ? spawn('wscript.exe', [vbs], { detached: true, stdio: 'ignore' })
    : spawn(process.execPath, [path.join(here, 'server.mjs')], { detached: true, stdio: 'ignore', cwd: here });
  child.unref();
}
