﻿# Desktop control for the Claude panel bridge, with nothing to install (PowerShell and .NET are part of Windows).
#   powershell -NoProfile -ExecutionPolicy Bypass -File desktop.ps1 <base64 of a UTF-8 JSON request>
# Prints one JSON object. Same requests as desktop.py (screenshot, click, move, scroll, type, key), plus:
#   windows                 the open windows, front first
#   elements {window, filter}  the buttons, links and fields of a window, by name (Windows UI Automation),
#                           numbered; the numbers are saved in data\ui-refs.json for desktop_click_element
#   focus {window}          bring a window to the front
# Coordinates in and out are pixels of the screenshot (the screen scaled down to MAX_W wide).
# Emergency stop: mouse pointer in the top-left corner -> nothing is done.
param([string]$Request)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.Encoding]::UTF8

$DataDir = Join-Path $PSScriptRoot 'data'
$Helper = Join-Path $DataDir 'deskhelper-5.dll' # bump the number when the C# below changes
if (-not (Test-Path $Helper)) {
  New-Item -ItemType Directory -Force $DataDir | Out-Null
  $code = @'
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Automation;

public static class DeskHelper {
  public const int MAX_W = 1280;
  [DllImport("user32.dll")] static extern bool SetProcessDPIAware();
  [DllImport("shcore.dll")] static extern int SetProcessDpiAwareness(int v);
  [DllImport("user32.dll")] static extern int GetSystemMetrics(int i);
  [DllImport("user32.dll")] static extern bool SetCursorPos(int x, int y);
  [DllImport("user32.dll")] static extern bool GetCursorPos(out POINT p);
  [DllImport("user32.dll")] static extern void mouse_event(uint f, int dx, int dy, int data, IntPtr extra);
  [DllImport("user32.dll")] static extern void keybd_event(byte vk, byte scan, uint f, IntPtr extra);
  [DllImport("user32.dll")] static extern uint SendInput(uint n, INPUT[] inputs, int size);
  [DllImport("user32.dll")] static extern bool EnumWindows(EnumProc cb, IntPtr l);
  [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
  [DllImport("user32.dll")] static extern bool IsIconic(IntPtr h);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll")] static extern bool ShowWindow(IntPtr h, int cmd);
  [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr h, out RECT r);
  [DllImport("dwmapi.dll")] static extern int DwmGetWindowAttribute(IntPtr h, int a, out int v, int size);
  public delegate bool EnumProc(IntPtr h, IntPtr l);
  [StructLayout(LayoutKind.Sequential)] public struct POINT { public int X, Y; }
  [StructLayout(LayoutKind.Sequential)] public struct RECT { public int L, T, R, B; }
  [StructLayout(LayoutKind.Sequential)] public struct KEYBDINPUT { public ushort vk, scan; public uint flags, time; public IntPtr extra; }
  [StructLayout(LayoutKind.Sequential)] public struct MOUSEINPUT { public int dx, dy; public uint data, flags, time; public IntPtr extra; }
  [StructLayout(LayoutKind.Explicit)] public struct INPUTUNION { [FieldOffset(0)] public MOUSEINPUT mi; [FieldOffset(0)] public KEYBDINPUT ki; }
  [StructLayout(LayoutKind.Sequential)] public struct INPUT { public uint type; public INPUTUNION u; }

  public static void Init() { try { SetProcessDpiAwareness(2); } catch { SetProcessDPIAware(); } }
  public static int W { get { return GetSystemMetrics(0); } }
  public static int H { get { return GetSystemMetrics(1); } }
  public static double Scale { get { return Math.Min(1.0, (double)MAX_W / W); } }
  public static int[] ToScreen(double x, double y) {
    double s = Scale;
    return new int[] { Math.Max(0, Math.Min(W - 1, (int)Math.Round(x / s))), Math.Max(0, Math.Min(H - 1, (int)Math.Round(y / s))) };
  }
  public static bool InCorner() { POINT p; GetCursorPos(out p); return p.X <= 2 && p.Y <= 2; }

  public static string Screenshot(out int w, out int h) {
    using (var full = new Bitmap(W, H)) {
      using (var g = Graphics.FromImage(full)) g.CopyFromScreen(0, 0, 0, 0, full.Size);
      double s = Scale;
      w = (int)Math.Round(full.Width * s); h = (int)Math.Round(full.Height * s);
      using (var small = new Bitmap(full, new Size(w, h))) using (var ms = new MemoryStream()) {
        var enc = Array.Find(ImageCodecInfo.GetImageEncoders(), c => c.MimeType == "image/jpeg");
        var ps = new EncoderParameters(1); ps.Param[0] = new EncoderParameter(System.Drawing.Imaging.Encoder.Quality, 70L);
        small.Save(ms, enc, ps);
        return Convert.ToBase64String(ms.ToArray());
      }
    }
  }
  public static void Click(double x, double y, bool right, bool dbl) {
    var p = ToScreen(x, y); SetCursorPos(p[0], p[1]); Thread.Sleep(80);
    uint down = right ? 8u : 2u, up = right ? 16u : 4u;
    for (int i = 0; i < (dbl ? 2 : 1); i++) { mouse_event(down, 0, 0, 0, IntPtr.Zero); Thread.Sleep(30); mouse_event(up, 0, 0, 0, IntPtr.Zero); Thread.Sleep(70); }
  }
  public static void Move(double x, double y) { var p = ToScreen(x, y); SetCursorPos(p[0], p[1]); }
  public static void Scroll(int notches) { mouse_event(0x0800, 0, 0, -120 * notches, IntPtr.Zero); }
  public static void Key(byte vk, bool up, bool ext) { keybd_event(vk, 0, (up ? 2u : 0u) | (ext ? 1u : 0u), IntPtr.Zero); }
  public static void TypeText(string text) {
    foreach (char ch in text) {
      if (ch == '\n') { Key(0x0D, false, false); Key(0x0D, true, false); }
      else if (ch == '\t') { Key(0x09, false, false); Key(0x09, true, false); }
      else if (ch != '\r') {
        var ins = new INPUT[2];
        ins[0].type = 1; ins[0].u.ki = new KEYBDINPUT { vk = 0, scan = ch, flags = 4 };
        ins[1].type = 1; ins[1].u.ki = new KEYBDINPUT { vk = 0, scan = ch, flags = 4 | 2 };
        SendInput(2, ins, Marshal.SizeOf(typeof(INPUT)));
      }
      Thread.Sleep(8);
    }
  }

  // ---- windows ----
  static bool Cloaked(IntPtr h) { int v; return DwmGetWindowAttribute(h, 14, out v, 4) == 0 && v != 0; }
  public static List<object[]> Windows() { // [handle, title, pid], front first
    var list = new List<object[]>();
    EnumWindows((h, l) => {
      if (!IsWindowVisible(h) || Cloaked(h)) return true;
      var sb = new StringBuilder(512); GetWindowText(h, sb, 512);
      var t = sb.ToString().Replace("‪", "").Replace("‫", "").Replace("‬", "").Trim();
      RECT r; GetWindowRect(h, out r);
      if (t.Length == 0 || r.R - r.L < 50 || r.B - r.T < 50) return true;
      if (t == "Program Manager") return true;
      uint pid; GetWindowThreadProcessId(h, out pid);
      list.Add(new object[] { h, t, (int)pid });
      return true;
    }, IntPtr.Zero);
    return list;
  }
  public static void Focus(IntPtr h) {
    if (IsIconic(h)) ShowWindow(h, 9);
    Key(0x12, false, false); Key(0x12, true, false); // an Alt press lets this process move the focus
    SetForegroundWindow(h); Thread.Sleep(250);
  }

  // ---- elements (UI Automation): what a person could click or type into ----
  static readonly ControlType[] Wanted = {
    ControlType.Button, ControlType.Hyperlink, ControlType.Edit, ControlType.ComboBox, ControlType.CheckBox,
    ControlType.RadioButton, ControlType.MenuItem, ControlType.TabItem, ControlType.ListItem, ControlType.TreeItem,
    ControlType.SplitButton, ControlType.Slider, ControlType.Spinner, ControlType.DataItem, ControlType.Document };
  public static List<object[]> Elements(IntPtr h, string filter, int max, int wakeMs) { // [type, name, value, x, y] in screenshot pixels
    var root = AutomationElement.FromHandle(h);
    // Chrome (and other Chromium programs) expose page content only once an assistive program is listening:
    // a focus listener tells them so. The page needs a moment to build its tree the first time.
    AutomationFocusChangedEventHandler noop = (o, e) => { };
    Automation.AddAutomationFocusChangedEventHandler(noop);
    try { root.FindFirst(TreeScope.Descendants, new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.Document)); } catch { }
    Thread.Sleep(wakeMs);
    var conds = new List<Condition>();
    foreach (var t in Wanted) conds.Add(new PropertyCondition(AutomationElement.ControlTypeProperty, t));
    var cond = new AndCondition(new OrCondition(conds.ToArray()), new PropertyCondition(AutomationElement.IsOffscreenProperty, false));
    var found = root.FindAll(TreeScope.Descendants, cond);
    var outp = new List<object[]>();
    double s = Scale;
    foreach (AutomationElement e in found) {
      try {
        var c = e.Current;
        var r = c.BoundingRectangle;
        if (r.IsEmpty || r.Width < 2 || r.Height < 2) continue;
        string name = (c.Name ?? "").Trim();
        string value = "";
        object vp;
        if (e.TryGetCurrentPattern(ValuePattern.Pattern, out vp)) { try { value = ((ValuePattern)vp).Current.Value ?? ""; } catch { } }
        if (c.ControlType == ControlType.Edit && c.IsPassword) value = "(password)";
        string type = c.ControlType.ProgrammaticName.Replace("ControlType.", "");
        if (type == "Document" && name.Length == 0) continue;
        string hay = (name + " " + value + " " + c.AutomationId + " " + c.HelpText).ToLowerInvariant();
        if (!string.IsNullOrEmpty(filter) && !hay.Contains(filter.ToLowerInvariant())) continue;
        if (name.Length == 0 && value.Length == 0 && type != "Edit" && type != "ComboBox") continue;
        int cx = (int)Math.Round((r.Left + r.Width / 2) * s), cy = (int)Math.Round((r.Top + r.Height / 2) * s);
        outp.Add(new object[] { type, name.Length > 120 ? name.Substring(0, 120) + "…" : name, value.Length > 80 ? value.Substring(0, 80) + "…" : value, cx, cy });
        if (outp.Count >= max) break;
      } catch (ElementNotAvailableException) { }
    }
    return outp;
  }
}
'@
  $refs = @('System.Drawing', 'UIAutomationClient', 'UIAutomationTypes', 'WindowsBase')
  Add-Type -TypeDefinition $code -ReferencedAssemblies $refs -OutputAssembly $Helper -OutputType Library
}
Add-Type -AssemblyName UIAutomationClient, UIAutomationTypes, System.Drawing
Add-Type -Path $Helper
[DeskHelper]::Init()

$VK = @{ ctrl = 0x11; control = 0x11; alt = 0x12; shift = 0x10; win = 0x5B; enter = 0x0D; return = 0x0D; tab = 0x09
  esc = 0x1B; escape = 0x1B; backspace = 0x08; delete = 0x2E; del = 0x2E; insert = 0x2D; space = 0x20; up = 0x26
  down = 0x28; left = 0x25; right = 0x27; home = 0x24; end = 0x23; pageup = 0x21; pagedown = 0x22; printscreen = 0x2C }
1..12 | ForEach-Object { $VK["f$_"] = 0x6F + $_ }
$EXT = @(0x26, 0x28, 0x25, 0x27, 0x24, 0x23, 0x21, 0x22, 0x2D, 0x2E, 0x5B)
$PanelTitle = 'Claude במחשב שלי'

function Find-Window([string]$name) {
  $all = [DeskHelper]::Windows()
  if ($name) {
    $w = $all | Where-Object { $_[1] -like "*$name*" } | Select-Object -First 1
    if (-not $w) { throw "no open window whose title contains '$name'. Use desktop_windows to see the open windows." }
    return $w
  }
  # Default: the front window that is not this panel (the user is usually typing in the panel).
  $w = $all | Where-Object { $_[1] -ne $PanelTitle -and $_[1] -notlike "$PanelTitle*" } | Select-Object -First 1
  if (-not $w) { throw 'no open window found' }
  return $w
}

function Invoke-Request($req) {
  $out = [ordered]@{ ok = $true }
  $action = [string]$req.action
  if ($action -notin @('screenshot', 'windows', 'elements') -and [DeskHelper]::InCorner()) {
    return @{ ok = $false; aborted = $true; error = 'stopped by the user (mouse pointer in the top-left corner)' }
  }
  switch ($action) {
    'screenshot' { }
    'click' { [DeskHelper]::Click([double]$req.x, [double]$req.y, $req.button -eq 'right', [bool]$req.double); $out.text = "clicked at $($req.x),$($req.y)" }
    'move' { [DeskHelper]::Move([double]$req.x, [double]$req.y); $out.text = 'moved' }
    'scroll' {
      if ($null -ne $req.x -and $null -ne $req.y) { [DeskHelper]::Move([double]$req.x, [double]$req.y); Start-Sleep -Milliseconds 50 }
      $n = 3; if ($null -ne $req.amount) { $n = [int]$req.amount }
      [DeskHelper]::Scroll($n); $out.text = 'scrolled'
    }
    'type' { [DeskHelper]::TypeText([string]$req.text); $out.text = 'typed' }
    'key' {
      $codes = foreach ($k in ([string]$req.keys).ToLower().Split('+')) {
        $k = $k.Trim(); if (-not $k) { continue }
        if ($VK.ContainsKey($k)) { $VK[$k] } elseif ($k.Length -eq 1 -and $k -match '^[a-z0-9]$') { [int][char]$k.ToUpper() } else { throw "unknown key: $k" }
      }
      foreach ($c in $codes) { [DeskHelper]::Key([byte]$c, $false, $EXT -contains $c); Start-Sleep -Milliseconds 20 }
      [array]::Reverse($codes); foreach ($c in $codes) { [DeskHelper]::Key([byte]$c, $true, $EXT -contains $c) }
      $out.text = "pressed $($req.keys)"
    }
    'windows' {
      $lines = [DeskHelper]::Windows() | Select-Object -First 40 | ForEach-Object { '- ' + $_[1] }
      return @{ ok = $true; text = "Open windows, front first:`n" + ($lines -join "`n") }
    }
    'focus' {
      $w = Find-Window ([string]$req.window); [DeskHelper]::Focus($w[0]); $out.text = "brought to front: $($w[1])"
    }
    'elements' {
      $w = Find-Window ([string]$req.window)
      $max = 150; if ($req.max) { $max = [Math]::Min(400, [int]$req.max) }
      $wake = if ($w[1] -match 'Chrome|Edge|Chromium|Visual Studio Code|Electron') { 700 } else { 0 }
      $items = [DeskHelper]::Elements($w[0], [string]$req.filter, $max, $wake)
      $refs = @(); $lines = @(); $i = 0
      foreach ($e in $items) {
        $i++
        $refs += , @{ ref = $i; type = $e[0]; name = $e[1]; x = $e[3]; y = $e[4] }
        $label = if ($e[1]) { '"' + $e[1] + '"' } else { '(no name)' }
        $val = if ($e[2] -and $e[2] -ne $e[1]) { " value=`"$($e[2])`"" } else { '' }
        $lines += "[$i] $($e[0]) $label$val at $($e[3]),$($e[4])"
      }
      [IO.File]::WriteAllText((Join-Path $DataDir 'ui-refs.json'), (ConvertTo-Json -InputObject @{ window = $w[1]; items = $refs } -Depth 4 -Compress))
      $head = "Window: $($w[1]) - $i elements" + $(if ($req.filter) { " matching '$($req.filter)'" } else { '' })
      $note = if ($i -eq 0) { "`nNothing found. The window may draw its own controls (then use desktop_screenshot and desktop_click), or try without filter." } elseif ($i -ge $max) { "`n(list cut at ${max} - use filter to narrow it)" } else { '' }
      return @{ ok = $true; text = $head + "`n" + ($lines -join "`n") + $note }
    }
    default { return @{ ok = $false; error = "unknown action $action" } }
  }
  if ($action -eq 'screenshot' -or $req.shot -ne $false) {
    if ($action -ne 'screenshot') { $wait = 0.7; if ($null -ne $req.wait) { $wait = [double]$req.wait }; Start-Sleep -Milliseconds ([int]($wait * 1000)) }
    $w = 0; $h = 0
    $out.image = [DeskHelper]::Screenshot([ref]$w, [ref]$h)
    $out.text = (($out.text, "screenshot ${w}x${h} (use these pixel coordinates)") | Where-Object { $_ }) -join ' | '
  }
  return $out
}

try {
  $json = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($Request))
  $req = $json | ConvertFrom-Json
  $res = Invoke-Request $req
} catch {
  $res = @{ ok = $false; error = "$($_.Exception.GetType().Name): $($_.Exception.Message)" }
}
[Console]::Out.Write((ConvertTo-Json -InputObject $res -Depth 4 -Compress))
