@echo off
rem Claude window - installer. Extract the whole ZIP first, then double-click this file. ASCII only.
chcp 65001 > nul
setlocal
cd /d "%~dp0"
echo.
echo  Installing the Claude window...
echo.
where node > nul 2>&1
if errorlevel 1 (
  echo  Node.js is not installed. Opening the download page - install the LTS version, then run this file again.
  start "" https://nodejs.org/
  goto done
)
where python > nul 2>&1
if errorlevel 1 (
  echo  NOTE: Python is not installed. The window will work, but mouse/keyboard control and the floating window will not.
) else (
  python -m pip install --quiet pillow
)
node "%~dp0claude-panel\install.mjs" --safe-defaults
if errorlevel 1 (
  echo.
  echo  The installation failed. See the messages above.
  goto done
)
if not exist "%USERPROFILE%\.claude\.credentials.json" (
  echo.
  echo  One more step: sign in to your Claude account.
  echo  A black window opens now. Press Enter on the first screen, choose the Claude account option, and approve in the browser.
  start "Claude sign-in" cmd /k ""%USERPROFILE%\claude-panel-bridge\node_modules\@anthropic-ai\claude-agent-sdk-win32-x64\claude.exe""
)
timeout /t 2 /nobreak > nul
start "" wscript "%USERPROFILE%\claude-panel-bridge\Claude Window.vbs"
echo.
echo  Done. A shortcut was added to the desktop and to the Start menu.
:done
echo.
pause
