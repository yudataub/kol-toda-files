@echo off
chcp 65001 >nul
echo Installing ToMarkdown. Keep this window open, it can take 10-15 minutes.
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
echo.
pause
