﻿# מתקין את "ממיר ל-Markdown" במחשב חדש. מופעל מ-INSTALL.bat.
# ההודעות בחלון באנגלית כי עברית יוצאת הפוכה במסוף של Windows. סיכום בעברית מופיע בסוף בחלון רגיל.
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$test = $env:TOMD_TEST -eq '1'
$dest = if ($env:TOMD_DEST) { $env:TOMD_DEST } else { Join-Path $env:LOCALAPPDATA 'ToMarkdown' }
$source = Join-Path $PSScriptRoot 'app'
$port = 5121

function Show-Message($text, $icon) {
    if ($test) { Write-Host $text; return }
    Add-Type -AssemblyName System.Windows.Forms
    $options = [System.Windows.Forms.MessageBoxOptions]::RightAlign -bor [System.Windows.Forms.MessageBoxOptions]::RtlReading
    [void][System.Windows.Forms.MessageBox]::Show($text, 'ממיר ל-Markdown', 'OK', $icon, 'Button1', $options)
}

function Update-Path {
    $env:Path = [Environment]::GetEnvironmentVariable('Path', 'Machine') + ';' + [Environment]::GetEnvironmentVariable('Path', 'User')
}

function Find-Uv {
    $command = Get-Command uv -ErrorAction SilentlyContinue
    if ($command) { return $command.Source }
    foreach ($path in "$env:LOCALAPPDATA\Microsoft\WinGet\Links\uv.exe", "$HOME\.local\bin\uv.exe") {
        if (Test-Path $path) { return $path }
    }
    return $null
}

function Install-Package($id) {
    if (-not (Get-Command winget -ErrorAction SilentlyContinue)) { return }
    $ErrorActionPreference = 'Continue'  # פלט ב-stderr של תוכנה חיצונית אינו שגיאה. בודקים אחר כך אם הותקנה
    & winget install --id $id -e --silent --source winget --accept-package-agreements --accept-source-agreements --disable-interactivity 2>&1 | Out-Host
}

function Find-File($paths) {
    return [bool]($paths | Where-Object { Test-Path $_ } | Select-Object -First 1)
}

try {
    if (-not (Test-Path $source)) {
        throw 'NOZIP'
    }

    Write-Host '[1/5] Copying the app...'
    if (-not $test) {
        Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue |
            ForEach-Object { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue }
    }
    New-Item -ItemType Directory -Force $dest | Out-Null
    Copy-Item (Join-Path $source '*') $dest -Recurse -Force

    Write-Host '[2/5] Checking uv (Python manager)...'
    Update-Path
    if (-not (Find-Uv)) { Install-Package 'astral-sh.uv'; Update-Path }
    if (-not (Find-Uv)) {
        Invoke-RestMethod 'https://astral.sh/uv/install.ps1' | Invoke-Expression
        Update-Path
    }
    $uv = Find-Uv
    if (-not $uv) { throw 'NOUV' }

    Write-Host '[3/5] Installing Tesseract (reads scanned pages). Windows may ask for approval...'
    $tesseract = "$env:ProgramFiles\Tesseract-OCR\tesseract.exe", "${env:ProgramFiles(x86)}\Tesseract-OCR\tesseract.exe", "$env:LOCALAPPDATA\Programs\Tesseract-OCR\tesseract.exe"
    if (-not (Find-File $tesseract)) { Install-Package 'UB-Mannheim.TesseractOCR' }

    Write-Host '[4/5] Installing LibreOffice (reads old doc and ppt files). About 350 MB, Windows may ask for approval...'
    $office = "$env:ProgramFiles\LibreOffice\program\soffice.exe", "${env:ProgramFiles(x86)}\LibreOffice\program\soffice.exe"
    if (-not (Find-File $office)) { Install-Package 'TheDocumentFoundation.LibreOffice' }

    Write-Host '[5/5] Installing Python and libraries. This takes a few minutes...'
    # שימוש במאגר התעודות של Windows, כדי שההורדה תעבוד גם מאחורי סינון כמו נטפרי
    $env:UV_NATIVE_TLS = 'true'
    $ErrorActionPreference = 'Continue'  # uv כותב התקדמות ל-stderr. התוצאה נבדקת לפי LASTEXITCODE
    $venv = Join-Path $dest '.venv'
    if (Test-Path $venv) { Remove-Item $venv -Recurse -Force }
    & $uv venv --python 3.12 $venv 2>&1 | Out-Host
    if ($LASTEXITCODE -ne 0) { throw 'NOPYTHON' }
    $python = Join-Path $venv 'Scripts\python.exe'
    & $uv pip install --python $python -r (Join-Path $dest 'requirements.txt') 2>&1 | Out-Host
    if ($LASTEXITCODE -ne 0) { throw 'NOLIBS' }
    Push-Location $dest
    & $python -c "import converter" 2>&1 | Out-Host
    $imported = $LASTEXITCODE -eq 0
    Pop-Location
    if (-not $imported) { throw 'NOLIBS' }
    $ErrorActionPreference = 'Stop'

    $missing = @()
    if (-not (Find-File $tesseract)) { $missing += 'Tesseract: קבצים סרוקים ותמונות לא ייקראו' }
    if (-not (Find-File $office)) { $missing += 'LibreOffice: קובצי doc ו-ppt ישנים לא ייקראו' }

    if (-not $test) {
        & (Join-Path $dest 'install_shortcuts.ps1')
        Start-Process (Join-Path $venv 'Scripts\pythonw.exe') -ArgumentList "`"$(Join-Path $dest 'launch.py')`"" -WorkingDirectory $dest
    }

    $message = "ההתקנה הסתיימה.`n`nבשולחן העבודה יש עכשיו קיצור דרך בשם `"ממיר ל-Markdown`"."
    if ($missing) {
        $message += "`n`nשני דברים לא הותקנו, והשאר עובד:`n" + ($missing -join "`n")
        Show-Message $message 'Warning'
    } else {
        Show-Message $message 'Information'
    }
}
catch {
    $reason = switch ("$($_.Exception.Message)") {
        'NOZIP'    { 'צריך קודם לחלץ את כל קובץ ה-ZIP לתיקייה, ורק אז להפעיל את INSTALL.bat.' }
        'NOUV'     { 'לא הצלחתי להתקין את uv. בדקו שיש חיבור לאינטרנט ונסו שוב.' }
        'NOPYTHON' { 'לא הצלחתי להוריד את Python. אם יש סינון אינטרנט, ייתכן שהוא חוסם את github.com.' }
        'NOLIBS'   { 'לא הצלחתי להוריד את הספריות. אם יש סינון אינטרנט, ייתכן שהוא חוסם את pypi.org.' }
        default    { "שגיאה: $($_.Exception.Message)" }
    }
    Show-Message "ההתקנה לא הושלמה.`n`n$reason" 'Error'
    exit 1
}
