"""המרת קבצים לטקסט Markdown נקי, עם טיפול מיוחד בעברית.

למה לא markitdown בלבד: ב-PDF עברי הוא מחזיר את הטקסט הפוך ("רורמה לע הכרבה"),
ובמצגות PDF שבנויות מתמונות הוא מחזיר טקסט ריק. לכן PDF ותמונות עוברים כאן
ב-PyMuPDF וב-Tesseract, ו-markitdown מטפל בשאר הסוגים.
"""
import os
import re
import shutil
import subprocess
import tempfile
import zipfile
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from pathlib import Path

os.environ.setdefault("OMP_THREAD_LIMIT", "1")

import pymupdf
import pytesseract
from PIL import Image



def _find_program(name, *folders):
    """מחפש תוכנה בתיקיות ההתקנה הרגילות, כי היא לא תמיד נמצאת ב-PATH."""
    roots = [os.environ.get(v) for v in ("ProgramFiles", "ProgramFiles(x86)")]
    roots.append(os.path.join(os.environ.get("LOCALAPPDATA", ""), "Programs"))
    for root in filter(None, roots):
        for folder in folders:
            path = Path(root) / folder / name
            if path.exists():
                return str(path)
    return shutil.which(name) or name


pytesseract.pytesseract.tesseract_cmd = _find_program("tesseract.exe", "Tesseract-OCR")
_TESSDATA = Path(__file__).parent / "tessdata"  # בהתקנה אצל אחרים: העברית מגיעה עם האפליקציה
if _TESSDATA.exists():
    os.environ["TESSDATA_PREFIX"] = str(_TESSDATA)
pymupdf.TOOLS.mupdf_display_errors(False)

OCR_LANG = "heb+eng"
OCR_DPI = 250
OCR_WORKERS = 4
ZIP_MAX_FILES = 500
ZIP_MAX_BYTES = 2 * 1024**3

IMAGE_EXT = {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".webp", ".gif"}
TEXT_EXT = {".txt", ".md", ".markdown", ".log", ".srt", ".vtt"}
MARKITDOWN_EXT = {".docx", ".pptx", ".xlsx", ".xls", ".html", ".htm", ".csv",
                  ".json", ".xml", ".epub", ".msg", ".ipynb"}
# פורמטים ישנים: LibreOffice מעביר אותם לפורמט מודרני, ומשם ממשיכים כרגיל
SOFFICE = _find_program("soffice.exe", r"LibreOffice\program")
LO_PROFILE = Path(__file__).parent / ".lo-profile"
LIBREOFFICE_EXT = {".doc": "docx", ".dot": "docx", ".rtf": "docx", ".odt": "docx", ".wps": "docx",
                   ".wpd": "docx", ".docm": "docx", ".ppt": "pptx", ".pps": "pptx", ".ppsx": "pptx",
                   ".pptm": "pptx", ".odp": "pptx", ".ods": "xlsx", ".xlsm": "xlsx", ".xlsb": "xlsx"}
SUPPORTED = {".pdf", ".zip"} | IMAGE_EXT | TEXT_EXT | MARKITDOWN_EXT | set(LIBREOFFICE_EXT)
MEDIA_EXT = {".mp3", ".wav", ".m4a", ".ogg", ".flac", ".mp4", ".mkv", ".mov", ".avi", ".webm"}

HEB = re.compile(r"[\u0590-\u05FF]")
LAT = re.compile(r"[A-Za-z]")
COMMON = {"של", "על", "את", "לא", "כי", "גם", "הוא", "היא", "זה", "זו", "אם", "כל", "מה",
          "לו", "עם", "אל", "או", "אך", "הם", "אשר", "בו", "לה", "כך", "יש", "אין", "מן",
          "the", "of", "and", "to", "in", "is", "for", "that", "with", "on"}
FINALS = "םןץףך"


@dataclass
class Result:
    markdown: str
    method: str
    warnings: list = field(default_factory=list)
    pages: int = 0
    ocr_pages: int = 0


class Unsupported(Exception):
    pass


def estimate_tokens(text):
    """הערכה גסה בלבד: עברית יקרה יותר מאנגלית בערך פי שניים לתו."""
    heb = len(HEB.findall(text))
    return round(heb / 2 + (len(text) - heb) / 4)


def clean(text):
    text = text.replace("\ufeff", "").replace("\u00ad", "").replace("\u00a0", " ")
    text = re.sub(r"[\u200b-\u200f\u202a-\u202e\u2066-\u2069]", "", text)
    text = re.sub(r"!\[([^\]]*)\]\(data:[^)]*\)", lambda m: f"[תמונה: {m[1]}]" if m[1] else "", text)
    text = re.sub(r"(?:\. ?){4,}", " ... ", text)
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r" *\n *", "\n", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip() + "\n"


def word_score(text):
    """כמה מהמילים הן מילים נפוצות. טקסט מקודד משובש יקבל ציון קרוב לאפס."""
    words = re.findall(r"[\u05D0-\u05EAa-zA-Z]+", text.lower())
    return (sum(w in COMMON for w in words) / len(words)) if words else 0.0


def is_reversed(text):
    """אות סופית בתחילת מילה כמעט לא קיימת בעברית, ולכן היא מסגירה טקסט הפוך."""
    words = re.findall(r"[\u05D0-\u05EA]{2,}", text)
    start = sum(w[0] in FINALS for w in words)
    end = sum(w[-1] in FINALS for w in words)
    return len(words) >= 8 and start > end * 2 and start >= 3


def line_reversed(line):
    words = re.findall(r"[\u05D0-\u05EA]{2,}", line)
    return len(words) >= 2 and sum(w[0] in FINALS for w in words) >= 2 \
        and not any(w[-1] in FINALS for w in words)


def unreverse_line(line):
    line = line[::-1].translate(str.maketrans("()[]{}<>", ")(][}{><"))
    return re.sub(r"[A-Za-z0-9][A-Za-z0-9.,:/_-]*", lambda m: m[0][::-1], line)


def _fix_span(text):
    """ב-PDF מ-Word פיסוק בסוף קטע עברי נשמר לפעמים בתחילתו (":תכנית" במקום "תכנית:")."""
    m = re.fullmatch(r"([:.,;!?]+)\s*(.*[\u05D0-\u05EA].*)", text)
    return m[2] + m[1] if m else text


def _rows(page):
    frags = []
    for block in page.get_text("dict")["blocks"]:
        for line in block.get("lines", []):
            for span in line["spans"]:
                if span["text"].strip():
                    x0, y0, x1, y1 = span["bbox"]
                    frags.append({"x0": x0, "x1": x1, "yc": (y0 + y1) / 2,
                                  "size": max(span["size"], 1), "t": _fix_span(span["text"].strip()),
                                  "lead": span["text"][0].isspace(), "trail": span["text"][-1].isspace()})
    frags.sort(key=lambda f: f["yc"])
    rows = []
    for f in frags:
        if rows and abs(f["yc"] - rows[-1][0]["yc"]) < 0.5 * min(f["size"], rows[-1][0]["size"]):
            rows[-1].append(f)
        else:
            rows.append([f])
    return rows


def _segments(row):
    row = sorted(row, key=lambda f: f["x0"])
    segs = [[row[0]]]
    for f in row[1:]:
        prev = segs[-1][-1]
        if f["x0"] - prev["x1"] > max(2.5 * f["size"], 18):
            segs.append([f])
        else:
            segs[-1].append(f)
    return segs


def _join(seg, rtl):
    seg = sorted(seg, key=lambda f: f["x0"], reverse=rtl)
    out = seg[0]["t"]
    for a, b in zip(seg, seg[1:]):
        gap = (a["x0"] - b["x1"]) if rtl else (b["x0"] - a["x1"])
        out += (" " if gap > 0.15 * b["size"] or a["trail"] or b["lead"] else "") + b["t"]
    return re.sub(r"-\s*([\])])([\u05D0-\u05EA]{1,3})", r"-\2\1", out)


def _seg_record(seg, rtl):
    return {"x0": min(f["x0"] for f in seg), "x1": max(f["x1"] for f in seg),
            "y": seg[0]["yc"], "size": seg[0]["size"], "t": _join(seg, rtl)}


def _reflow(lines):
    """מחבר שורות של אותה פסקה. שורה קצרה או שורה שמסתיימת בסימן פיסוק סוגרת פסקה."""
    if not lines:
        return ""
    width = max(l["x1"] - l["x0"] for l in lines)
    out = lines[0]["t"]
    for a, b in zip(lines, lines[1:]):
        same_par = (b["y"] - a["y"] < 1.7 * a["size"] and a["x1"] - a["x0"] > 0.8 * width
                    and abs(a["size"] - b["size"]) < 0.5 and not re.search(r"[.:?!;|]$", a["t"]))
        out += (" " if same_par else "\n") + b["t"]
    return out


def page_lines(page):
    rows = _rows(page)
    text = " ".join(f["t"] for r in rows for f in r)
    rtl = len(HEB.findall(text)) >= len(LAT.findall(text))
    parsed = [_segments(r) for r in rows]
    records = [[_seg_record(s, rtl) for s in segs] for segs in parsed]

    # שני טורים: רווח אנכי באמצע העמוד שאף שורה לא חוצה, ושורות טקסט ארוכות משני צדיו
    mid_lo, mid_hi = page.rect.width * 0.35, page.rect.width * 0.65
    flat = [s for r in records for s in r]
    gutter = next((x for x in range(int(mid_lo), int(mid_hi), 4)
                   if not any(s["x0"] < x < s["x1"] for s in flat)), None)
    if gutter and len(flat) >= 16:
        left = [s for s in flat if s["x1"] <= gutter]
        right = [s for s in flat if s["x0"] >= gutter]
        avg = sum(len(s["t"]) for s in flat) / len(flat)
        if min(len(left), len(right)) >= 8 and avg >= 25:
            first, second = (right, left) if rtl else (left, right)
            return _reflow(sorted(first, key=lambda s: s["y"])) + "\n\n" + \
                _reflow(sorted(second, key=lambda s: s["y"]))

    lines = []
    for r in records:
        r = sorted(r, key=lambda s: s["x0"], reverse=rtl)
        lines.append({**r[0], "x0": min(s["x0"] for s in r), "x1": max(s["x1"] for s in r),
                      "t": " | ".join(s["t"] for s in r)})
    return _reflow(lines)


def _ocr_noise(line):
    """שורות כמו ". ה-- י 0" הן קווים ורקע שה-OCR ניסה לקרוא כאותיות."""
    letters = len(re.findall(r"[\u05D0-\u05EAa-zA-Z0-9]", line))
    return letters < 2 or letters < 0.5 * len(line.replace(" ", ""))


def ocr_image(img):
    try:
        text = pytesseract.image_to_string(img, lang=OCR_LANG, config="--psm 3")
    except pytesseract.TesseractNotFoundError:
        raise Unsupported("Tesseract לא מותקן, ולכן אי אפשר לקרוא טקסט סרוק")
    heb, lat = len(HEB.findall(text)), len(LAT.findall(text))
    if heb > lat > 0:
        # בעמוד עברי, מילים מנוקדות נקראות באנגלית משובשת. קריאה חוזרת בעברית בלבד מצילה אותן
        text = pytesseract.image_to_string(img, lang="heb", config="--psm 3")
    return "\n".join(l for l in text.split("\n") if l.strip() and not _ocr_noise(l))


def _ocr_page(path, index):
    with pymupdf.open(path) as doc:  # מסמך נפרד לכל תהליכון: PyMuPDF לא בטוח לשיתוף
        pix = doc[index].get_pixmap(dpi=OCR_DPI)
    return ocr_image(Image.frombytes("RGB", (pix.width, pix.height), pix.samples)
                     if pix.n == 3 else Image.frombytes("RGB", (pix.width, pix.height),
                                                        pymupdf.Pixmap(pymupdf.csRGB, pix).samples))


def _strip_repeats(pages):
    """מוריד כותרות עליונות ותחתונות שחוזרות, ומספרי עמוד. הן סתם טוקנים."""
    def key(line):
        return re.sub(r"\d+", "#", line.strip())

    edges = Counter()
    for text in pages:
        lines = [l for l in text.split("\n") if l.strip()]
        edges.update({key(l) for l in lines[:2] + lines[-2:]})
    limit = max(3, len(pages) * 0.5)
    repeated = {k for k, n in edges.items() if n >= limit}
    result = []
    for text in pages:
        lines = text.split("\n")
        filled = [i for i, l in enumerate(lines) if l.strip()]
        edge = set(filled[:2] + filled[-2:])
        result.append("\n".join(l for i, l in enumerate(lines)
                                if not (i in edge and (key(l) in repeated or re.fullmatch(r"[-–\s\d]+", l)))))
    return result


def _pages(n):
    return "עמוד אחד" if n == 1 else f"{n} עמודים"


def convert_pdf(path, progress):
    with pymupdf.open(path) as doc:
        if doc.needs_pass:
            raise Unsupported("ה-PDF מוגן בסיסמה")
        total = doc.page_count
        pages, need_ocr, flipped = [], [], 0
        for i, page in enumerate(doc):
            text = page_lines(page)
            if is_reversed(text):
                text = "\n".join(unreverse_line(l) for l in text.split("\n"))
                flipped += 1
            else:
                text = "\n".join(unreverse_line(l) if line_reversed(l) else l for l in text.split("\n"))
            words = len(text.split())
            empty = len(text.strip()) < 30 and (page.get_images() or page.get_drawings())
            garbled = "\ufffd" in text or "(cid:" in text or (words >= 40 and word_score(text) < 0.01)
            if empty or garbled:
                need_ocr.append(i)
            pages.append(text)
            progress(f"קורא עמוד {i + 1} מתוך {total}")

    done = 0

    def work(i):
        nonlocal done
        text = _ocr_page(path, i)
        done += 1
        progress(f"OCR: עמוד {done} מתוך {len(need_ocr)}")
        return i, text

    replaced = 0
    with ThreadPoolExecutor(OCR_WORKERS) as pool:
        for i, text in pool.map(work, need_ocr):
            # טקסט קיים נשאר אם ה-OCR לא טוב ממנו
            if len(pages[i].strip()) < 30 or word_score(text) > word_score(pages[i]):
                pages[i] = text
                replaced += 1

    pages = _strip_repeats(pages)
    body = "\n\n".join(f"[עמ' {i + 1}]\n{t.strip()}" if total > 1 else t.strip()
                       for i, t in enumerate(pages) if t.strip())
    warnings = []
    if replaced:
        warnings.append(f"{_pages(replaced)} ב-OCR. ייתכנו טעויות, בעיקר בניקוד ובטקסט קטן")
    if flipped:
        warnings.append(f"{_pages(flipped)} עם טקסט הפוך, ותוקן")
    blank = sum(not pages[i].strip() for i in need_ocr)
    if blank:
        warnings.append(f"{_pages(blank)} בלי טקסט שאפשר לקרוא")
    method = "PDF עם OCR" if replaced == total else "PDF וחלקו OCR" if replaced else "PDF"
    return Result(clean(body), method, warnings, total, replaced)


def convert_image(path, progress):
    progress("OCR לתמונה")
    with Image.open(path) as img:
        img = img.convert("RGB")
        if max(img.size) < 1500:
            img = img.resize((img.width * 2, img.height * 2), Image.LANCZOS)
        text = ocr_image(img)
    warnings = ["הטקסט נקרא ב-OCR. גרפיקה וציורים לא עוברים"]
    if len(text.strip()) < 10:
        warnings = ["לא נמצא טקסט בתמונה. אם חשוב מה רואים בה, כדאי להעלות את התמונה עצמה"]
    return Result(clean(text), "OCR", warnings, 1, 1)


def _decode(raw):
    for encoding in ("utf-8-sig", "cp1255"):
        try:
            return raw.decode(encoding)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", "replace")


def convert_text(path):
    text = _decode(Path(path).read_bytes())
    return Result(clean(text), "טקסט", ["חלק מהתווים לא פוענחו"] if "\ufffd" in text else [])


def _embedded_images(path, ext):
    folder = {".docx": "word/media/", ".pptx": "ppt/media/", ".xlsx": "xl/media/"}.get(ext)
    if not folder:
        return 0
    with zipfile.ZipFile(path) as z:
        return sum(n.startswith(folder) for n in z.namelist())


def convert_office(path, ext, progress):
    from markitdown import MarkItDown
    progress("ממיר")
    if ext == ".csv":
        # markitdown מנחש קידוד, וב-CSV עברי של Excel הישן (cp1255) הוא טועה
        with tempfile.TemporaryDirectory() as tmp:
            utf8 = Path(tmp) / "data.csv"
            utf8.write_text(_decode(Path(path).read_bytes()), encoding="utf-8")
            text = MarkItDown(enable_plugins=False).convert(str(utf8)).text_content
    else:
        text = MarkItDown(enable_plugins=False).convert(str(path)).text_content
    text = re.sub(r"(?<=\|) *(NaN|Unnamed: \d+) *(?=\|)", " ", text)
    text = re.sub(r"<!-- Slide number: (\d+) -->", r"[שקף \1]", text)
    text = re.sub(r"### Notes:\s*(?=\[שקף|\Z)", "", text)
    text, linked = re.subn(r"!\[[^\]]*\]\((?!data:)[^)]*\)", "", text)
    warnings = []
    images = _embedded_images(path, ext) or linked
    if images:
        warnings.append(f"בקובץ {images} תמונות. טקסט שכתוב בתוך תמונה לא נקרא")
    if len(text.strip()) < 10:
        warnings.append("כמעט לא נמצא טקסט בקובץ")
    return Result(clean(text), ext.lstrip(".").upper(), warnings)


def convert_legacy(path, ext, progress):
    target = LIBREOFFICE_EXT[ext]
    progress("ממיר פורמט ישן ב-LibreOffice")
    with tempfile.TemporaryDirectory() as tmp:
        source = Path(tmp) / f"source{ext}"  # שם פשוט: LibreOffice לא תמיד מסתדר עם נתיבים מיוחדים
        source.write_bytes(Path(path).read_bytes())
        try:
            subprocess.run([SOFFICE, f"-env:UserInstallation={LO_PROFILE.as_uri()}", "--headless",
                            "--norestore", "--convert-to", target, "--outdir", tmp, str(source)],
                           capture_output=True, timeout=300, creationflags=subprocess.CREATE_NO_WINDOW)
        except FileNotFoundError:
            raise Unsupported("LibreOffice לא מותקן")
        except subprocess.TimeoutExpired:
            raise Unsupported("LibreOffice לא סיים תוך 5 דקות")
        out = Path(tmp) / f"source.{target}"
        if not out.exists():
            raise Unsupported("LibreOffice לא הצליח לפתוח את הקובץ. ייתכן שהוא מוגן בסיסמה או פגום")
        result = convert_office(out, f".{target}", progress)
    result.method = ext.lstrip(".").upper()
    return result


def convert_zip(path, progress):
    parts, warnings = [], []
    with zipfile.ZipFile(path) as z, tempfile.TemporaryDirectory() as tmp:
        infos = [i for i in z.infolist() if not i.is_dir()]
        if len(infos) > ZIP_MAX_FILES or sum(i.file_size for i in infos) > ZIP_MAX_BYTES:
            raise Unsupported("קובץ ה-zip גדול מדי (עד 500 קבצים ו-2GB)")
        for n, info in enumerate(infos, 1):
            name = info.filename
            ext = Path(name).suffix.lower()
            if ext == ".zip" or ext not in SUPPORTED:
                warnings.append(f"דילוג: {name}")
                continue
            progress(f"קובץ {n} מתוך {len(infos)}: {Path(name).name}")
            target = Path(tmp) / f"{n}{ext}"  # שם פנימי, כדי שנתיב בתוך ה-zip לא יברח מהתיקייה
            target.write_bytes(z.read(info))
            try:
                sub = convert(target, progress)
                parts.append(f"# {name}\n\n{sub.markdown}")
                warnings += [f"{name}: {w}" for w in sub.warnings]
            except Exception as e:
                warnings.append(f"{name}: נכשל ({e})")
    return Result(clean("\n\n".join(parts)), "ZIP", warnings)


def convert(path, progress=lambda message: None):
    path = Path(path)
    ext = path.suffix.lower()
    if ext in MEDIA_EXT:
        raise Unsupported("אודיו ווידאו לא נתמכים כאן. צריך לתמלל אותם קודם")
    if ext == ".pdf":
        return convert_pdf(path, progress)
    if ext in IMAGE_EXT:
        return convert_image(path, progress)
    if ext in TEXT_EXT:
        return convert_text(path)
    if ext == ".zip":
        return convert_zip(path, progress)
    if ext in MARKITDOWN_EXT:
        return convert_office(path, ext, progress)
    if ext in LIBREOFFICE_EXT:
        return convert_legacy(path, ext, progress)
    with open(path, "rb") as f:
        if b"\0" not in f.read(8192):  # קוד, הגדרות וכל קובץ טקסט אחר עם סיומת לא מוכרת
            return convert_text(path)
    raise Unsupported(f"סוג קובץ לא מוכר: {ext or 'ללא סיומת'}")


def safe_stem(name):
    stem = Path(name.replace("\\", "/")).stem
    return re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", stem).strip(" .")[:120] or "file"


def save_output(folder, name, markdown):
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    stem = safe_stem(name)
    target = folder / f"{stem}.md"
    n = 2
    while target.exists():
        target = folder / f"{stem}-{n}.md"
        n += 1
    target.write_text(markdown, encoding="utf-8")
    return target
