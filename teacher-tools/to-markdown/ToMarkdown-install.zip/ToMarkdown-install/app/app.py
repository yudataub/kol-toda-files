"""שרת מקומי של "ממיר ל-Markdown". מאזין רק ל-127.0.0.1, ושום קובץ לא יוצא מהמחשב."""
import os
import queue
import shutil
import subprocess
import tempfile
import threading
import uuid
from pathlib import Path

from flask import Flask, abort, jsonify, render_template, request

import converter

BASE = Path(__file__).parent
OUTPUT = BASE / "output"
PORT = 5121
PDF_PAGE_IMAGE_TOKENS = 1500  # הערכה: כל עמוד PDF נשלח למודל גם כתמונה

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 1024**3
jobs = {}
work = queue.Queue()


@app.before_request
def guard():
    # אתר זר בדפדפן לא יכול להגיע לכאן: בודקים Host, ובכתיבה גם כותרת שדורשת אישור CORS
    if request.host.split(":")[0] not in ("127.0.0.1", "localhost"):
        abort(403)
    if request.method == "POST" and request.headers.get("X-Local-App") != "1":
        abort(403)


def worker():
    while True:
        job, path, folder = work.get()
        try:
            def progress(message):
                job["message"] = message

            result = converter.convert(path, progress)
            out = converter.save_output(OUTPUT, job["name"], result.markdown)
            tokens = converter.estimate_tokens(result.markdown)
            job.update(status="done", message="", path=str(out), text=result.markdown,
                       method=result.method, warnings=result.warnings, pages=result.pages,
                       out_size=out.stat().st_size, tokens=tokens,
                       tokens_before=(tokens + result.pages * PDF_PAGE_IMAGE_TOKENS)
                       if job["name"].lower().endswith(".pdf") else None)
        except converter.Unsupported as e:
            job.update(status="error", message=str(e))
        except Exception as e:
            job.update(status="error", message=f"ההמרה נכשלה: {e}")
        finally:
            shutil.rmtree(folder, ignore_errors=True)


threading.Thread(target=worker, daemon=True).start()


@app.get("/")
def index():
    return render_template("index.html", output=str(OUTPUT))


@app.post("/api/convert")
def api_convert():
    file = request.files.get("file")
    if not file or not file.filename:
        abort(400)
    name = os.path.basename(file.filename.replace("\\", "/"))
    folder = tempfile.mkdtemp(prefix="to-md-")
    path = Path(folder) / f"input{Path(name).suffix.lower()}"
    file.save(path)
    job = {"id": uuid.uuid4().hex, "name": name, "status": "working", "message": "ממתין בתור",
           "size": path.stat().st_size}
    jobs[job["id"]] = job
    work.put((job, path, folder))
    return jsonify(id=job["id"])


@app.get("/api/job/<job_id>")
def api_job(job_id):
    job = jobs.get(job_id)
    if not job:
        abort(404)
    return jsonify({k: v for k, v in job.items() if k != "text"})


@app.get("/api/text/<job_id>")
def api_text(job_id):
    job = jobs.get(job_id)
    if not job or "text" not in job:
        abort(404)
    return job["text"], 200, {"Content-Type": "text/plain; charset=utf-8"}


@app.post("/api/open_folder")
def api_open_folder():
    OUTPUT.mkdir(exist_ok=True)
    subprocess.Popen(["explorer", str(OUTPUT)])
    return "", 204


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=PORT, threaded=True)
