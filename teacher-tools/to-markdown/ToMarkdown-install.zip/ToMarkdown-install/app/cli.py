"""המרה משורת הפקודה ומתפריט "שלח אל". הקבצים נשמרים בתיקיית output, ובסוף היא נפתחת.

    python cli.py <קובץ> [<קובץ> ...] [--no-open]
"""
import subprocess
import sys
from pathlib import Path

import converter

OUTPUT = Path(__file__).parent / "output"


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    args = sys.argv[1:]
    no_open = "--no-open" in args
    failed = 0
    for name in [a for a in args if a != "--no-open"]:
        path = Path(name)
        print(f"ממיר: {path.name}")
        try:
            result = converter.convert(path, lambda m: print(f"  {m}", end="\r"))
            out = converter.save_output(OUTPUT, path.name, result.markdown)
            print(f"\n  נשמר: {out} (כ-{converter.estimate_tokens(result.markdown):,} טוקנים)")
            for warning in result.warnings:
                print(f"  שים לב: {warning}")
        except Exception as e:
            failed += 1
            print(f"\n  נכשל: {e}")
    if not no_open:
        subprocess.Popen(["explorer", str(OUTPUT)])
        if failed:
            input("\nלחץ Enter לסגירה")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
