﻿
$base = $PSScriptRoot
$shell = New-Object -ComObject WScript.Shell
$desktop = [Environment]::GetFolderPath('Desktop')
$a = $shell.CreateShortcut((Join-Path $desktop 'ממיר ל-Markdown.lnk'))
$a.TargetPath = "$base\.venv\Scripts\pythonw.exe"
$a.Arguments = "`"$base\launch.py`""
$a.WorkingDirectory = $base
$a.IconLocation = 'C:\Windows\System32\shell32.dll,70'
$a.Save()
$b = $shell.CreateShortcut((Join-Path ([Environment]::GetFolderPath('SendTo')) 'המר ל-Markdown.lnk'))
$b.TargetPath = "$base\.venv\Scripts\python.exe"
$b.Arguments = "`"$base\cli.py`""
$b.WorkingDirectory = $base
$b.IconLocation = 'C:\Windows\System32\shell32.dll,70'
$b.Save()
