"""פותח את הממיר בדפדפן, ומפעיל את השרת אם הוא עוד לא רץ."""
import socket
import subprocess
import sys
import time
import webbrowser
from pathlib import Path

BASE = Path(__file__).parent
PORT = 5121


def running():
    with socket.socket() as s:
        s.settimeout(0.3)
        return s.connect_ex(("127.0.0.1", PORT)) == 0


if not running():
    pythonw = Path(sys.executable).with_name("pythonw.exe")
    log = open(BASE / "server.log", "ab")
    subprocess.Popen([str(pythonw), str(BASE / "app.py")], cwd=BASE, stdout=log, stderr=log,
                     creationflags=subprocess.DETACHED_PROCESS)
    for _ in range(100):
        if running():
            break
        time.sleep(0.2)

webbrowser.open(f"http://127.0.0.1:{PORT}/")
