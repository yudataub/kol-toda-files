@echo off
rem Opens the uBlock Origin Lite store page in every existing Chrome profile of this Windows user.
rem No administrator rights needed. In each window that opens, click "Add to Chrome".
set "URL=https://chromewebstore.google.com/detail/ublock-origin-lite/ddkjiahejlhfcafbddmgiahcphecmpfh"
set "UD=%LOCALAPPDATA%\Google\Chrome\User Data"
set "CH=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not exist "%CH%" set "CH=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if not exist "%CH%" set "CH=%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"
if not exist "%CH%" echo Chrome was not found on this computer.& pause & exit /b 1
if "%1"=="test" set "DRY=echo"
for /d %%P in ("%UD%\Default" "%UD%\Profile *") do if exist "%%~fP\Preferences" %DRY% start "" "%CH%" --profile-directory="%%~nxP" "%URL%"
